﻿using proiect_csharp_GUI.model;

namespace proiect_csharp_GUI.repository.interfaces;

public interface ITicketRepository : IRepository<int, Ticket>
{
    IEnumerable<Ticket> FindByFlight(Flight flight);
}