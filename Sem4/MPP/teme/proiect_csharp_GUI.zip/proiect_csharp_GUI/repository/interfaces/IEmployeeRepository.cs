﻿using proiect_csharp_GUI.model;

namespace proiect_csharp_GUI.repository.interfaces;

public interface IEmployeeRepository : IRepository<int, Employee>
{
    Employee FindByAgencyNameAndPassword(string agencyName, string password);
}