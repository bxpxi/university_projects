﻿using proiect_csharp_GUI.model;
using proiect_csharp_GUI.service;

namespace proiect_csharp_GUI.ui;

public partial class LoginWindow : AppForm
{
    public LoginWindow(IAppService appService) : base(appService)
    {
        InitializeComponent();
    }
    
    public Employee ConnectedEmployee = null;

    private void LoginButton_Click(object sender, EventArgs e)
    {
        var agencyName = AgencyNameBox.Text;
        var password = PasswordBox.Text;
        
        ConnectedEmployee = AppService.Login(agencyName, password);

        if (ConnectedEmployee == null)
        {
            MessageBox.Show("Invalid agency name or password");
            return;
        }
        
        DialogResult = DialogResult.OK;
        Close();
    }
}