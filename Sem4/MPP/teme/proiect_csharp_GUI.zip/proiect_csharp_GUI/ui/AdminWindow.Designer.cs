﻿using System.ComponentModel;

namespace proiect_csharp_GUI.ui;

partial class AdminWindow
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        panel1 = new System.Windows.Forms.Panel();
        RegisterButton = new System.Windows.Forms.Button();
        label2 = new System.Windows.Forms.Label();
        label1 = new System.Windows.Forms.Label();
        PasswordBox = new System.Windows.Forms.TextBox();
        AgencyNameBox = new System.Windows.Forms.TextBox();
        panel1.SuspendLayout();
        SuspendLayout();
        // 
        // panel1
        // 
        panel1.Controls.Add(RegisterButton);
        panel1.Controls.Add(label2);
        panel1.Controls.Add(label1);
        panel1.Controls.Add(PasswordBox);
        panel1.Controls.Add(AgencyNameBox);
        panel1.Location = new System.Drawing.Point(124, 36);
        panel1.Name = "panel1";
        panel1.Size = new System.Drawing.Size(544, 368);
        panel1.TabIndex = 0;
        // 
        // RegisterButton
        // 
        RegisterButton.Location = new System.Drawing.Point(230, 269);
        RegisterButton.Name = "RegisterButton";
        RegisterButton.Size = new System.Drawing.Size(99, 42);
        RegisterButton.TabIndex = 4;
        RegisterButton.Text = "REGISTER";
        RegisterButton.UseVisualStyleBackColor = true;
        RegisterButton.Click += RegisterButton_Click;
        // 
        // label2
        // 
        label2.Location = new System.Drawing.Point(59, 148);
        label2.Name = "label2";
        label2.Size = new System.Drawing.Size(100, 23);
        label2.TabIndex = 3;
        label2.Text = "Password:";
        // 
        // label1
        // 
        label1.Location = new System.Drawing.Point(59, 62);
        label1.Name = "label1";
        label1.Size = new System.Drawing.Size(140, 31);
        label1.TabIndex = 2;
        label1.Text = "Agency Name:";
        label1.Click += label1_Click;
        // 
        // PasswordBox
        // 
        PasswordBox.Location = new System.Drawing.Point(230, 140);
        PasswordBox.Name = "PasswordBox";
        PasswordBox.Size = new System.Drawing.Size(224, 31);
        PasswordBox.TabIndex = 1;
        
        // 
        // AgencyNameBox
        // 
        AgencyNameBox.Location = new System.Drawing.Point(230, 62);
        AgencyNameBox.Name = "AgencyNameBox";
        AgencyNameBox.Size = new System.Drawing.Size(224, 31);
        AgencyNameBox.TabIndex = 0;
        // 
        // AdminWindow
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(800, 450);
        Controls.Add(panel1);
        Text = "AdminWindow";
        panel1.ResumeLayout(false);
        panel1.PerformLayout();
        ResumeLayout(false);
    }

    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Button RegisterButton;

    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.TextBox AgencyNameBox;
    private System.Windows.Forms.TextBox PasswordBox;
    private System.Windows.Forms.Label label1;

    #endregion
}