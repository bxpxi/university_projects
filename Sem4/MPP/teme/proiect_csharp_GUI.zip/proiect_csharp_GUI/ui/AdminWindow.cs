﻿using proiect_csharp_GUI.service;

namespace proiect_csharp_GUI.ui;

public partial class AdminWindow : AppForm
{
    public AdminWindow(IAppService appService) : base(appService)
    {
        InitializeComponent();
    }

    private void label1_Click(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void RegisterButton_Click(object sender, EventArgs e)
    {
        var agencyName = AgencyNameBox.Text;
        var password = PasswordBox.Text;

        try
        {
            AppService.Register(agencyName, password);
            MessageBox.Show("Registration Successful");
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }
        finally
        {
            AgencyNameBox.Clear();
            PasswordBox.Clear();
        }
    }
}