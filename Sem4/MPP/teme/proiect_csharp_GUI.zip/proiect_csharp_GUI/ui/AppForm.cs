﻿using proiect_csharp_GUI.service;

namespace proiect_csharp_GUI.ui;

public partial class AppForm : Form
{
    protected internal IAppService AppService;
    
    public AppForm() : this(null) { }

    public AppForm(IAppService appService = null)
    {
        AppService = appService;
    }
}