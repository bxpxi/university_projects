﻿namespace proiect_csharp_GUI.model;

public class Entity<T>
{
    
}