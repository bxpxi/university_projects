﻿using proiect_csharp_GUI.model;

namespace proiect_csharp_GUI.service;

public interface IAppService
{
    void Register(string username, string password);
    Employee Login(string agencyName, string password);

    IEnumerable<Flight> FindFlights();
    IEnumerable<Flight> FindByDestinationAndDepartureDate(string destination, string departureDate);

    void BuyTicket(Flight flight, string client, int noOfSeats);
}