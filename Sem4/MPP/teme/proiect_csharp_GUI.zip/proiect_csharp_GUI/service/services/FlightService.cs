﻿using proiect_csharp_GUI.model;
using proiect_csharp_GUI.repository.interfaces;
using proiect_csharp_GUI.service.interfaces;

namespace proiect_csharp_GUI.service.services;

public class FlightService : AbstractService<int, Flight, IFlightRepository>, IFlightService
{
    public FlightService(IFlightRepository repository) : base(repository)
    {
        
    }
    
    public IEnumerable<Flight> FindByDestinationAndDepartureDate(string destination, string departureDate)
    {
        return Repository.FindByDestinationAndDepartureDate(destination, departureDate);
    }
}