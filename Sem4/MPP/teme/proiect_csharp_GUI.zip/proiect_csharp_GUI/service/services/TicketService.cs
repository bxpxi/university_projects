﻿using proiect_csharp_GUI.model;
using proiect_csharp_GUI.repository.interfaces;
using proiect_csharp_GUI.service.interfaces;

namespace proiect_csharp_GUI.service.services;

public class TicketService : AbstractService<int, Ticket, ITicketRepository>, ITicketService
{
    public TicketService(ITicketRepository repository) : base(repository)
    {
        
    }

    public IEnumerable<Ticket> FindByFlight(Flight flight)
    {
        return Repository.FindByFlight(flight);
    }

}