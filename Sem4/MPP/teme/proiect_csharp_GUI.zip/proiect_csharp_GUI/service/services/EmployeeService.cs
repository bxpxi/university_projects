﻿using proiect_csharp_GUI.model;
using proiect_csharp_GUI.repository.interfaces;
using proiect_csharp_GUI.service.interfaces;

namespace proiect_csharp_GUI.service.services;

public class EmployeeService : AbstractService<int, Employee, IEmployeeRepository>, IEmployeeService
{
    public EmployeeService(IEmployeeRepository repository) : base(repository)
    {
        
    }

    public void Register(Employee employee)
    {
        string agencyName = employee.AgencyName;
        string password = employee.Password;
        Save(new Employee(agencyName, password));
    }

    public Employee Login(string agencyName, string password)
    {
        return Repository.FindByAgencyNameAndPassword(agencyName, password);
    }
}