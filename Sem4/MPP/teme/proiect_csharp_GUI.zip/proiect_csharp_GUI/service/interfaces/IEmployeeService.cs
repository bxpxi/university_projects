﻿using proiect_csharp_GUI.model;

namespace proiect_csharp_GUI.service.interfaces;

public interface IEmployeeService : IService<int, Employee>
{
    void Register(Employee employee);
    Employee Login(string agencyName, string password);
}