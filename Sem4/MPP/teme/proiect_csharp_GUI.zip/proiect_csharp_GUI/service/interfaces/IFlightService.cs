﻿using proiect_csharp_GUI.model;

namespace proiect_csharp_GUI.service.interfaces;

public interface IFlightService : IService<int, Flight>
{
    IEnumerable<Flight> FindByDestinationAndDepartureDate(string destination, string departureDate);
}