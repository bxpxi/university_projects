﻿using proiect_csharp_GUI.model;

namespace proiect_csharp_GUI.service.interfaces;

public interface ITicketService : IService<int, Ticket>
{
    IEnumerable<Ticket> FindByFlight(Flight flight);
}