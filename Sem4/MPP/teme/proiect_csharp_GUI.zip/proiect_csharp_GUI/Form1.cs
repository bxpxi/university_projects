namespace proiect_csharp_GUI;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }
}