using System.Reflection;
using log4net;
using log4net.Config;
using proiect_csharp_GUI.model;
using proiect_csharp_GUI.repository.databases;
using proiect_csharp_GUI.repository;
using proiect_csharp_GUI.service;
using proiect_csharp_GUI.service.services;
using proiect_csharp_GUI.ui;

namespace proiect_csharp_GUI;

static class Program
{
    private static readonly ILog logger = LogManager.GetLogger(typeof(Program));
    
    /// <summary>
    ///  The main entry point for the application.
    /// </summary>
    [STAThread]
    
    public static bool TestConnection()
    {
        try
        {
            using (var connection = JdbcUtils.getConnection())
            {
                return true;
            }
        }
        catch (Exception ex)
        {
            logger.Error("Test connection failed: " + ex.Message);
            return false;
        }
    }
    
    static void Main()
    {
        // To customize application configuration such as set high DPI settings or default font,
        // see https://aka.ms/applicationconfiguration.
        
        var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
        XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));
        
        if (TestConnection())
            logger.Info("Test connection successful");
        else
            logger.Error("Test connection failed");
        
        EmployeeRepository EmployeeRepository = new EmployeeRepository();
        FlightRepository FlightRepository = new FlightRepository();
        TicketRepository TicketRepository = new TicketRepository(FlightRepository);
        
        EmployeeService EmployeeService = new EmployeeService(EmployeeRepository);
        FlightService FlightService = new FlightService(FlightRepository);
        TicketService TicketService = new TicketService(TicketRepository);
        
        AppService AppService = new AppService(EmployeeService, FlightService, TicketService);
        
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        //ApplicationConfiguration.Initialize();
        Application.Run(new FlightsWindow(AppService));
    }
}