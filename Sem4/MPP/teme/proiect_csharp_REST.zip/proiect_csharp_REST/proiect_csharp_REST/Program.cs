﻿using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Text.Json;

namespace RestClientTest
{
    public class Flight
    {
        public int Id { get; set; }
        public string Destination { get; set; }
        public string DepartureDate { get; set; }
        public string DepartureTime { get; set; }
        public string Airport { get; set; }
        public int AvailableSeats { get; set; }

        public override string ToString()
        {
            return $"Flight [id={Id}, destination={Destination}, departureDate={DepartureDate}, departureTime={DepartureTime}, airport={Airport}, availableSeats={AvailableSeats}]";
        }
    }

    class Program
    {
        private static readonly HttpClient client = new HttpClient();
        private const string BASE_URL = "http://localhost:8080/agency/flights";

        static async Task Main(string[] args)
        {
            try
            {
                // CREATE
                var newFlight = new Flight
                {
                    Destination = "Berlin",
                    DepartureDate = "2025-09-01",
                    DepartureTime = "13:45",
                    Airport = "BER",
                    AvailableSeats = 150
                };

                Console.WriteLine("Creating a new flight...");
                var response = await client.PostAsJsonAsync(BASE_URL, newFlight);
                var createdFlight = await response.Content.ReadFromJsonAsync<Flight>();
                Console.WriteLine("Created: " + createdFlight);

                // GET ALL
                Console.WriteLine("\nGetting all flights...");
                var flights = await client.GetFromJsonAsync<Flight[]>(BASE_URL);
                foreach (var flight in flights)
                    Console.WriteLine(flight);

                // GET BY ID
                Console.WriteLine($"\nGetting flight by ID: {createdFlight.Id}");
                var fetchedFlight = await client.GetFromJsonAsync<Flight>($"{BASE_URL}/{createdFlight.Id}");
                Console.WriteLine(fetchedFlight);

                // UPDATE
                Console.WriteLine($"\nUpdating flight {createdFlight.Id}...");
                createdFlight.AvailableSeats = 99;
                await client.PutAsJsonAsync($"{BASE_URL}/{createdFlight.Id}", createdFlight);
                var updatedFlight = await client.GetFromJsonAsync<Flight>($"{BASE_URL}/{createdFlight.Id}");
                Console.WriteLine("Updated: " + updatedFlight);

                // DELETE
                Console.WriteLine($"\nDeleting flight {createdFlight.Id}...");
                await client.DeleteAsync($"{BASE_URL}/{createdFlight.Id}");
                Console.WriteLine("Deleted.");

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
