import {useState} from "react";
import api from "./api.js";

function DeleteFlightForm({flights}) {
    const [id, setId] = useState(1);
    return (
      <form>
          Id: <input type="number" value={id} onChange={e => setId(e.target.value)}/> <br />
          <input type="submit" onClick={ async (e) => {
                e.preventDefault();
                await api.remove(id, function(response){
                    console.log(response);
                    alert("Flight removed!");
                    window.location.reload(false);
                })
            }
          }/>
      </form>
    );
}

export default DeleteFlightForm;