import {useState} from "react";
import api from "./api.js";

function UpdateFlightForm(){
    const [id, setId] = useState(1);
    const [destination, setDestination] = useState("exampleFlight");
    const [departureDate, setDepartureDate] = useState(new Date());
    const [departureTime, setDepartureTime] = useState("12:00");
    const [airport, setAirport] = useState("exampleAirport");
    const [availableSeats, setAvailableSeats] = useState(30);

    return (
        <form>
            Id: <input type="number" value={id} onChange={e=>setId(e.target.value)}/> <br />
            Destination: <input type="text" value={destination} onChange={e => setDestination(e.target.value)} /> <br />
            Departure Date: <input type="date" value={departureDate.toISOString().substring(0, 10)} onChange={e => setDepartureDate(new Date(e.target.value))}/> <br />
            Departure Time: <input type="time" value={departureTime} onChange={e => setDepartureTime(e.target.value)} /> <br />
            Airport: <input type="text" value={airport} onChange={e => setAirport(e.target.value)} /> <br />
            Available Seats: <input type="number" value={availableSeats} onChange={e => setAvailableSeats(e.target.value)}/> <br />
            <input type="submit" onClick={async (e) => {
                e.preventDefault();
                const flight = {
                    id,
                    destination,
                    departureDate: departureDate.toISOString().substring(0, 19),
                    departureTime,
                    airport,
                    availableSeats
                };
                console.log(flight);
                await api.update(flight, function(response){
                    console.log(response);
                    alert("Flight updated!");
                    window.location.reload(false);
                });
            }}/>
        </form>
    );
}

export default UpdateFlightForm;
