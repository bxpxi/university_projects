import {useState} from "react";
import FormattedDate from "./FormattedDate.jsx";

function FlightView({flight}){
    const [id, setID] = useState(flight.id);
    const [destination, setDestination] = useState(flight.destination);
    const [departureDate, setDepartureDate] = useState(new Date(flight.departureDate));
    const [departureTime, setDepartureTime] = useState(flight.departureTime); // ADĂUGAT
    const [airport, setAirport] = useState(flight.airport);
    const [availableSeats, setAvailableSeats] = useState(flight.availableSeats);

    return (
        <div>
          <span>
              {id}, {destination}, <FormattedDate date={departureDate} />, {departureTime}, {airport}, {availableSeats}
          </span>
        </div>
    );
}

export default FlightView;