import { useEffect, useState } from 'react';
import './App.css';
import FlightsList from "./FlightsList.jsx";
import AddFlightForm from "./AddFlightForm.jsx";
import UpdateFlightForm from "./UpdateFlightForm.jsx";
import DeleteFlightForm from "./DeleteFlightForm.jsx";
import api from "./api.js";

function App() {
    const [flights, setFlights] = useState([]);

    useEffect(() => {
        // Ia toate zborurile la încărcarea paginii
        api.getAll(setFlights);

        // Conectare la WebSocket la endpoint-ul corect
        const ws = new WebSocket('ws://localhost:8080/flightss');

        ws.onopen = () => {
            console.log("✅ WebSocket connected");
        };

        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                console.log("📦 WebSocket update received:", data);
                setFlights(data); // Actualizează lista zborurilor în UI
            } catch (e) {
                console.error("❌ Error parsing WS message:", e);
            }
        };

        ws.onclose = () => {
            console.log("🔌 WebSocket closed");
        };

        ws.onerror = (error) => {
            console.error("💥 WebSocket error:", error);
        };

        // Curățare: închide conexiunea când componenta se demontează
        return () => {
            ws.close();
        };
    }, []);  // [] = rulează o singură dată, la mount

    console.log("   Mounting App.jsx")

    return (
        <>
            <div id="Container">
                <div id="Get">
                    <h2>Flights</h2>
                    <div id="FlightsContainer">
                        <FlightsList flights={flights} />
                    </div>
                </div>
                <div id="Add">
                    <h2>Add</h2>
                    <AddFlightForm />
                </div>
                <div id="Update">
                    <h2>Update</h2>
                    <UpdateFlightForm />
                </div>
                <div id="Delete">
                    <h2>Delete</h2>
                    <DeleteFlightForm />
                </div>
            </div>
        </>
    );
}

export default App;
