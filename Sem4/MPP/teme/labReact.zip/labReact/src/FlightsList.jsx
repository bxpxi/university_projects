import {useState} from "react";
import {FlatList} from 'react-native-web'
import FlightView from "./FlightView.jsx";

function FlightsList({flights}){
    const [items, setItems] = useState(flights);

    return (
      <FlatList data={flights} renderItem={({item}) => (<FlightView flight={item} />)}>

      </FlatList>
    );
}

export default FlightsList;