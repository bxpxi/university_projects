async function textOrError(resp) {
    if (resp.ok) {
        return resp.text();
    }
    throw new Error(resp.status+" : "+ await resp.text());
}

async function jsonOrError(resp) {
    if (resp.ok) {
        return resp.json();
    }
    throw new Error(resp.status+" : "+ await resp.text());
}

const api = {
    getAll : function(callback) {
        fetch('http://localhost:8080/agency/flights')
            .then(jsonOrError)
            .then(callback)
            .catch(e=>alert(e));
    },
    add : function(flight, callback) {
        fetch('http://localhost:8080/agency/flights',{
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            },
            body: JSON.stringify(flight)
        })
            .then(jsonOrError)
            .then(callback)
            .catch(e=>alert(e));
    },
    update : function(flight, callback) {
        fetch('http://localhost:8080/agency/flights/'+flight.id,{
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            },
            body: JSON.stringify(flight)
        })
            .then(textOrError)
            .then(callback)
            .catch(e=>alert(e));
    },
    remove : function(id, callback) {
        fetch('http://localhost:8080/agency/flights/'+id,{
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            },
        })
            .then(textOrError)
            .then(callback)
            .catch(e=>alert(e));
    }
};

export default api;