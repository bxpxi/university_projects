﻿namespace proiect_csharp.model;

public class Client : Entity<int>
{
    public int Id { get; set; }
    public string ClientName { get; set; }

    public Client(string clientName)
    {
        ClientName = clientName;
    }

    public override string ToString()
    {
        return $"Client: [Id: {Id}, ClientName: {ClientName}]";
    }
}