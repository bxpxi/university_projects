﻿namespace proiect_csharp.model;

public interface Entity<T>
{
    
}