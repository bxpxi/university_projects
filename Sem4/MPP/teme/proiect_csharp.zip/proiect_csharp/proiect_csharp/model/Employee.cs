﻿namespace proiect_csharp.model;

public class Employee : Entity<int>
{
    public int Id {get; set;}
    public string AgencyName { get; set; }
    public string Password { get; set; }

    public Employee(string agencyName, string password)
    {
        AgencyName = agencyName;
        Password = password;
    }

    public override string ToString()
    {
        return $"Employee[Id: {Id}, AgencyName: {AgencyName}, Password: {Password}]";
    }
}