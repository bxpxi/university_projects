﻿using proiect_csharp.model;

namespace proiect_csharp.repository.interfaces;

public interface IClientRepository : IRepository<int, Client>
{
    
}