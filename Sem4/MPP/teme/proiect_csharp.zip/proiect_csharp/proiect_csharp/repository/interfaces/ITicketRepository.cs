﻿using proiect_csharp.model;

namespace proiect_csharp.repository.interfaces;

public interface ITicketRepository : IRepository<int, Ticket>
{
    
}