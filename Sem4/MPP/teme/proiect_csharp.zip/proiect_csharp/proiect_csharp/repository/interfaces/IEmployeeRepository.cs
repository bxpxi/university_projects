﻿using proiect_csharp.model;

namespace proiect_csharp.repository.interfaces;

public interface IEmployeeRepository : IRepository<int, Employee>
{
    Employee FindByAgencyNameAndPassword(string agencyName, string password);
}