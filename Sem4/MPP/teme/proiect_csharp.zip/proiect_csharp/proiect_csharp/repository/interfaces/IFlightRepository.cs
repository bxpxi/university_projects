﻿using proiect_csharp.model;

namespace proiect_csharp.repository.interfaces;

public interface IFlightRepository : IRepository<int, Flight>
{
    IEnumerable<Flight> FindByDestinationAndDepartureDate(string destination, string departureDate);
}