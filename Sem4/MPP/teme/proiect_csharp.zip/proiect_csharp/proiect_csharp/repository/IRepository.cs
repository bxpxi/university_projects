﻿using proiect_csharp.model;

namespace proiect_csharp.repository;

public interface IRepository<ID, E > where E : Entity<ID>
{
    E FindById(ID id);
    IEnumerable<E> FindAll();
    void Save(E entity);
    void Delete(ID id);
    void Update(ID id, E entity);
}