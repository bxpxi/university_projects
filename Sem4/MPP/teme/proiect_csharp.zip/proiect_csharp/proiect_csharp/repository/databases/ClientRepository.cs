﻿using System.Data;
using System.Data.SqlClient;
using log4net;
using proiect_csharp.model;
using proiect_csharp.repository.interfaces;

namespace proiect_csharp.repository.databases;

public class ClientRepository : IClientRepository
{
    private static readonly ILog logger = LogManager.GetLogger(typeof(ClientRepository));

    public ClientRepository()
    {
        logger.Info("ClientRepository initialized");
    }

    public Client FindById(int id)
    {
        logger.Info("Finding Client with Id");
        IDbConnection connection = JdbcUtils.getConnection();
        using (IDbCommand command = connection.CreateCommand())
        {
            command.CommandText = "SELECT * FROM clients WHERE id = @id";
            IDataParameter idParameter = command.CreateParameter();
            idParameter.ParameterName = "@id";
            idParameter.Value = id;
            command.Parameters.Add(idParameter);
            using (IDataReader result = command.ExecuteReader())
            {
                if (result.Read())
                {
                    string clientName = result["clientName"].ToString();
                    Client client = new Client(clientName);
                    client.Id = Convert.ToInt32(result["id"]);
                    return client;
                }
            }
        }
        return null;
    }

    public IEnumerable<Client> FindAll()
    {
        logger.Info("Finding All Clients");
        IDbConnection connection = JdbcUtils.getConnection();
        List<Client> clients = new List<Client>();
        using (IDbCommand command = connection.CreateCommand())
        {
            command.CommandText = "SELECT * FROM clients";
            using (IDataReader result = command.ExecuteReader())
            {
                while (result.Read())
                {
                    int id = Convert.ToInt32(result["id"]);
                    string clientName = result["clientName"].ToString();
                    Client client = new Client(clientName);
                    client.Id = id;
                    clients.Add(client);
                }
            }
            
        }
        return clients;
    }

    public void Save(Client client)
    {
        logger.Info("Saving Client");
        IDbConnection connection = JdbcUtils.getConnection();
        using (IDbCommand command = connection.CreateCommand())
        {
            command.CommandText = "INSERT INTO clients (clientName) VALUES (@clientName)";
            IDataParameter clientNameParameter = command.CreateParameter();
            clientNameParameter.ParameterName = "@clientName";
            clientNameParameter.Value = client.ClientName;
            command.Parameters.Add(clientNameParameter);
            int result = command.ExecuteNonQuery();
            logger.Info("Saved clients: " + result);
        }
    }

    public void Delete(int id)
    {
        logger.Info("Deleting Client");
        IDbConnection connection = JdbcUtils.getConnection();
        using (IDbCommand command = connection.CreateCommand())
        {
            command.CommandText = "DELETE FROM clients WHERE id = @id";
            IDataParameter idParameter = command.CreateParameter();
            idParameter.ParameterName = "@id";
            idParameter.Value = id;
            command.Parameters.Add(idParameter);
            int result = command.ExecuteNonQuery();
            logger.Info("Deleted clients: " + result);
        }
    }

    public void Update(int id, Client client)
    {
        logger.Info("Updating Client");
        IDbConnection connection = JdbcUtils.getConnection();
        using (IDbCommand command = connection.CreateCommand())
        {
            command.CommandText = "UPDATE clients SET clientName = @clientName WHERE id = @id";
            IDataParameter clientNameParameter = command.CreateParameter();
            clientNameParameter.ParameterName = "@clientName";
            clientNameParameter.Value = client.ClientName;
            command.Parameters.Add(clientNameParameter);
            IDataParameter idParameter = command.CreateParameter();
            idParameter.ParameterName = "@id";
            idParameter.Value = id;
            command.Parameters.Add(idParameter);
            int result = command.ExecuteNonQuery();
            logger.Info("Updated clients: " + result);
        }
    }
    
    
}