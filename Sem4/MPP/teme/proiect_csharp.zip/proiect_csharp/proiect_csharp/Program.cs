﻿using log4net.Config;
using log4net;
using System.Reflection;
using proiect_csharp.model;
using proiect_csharp.repository;
using proiect_csharp.repository.databases;

namespace proiect_csharp;

internal class Program
{
    private static readonly ILog logger = LogManager.GetLogger(typeof(Program));
    
    public static bool TestConnection()
    {
        try
        {
            using (var connection = JdbcUtils.getConnection())
            {
                return true;
            }
        }
        catch (Exception ex)
        {
            logger.Error("Test connection failed: " + ex.Message);
            return false;
        }
    }
    
    static void Main(string[] args)
    {
        var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
        XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));
        
        if (TestConnection())
            logger.Info("Test connection successful");
        else
            logger.Error("Test connection failed");
        
        //clients
        ClientRepository clientRepo = new ClientRepository();
        clientRepo.Save(new Client("Marinescu Razvan"));
        Console.WriteLine("Clients from DB: ");
        foreach(Client client in clientRepo.FindAll()) {
            Console.WriteLine(client);
        }
        Client new_client = new Client("Popescu Ana");
        clientRepo.Update(23, new_client);
        Console.WriteLine("Clients from DB: ");
        foreach(Client client in clientRepo.FindAll()) {
            Console.WriteLine(client);
        }
        Console.WriteLine(clientRepo.FindById(23));
        clientRepo.Delete(23);
        Console.WriteLine("Clients from DB: ");
        foreach(Client client in clientRepo.FindAll()) {
            Console.WriteLine(client);
        }
        
        //employees
        EmployeeRepository employeeRepo = new EmployeeRepository();
        employeeRepo.Save(new Employee("Paralelaa 45", "1234"));
        Console.WriteLine("Employees from DB: ");
        foreach (Employee employee in employeeRepo.FindAll()) {
            Console.WriteLine(employee);
        }
        Employee new_employee = new Employee("Paralelaaa 45", "1111");
        employeeRepo.Update(21, new_employee);
        Console.WriteLine("Employees from DB: ");
        foreach (Employee employee in employeeRepo.FindAll()) {
            Console.WriteLine(employee);
        }
        Console.WriteLine(employeeRepo.FindById(21));
        Console.WriteLine(employeeRepo.FindByAgencyNameAndPassword("Paralelaaa 45", "1111"));
        employeeRepo.Delete(21);
        Console.WriteLine("Employees from DB: ");
        foreach (Employee employee in employeeRepo.FindAll()) {
            Console.WriteLine(employee);
        }
        
        //flights
        FlightRepository flightRepo = new FlightRepository();
        flightRepo.Save(new Flight("Paris", "03/28/2025", "14:00", "Paris Airport", 50));
        Console.WriteLine("Flights from DB: ");
        foreach (Flight flight in flightRepo.FindAll()) {
            Console.WriteLine(flight);
        }
        Flight new_flight = new Flight("Londonnn", "04/28/2025", "14:00", "London Airport", 50);
        flightRepo.Update(21, new_flight);
        Console.WriteLine("Flights from DB: ");
        foreach (Flight flight in flightRepo.FindAll()) {
            Console.WriteLine(flight);
        }
        Console.WriteLine(flightRepo.FindById(21));
        Console.WriteLine("Flights: ");
        foreach (Flight flight in flightRepo.FindByDestinationAndDepartureDate("Londonnn", "04/28/2025")) {
            Console.WriteLine(flight);
        }
        flightRepo.Delete(21);
        Console.WriteLine("Flights from DB: ");
        foreach (Flight flight in flightRepo.FindAll()) {
            Console.WriteLine(flight);
        }
        
        
        //tickets
        TicketRepository ticketRepo = new TicketRepository(clientRepo, flightRepo);
        Client client1 = clientRepo.FindById(1);
        Flight flight1 = flightRepo.FindById(8);
        ticketRepo.Save(new Ticket(client1,flight1, 51));
        Console.WriteLine("Tickets from DB: ");
        foreach(Ticket ticket in ticketRepo.FindAll()) {
            Console.WriteLine(ticket);
        }
        Client client2 = clientRepo.FindById(4);
        Flight flight2 = flightRepo.FindById(9);
        Ticket new_ticket = new Ticket(client2, flight2, 2);
        ticketRepo.Update(11, new_ticket);
        Console.WriteLine("Tickets from DB: ");
        foreach(Ticket ticket in ticketRepo.FindAll()) {
            Console.WriteLine(ticket);
        }
        Console.WriteLine(ticketRepo.FindById(11));
        ticketRepo.Delete(11);
        Console.WriteLine("Tickets from DB: ");
        foreach(Ticket ticket in ticketRepo.FindAll()) {
            Console.WriteLine(ticket);
        }
    }
}