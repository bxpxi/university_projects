#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>

int main() {
    int s;
    struct sockaddr_in server, client;
    socklen_t client_len = sizeof(client);
    char hostname[101];
    struct hostent *host_entry;
    uint32_t ip_address;

    s = socket(AF_INET, SOCK_DGRAM, 0);
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(1234);
    server.sin_addr.s_addr = INADDR_ANY;

    bind(s, (struct sockaddr *)&server, sizeof(server));
    while (1) {
        recvfrom(s, hostname, sizeof(hostname), 0, (struct sockaddr *)&client, &client_len);
        host_entry = gethostbyname(hostname);
        if (host_entry == NULL) {
            ip_address = 0;
        } else {
            ip_address = *(uint32_t *)host_entry->h_addr_list[0];
        }
        ip_address = htonl(ip_address);
        sendto(s, &ip_address, sizeof(ip_address), 0, (struct sockaddr *)&client, client_len);
    }

    close(s);
    return 0;
}
