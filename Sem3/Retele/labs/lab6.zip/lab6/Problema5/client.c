#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>

int main() {
    int c;
    struct sockaddr_in server;
    uint8_t number;
    uint8_t divisors[256];
    int count;

    c = socket(AF_INET, SOCK_DGRAM, 0);
    if (c < 0) {
        perror("Eroare la crearea socketului client");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(1234);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("Introduceți un număr (0-255): ");
    scanf("%hhu", &number);

    sendto(c, &number, sizeof(number), 0, (struct sockaddr *)&server, sizeof(server));
    recvfrom(c, divisors, sizeof(divisors), 0, NULL, NULL);
    recvfrom(c, &count, sizeof(count), 0, NULL, NULL);

    if (count > 0) {
        printf("Divizorii pentru numărul %d sunt: ", number);
        for (int j = 0; j < count; j++) {
            printf("%d ", divisors[j]);
        }
        printf("\n");
    } else {
        printf("Nu există divizori pentru numărul %d.\n", number);
    }

    close(c);
    return 0;
}
