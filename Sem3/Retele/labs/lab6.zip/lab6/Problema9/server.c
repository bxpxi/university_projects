#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

int main() {
    int s;
    struct sockaddr_in server, client;
    int l = sizeof(client);
    time_t current_time;

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) {
        perror("Eroare la crearea socketului server");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(1234);
    server.sin_addr.s_addr = INADDR_ANY;

    if (bind(s, (struct sockaddr *) &server, sizeof(server)) < 0) {
        perror("Eroare la bind");
        close(s);
        return 1;
    }

    printf("Serverul UDP este pornit și ascultă pe portul 1234...\n");

    while (1) {
        uint16_t request;
        printf("Se asteapta o cerere de la client...\n");

        recvfrom(s, &request, sizeof(request), MSG_WAITALL, (struct sockaddr *) &client, &l);

        current_time = time(NULL);
        uint32_t time_to_send = htonl((uint32_t)current_time);

        printf("Cerere primita. Se trimite timpul curent: %ld\n", (long)current_time);

        sendto(s, &time_to_send, sizeof(time_to_send), 0, (struct sockaddr *) &client, l);
    }

    close(s);
    return 0;
}
