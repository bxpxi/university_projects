#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    int c;
    struct sockaddr_in server;
    uint32_t server_time;
    int l=sizeof(server);

    c = socket(AF_INET, SOCK_DGRAM, 0);
    if (c < 0) {
        perror("Eroare la crearea socketului client");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(1234);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    uint16_t request = 1;
    request = htons(request);
    printf("Se trimite cererea catre server...\n");
    sendto(c, &request, sizeof(request), 0, (struct sockaddr *) &server, sizeof(server));

    if (recvfrom(c, &server_time, sizeof(server_time), MSG_WAITALL, (struct sockaddr *) &server, &l) < 0) {
        perror("Eroare la primirea datelor de la server");
        close(c);
        return 1;
    }

    server_time = ntohl(server_time);
    printf("Timpul primit de la server: %u secunde de la epoch\n", server_time);

    time_t received_time = (time_t)server_time;
    printf("Data si ora: %s", ctime(&received_time));

    close(c);
    return 0;
}
