#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

int main() {
    int c;
    struct sockaddr_in server;
    char buffer[101];
    int space_count;

    c = socket(AF_INET, SOCK_DGRAM, 0);
    if (c < 0) {
        perror("Eroare la crearea socketului client");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(1234);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("Introduceți un șir de caractere (max 100): ");
    fgets(buffer, sizeof(buffer), stdin);

    sendto(c, buffer, strlen(buffer), 0, (struct sockaddr *)&server, sizeof(server));
    recvfrom(c, &space_count, sizeof(space_count), 0, NULL, NULL);

    printf("Numărul de caractere spațiu din șir este: %d\n", space_count);

    close(c);
    return 0;
}
