#include<string.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

int main() {
    int c;
    struct sockaddr_in server;
    int numbers[2];
    int sum;

    c = socket(AF_INET, SOCK_DGRAM, 0);
    if (c < 0) {
        perror("Eroare la crearea socketului client");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(1234);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("Introduceți două numere: ");
    scanf("%d %d", &numbers[0], &numbers[1]);

    numbers[0] = htonl(numbers[0]);
    numbers[1] = htonl(numbers[1]);
    sendto(c, numbers, sizeof(numbers), 0, (struct sockaddr *)&server, sizeof(server));
    recvfrom(c, &sum, sizeof(sum), 0, NULL, NULL);
    sum = ntohl(sum);

    printf("Suma celor două numere este: %d\n", sum);

    close(c);
    return 0;
}
