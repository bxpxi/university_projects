#include<sys/types.h>
#include<sys/socket.h>
#include<stdio.h>
#include<string.h>
#include<netinet/in.h>
#include<netinet/ip.h>

int main() {
	int c;
	struct sockaddr_in server;
	char sir[101],subsir[101];
	uint16_t i,l;
	int server_dim=sizeof(server);

	c=socket(AF_INET,SOCK_DGRAM,0);
	if(c<0) {
		printf("Eroare la crearea socketului client.\n");
		return 1;
	}

	memset(&server,0,sizeof(server));
	server.sin_port=htons(1234);
	server.sin_family=AF_INET;
	server.sin_addr.s_addr=inet_addr("127.0.0.1");

	printf("Introduceti sirul: ");
	fgets(sir,sizeof(sir),stdin);

	uint16_t len=strlen(sir);
	if(sir[len-1]=='\n') {
		sir[len-1]='\0';
		len--;
	}

	printf("Introduceti pozitia de la care porneste subsirul: ");
	scanf("%hu",&i);
	printf("Introduceti lungimea subsirului: ");
	scanf("%hu",&l);

	i=htons(i);
	l=htons(l);

	sendto(c,sir,sizeof(sir),0,(struct sockaddr *) &server,sizeof(server));
	sendto(c,&i,sizeof(i),0,(struct sockaddr *) &server,sizeof(server));
	sendto(c,&l,sizeof(l),0,(struct sockaddr *) &server,sizeof(server));

	recvfrom(c,subsir,sizeof(subsir),0,(struct sockaddr *) &server,&server_dim);

	printf("Subsirul: %s",subsir);

	close(c);
}
