#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include<string.h>

int main() {
    int c;
    struct sockaddr_in server;
    int number;
    int is_prime_number;

    c = socket(AF_INET, SOCK_DGRAM, 0);
    if (c < 0) {
        perror("Eroare la crearea socketului client");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(1234);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("Introduceți un număr: ");
    scanf("%d", &number);

    number = htonl(number);
    sendto(c, &number, sizeof(number), 0, (struct sockaddr *)&server, sizeof(server));
    recvfrom(c, &is_prime_number, sizeof(is_prime_number), 0, NULL, NULL);

    printf("Numărul %d %s este prim.\n", ntohl(number), is_prime_number ? "" : "nu ");

    close(c);
    return 0;
}
