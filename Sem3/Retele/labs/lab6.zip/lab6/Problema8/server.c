#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <stdint.h>

uint16_t cmmdc(uint16_t a, uint16_t b) {
    while (b != 0) {
        uint16_t r = a % b;
        a = b;
        b = r;
    }
    return a;
}

uint16_t cmmmc(uint16_t a, uint16_t b) {
    return (a / cmmdc(a, b)) * b;
}

int main() {
    int s;
    struct sockaddr_in server, client;
    socklen_t client_len = sizeof(client);
    uint16_t num1, num2;
    uint16_t cmmdc_result, cmmmc_result;

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) {
        perror("Eroare la crearea socketului server");
        return 1;
    }

    memset(&server,0,sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(1234);
    server.sin_addr.s_addr = INADDR_ANY;

    if (bind(s, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("Eroare la bind");
        close(s);
        return 1;
    }

    printf("Serverul ascultă pe portul 1234...\n");

    while (1) {
        recvfrom(s, &num1, sizeof(num1), 0, (struct sockaddr *)&client, &client_len);
        recvfrom(s, &num2, sizeof(num2), 0, (struct sockaddr *)&client, &client_len);

        num1 = ntohs(num1);
        num2 = ntohs(num2);

        cmmdc_result = htons(cmmdc(num1, num2));
        cmmmc_result = htons(cmmmc(num1, num2));

        sendto(s, &cmmdc_result, sizeof(cmmdc_result), 0, (struct sockaddr *)&client, client_len);
        sendto(s, &cmmmc_result, sizeof(cmmmc_result), 0, (struct sockaddr *)&client, client_len);
    }

    close(s);
    return 0;
}
