#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdint.h>

int main() {
    int c;
    struct sockaddr_in server;
    uint16_t num1, num2;
    uint16_t cmmdc_result, cmmmc_result;

    c = socket(AF_INET, SOCK_DGRAM, 0);
    if (c < 0) {
        perror("Eroare la crearea socketului client");
        return 1;
    }

    memset(&server,0,sizeof(server));;
    server.sin_family = AF_INET;
    server.sin_port = htons(1234);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("Introduceti primul numar: ");
    scanf("%hu", &num1);
    printf("Introduceti al doilea numar: ");
    scanf("%hu", &num2);

    num1 = htons(num1);
    num2 = htons(num2);

    sendto(c, &num1, sizeof(num1), 0, (struct sockaddr *)&server, sizeof(server));
    sendto(c, &num2, sizeof(num2), 0, (struct sockaddr *)&server, sizeof(server));

    recvfrom(c, &cmmdc_result, sizeof(cmmdc_result), 0, NULL, NULL);
    recvfrom(c, &cmmmc_result, sizeof(cmmmc_result), 0, NULL, NULL);

    cmmdc_result = ntohs(cmmdc_result);
    cmmmc_result = ntohs(cmmmc_result);

    printf("CMMDC: %hu\n", cmmdc_result);
    printf("CMMMC: %hu\n", cmmmc_result);

    close(c);
    return 0;
}
