#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LEN 100

int main() {
    int s;
    struct sockaddr_in server, client;
    int c, l;
    uint16_t sir1[MAX_LEN], sir2[MAX_LEN], sir_rez[MAX_LEN];
    uint16_t n1, n2, len_rez;

    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        printf("Eroare la crearea socketului server\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;

    if (bind(s, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la bind\n");
        return 1;
    }

    listen(s, 5);

    l = sizeof(client);
    memset(&client, 0, sizeof(client));

    while (1) {
        c = accept(s, (struct sockaddr *) &client, &l);
        printf("S-a conectat un client.\n");

        recv(c, &n1, sizeof(n1), MSG_WAITALL);
        n1 = ntohs(n1);

        recv(c, sir1, n1 * sizeof(uint16_t), MSG_WAITALL);

        recv(c, &n2, sizeof(n2), MSG_WAITALL);
        n2 = ntohs(n2);

        recv(c, sir2, n2 * sizeof(uint16_t), MSG_WAITALL);

        len_rez = 0;
        for (int i = 0; i < n1; i++) {
            int found = 0;
            for (int j = 0; j < n2; j++) {
                if (sir1[i] == sir2[j]) {
                    found = 1;
                    break;
                }
            }
            if (!found) {
                sir_rez[len_rez++] = sir1[i];
            }
        }

        uint16_t net_len_rez = htons(len_rez);
        send(c, &net_len_rez, sizeof(net_len_rez), 0);
        if (len_rez > 0) {
            send(c, sir_rez, len_rez * sizeof(uint16_t), 0);
        }

        close(c);
    }

    close(s);
}
