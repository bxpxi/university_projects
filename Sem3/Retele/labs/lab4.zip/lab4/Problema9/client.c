#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>

#define MAX_LEN 100

int main() {
    int c;
    struct sockaddr_in server;
    uint16_t n1, n2;
    uint16_t sir1[MAX_LEN], sir2[MAX_LEN];
    uint16_t sir_rez[MAX_LEN];
    uint16_t len_rez;

    c = socket(AF_INET, SOCK_STREAM, 0);
    if (c < 0) {
        printf("Eroare la crearea socketului client\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(c, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la conectarea la server\n");
        return 1;
    }

    printf("Introduceti numarul de elemente din primul sir: ");
    scanf("%hu", &n1);

    printf("Introduceti elementele din primul sir:\n");
    for (int i = 0; i < n1; i++) {
        scanf("%hu", &sir1[i]);
    }

    printf("Introduceti numarul de elemente din al doilea sir: ");
    scanf("%hu", &n2);

    printf("Introduceti elementele din al doilea sir:\n");
    for (int i = 0; i < n2; i++) {
        scanf("%hu", &sir2[i]);
    }

    uint16_t net_n1 = htons(n1);
    uint16_t net_n2 = htons(n2);

    send(c, &net_n1, sizeof(net_n1), 0);
    send(c, sir1, n1 * sizeof(uint16_t), 0);

    send(c, &net_n2, sizeof(net_n2), 0);
    send(c, sir2, n2 * sizeof(uint16_t), 0);

    recv(c, &len_rez, sizeof(len_rez), MSG_WAITALL);
    len_rez = ntohs(len_rez);

    if (len_rez > 0) {
        recv(c, sir_rez, len_rez * sizeof(uint16_t), MSG_WAITALL);
        printf("Numerele care se regasesc in primul sir dar nu si in al doilea sunt:\n");
        for (int i = 0; i < len_rez; i++) {
            printf("%hu ", sir_rez[i]);
        }
        printf("\n");
    } else {
        printf("Nu exista numere in primul sir care sa nu fie in al doilea.\n");
    }

    close(c);
    return 0;
}
