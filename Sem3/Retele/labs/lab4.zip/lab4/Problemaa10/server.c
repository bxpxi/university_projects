#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LEN 100

int main() {
    int s;
    struct sockaddr_in server, client;
    int c, l;

    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        printf("Eroare la crearea socketului server\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;

    if (bind(s, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la bind\n");
        return 1;
    }

    listen(s, 5);

    l = sizeof(client);
    memset(&client, 0, sizeof(client));

    while (1) {
        char sir1[MAX_LEN], sir2[MAX_LEN];
        uint16_t len1, len2;
        int frecventa[256] = {0};
        char caracter_comun = '\0';
        uint16_t numar_aparitii = 0;

        c = accept(s, (struct sockaddr *) &client, &l);
        printf("S-a conectat un client.\n");

        recv(c, &len1, sizeof(len1), 0);
        len1 = ntohs(len1);
        recv(c, sir1, len1, 0);
        sir1[len1] = '\0';

        recv(c, &len2, sizeof(len2), 0);
        len2 = ntohs(len2);
        recv(c, sir2, len2, 0);
        sir2[len2] = '\0';

        int lungime_minima = (len1 < len2) ? len1 : len2;

        for (int i = 0; i < lungime_minima; i++) {
            if (sir1[i] == sir2[i]) {
                frecventa[(unsigned char)sir1[i]]++;
            }
        }

        for (int i = 0; i < 256; i++) {
            if (frecventa[i] > numar_aparitii) {
                numar_aparitii = frecventa[i];
                caracter_comun = i;
            }
        }

        numar_aparitii = htons(numar_aparitii);
        send(c, &caracter_comun, sizeof(caracter_comun), 0);
        send(c, &numar_aparitii, sizeof(numar_aparitii), 0);

        close(c);
    }

    return 0;
}
