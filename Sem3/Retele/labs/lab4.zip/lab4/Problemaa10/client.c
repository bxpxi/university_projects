#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LEN 100

void elimina_spatii(char *sir) {
    int i, j = 0;
    for (i = 0; sir[i] != '\0'; i++) {
        if (sir[i] != ' ') {
            sir[j++] = sir[i];
        }
    }
    sir[j] = '\0';
}

int main() {
    int c;
    struct sockaddr_in server;
    char sir1[MAX_LEN], sir2[MAX_LEN];
    uint16_t len1, len2;
    char caracter_comun;
    uint16_t numar_aparitii;

    c = socket(AF_INET, SOCK_STREAM, 0);
    if (c < 0) {
        printf("Eroare la crearea socketului client\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(c, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la conectarea la server\n");
        return 1;
    }

    printf("Introduceti primul sir: ");
    fgets(sir1, MAX_LEN, stdin);
    len1 = strlen(sir1);
    if (sir1[len1 - 1] == '\n') sir1[--len1] = '\0';

    printf("Introduceti al doilea sir: ");
    fgets(sir2, MAX_LEN, stdin);
    len2 = strlen(sir2);
    if (sir2[len2 - 1] == '\n') sir2[--len2] = '\0';

    elimina_spatii(sir1);
    elimina_spatii(sir2);

    len1 = strlen(sir1);
    len2 = strlen(sir2);

    uint16_t net_len1 = htons(len1);
    uint16_t net_len2 = htons(len2);
    send(c, &net_len1, sizeof(net_len1), 0);
    send(c, sir1, len1, 0);
    send(c, &net_len2, sizeof(net_len2), 0);
    send(c, sir2, len2, 0);

    recv(c, &caracter_comun, sizeof(caracter_comun), MSG_WAITALL);
    recv(c, &numar_aparitii, sizeof(numar_aparitii), MSG_WAITALL);
    numar_aparitii = ntohs(numar_aparitii);

    if (numar_aparitii > 0) {
        printf("Caracterul comun care apare cel mai des pe aceleasi pozitii: '%c'\n", caracter_comun);
        printf("Numarul de aparitii: %hu\n", numar_aparitii);
    } else {
        printf("Nu exista caractere comune pe aceleasi pozitii.\n");
    }

    close(c);
}
