#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LEN 1000

int main() {
    int s;
    struct sockaddr_in server, client;
    int c, l;
    char sir[MAX_LEN];
    char caracter;
    uint16_t len_sir, num_positions = 0;
    uint16_t positions[MAX_LEN];

    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        printf("Eroare la crearea socketului server\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;

    if (bind(s, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la bind\n");
        return 1;
    }

    listen(s, 5);

    l = sizeof(client);
    memset(&client, 0, sizeof(client));

    while (1) {
        c = accept(s, (struct sockaddr *) &client, &l);
        printf("S-a conectat un client.\n");

        recv(c, &len_sir, sizeof(len_sir), MSG_WAITALL);
        len_sir = ntohs(len_sir);

        recv(c, sir, len_sir, MSG_WAITALL);
        sir[len_sir] = '\0';

        recv(c, &caracter, sizeof(caracter), MSG_WAITALL);

        num_positions = 0;
        for (int i = 0; i < len_sir; i++) {
            if (sir[i] == caracter) {
                positions[num_positions++] = htons(i);
            }
        }

        uint16_t net_num_positions = htons(num_positions);
        send(c, &net_num_positions, sizeof(net_num_positions), 0);

        if (num_positions > 0) {
            send(c, positions, num_positions * sizeof(uint16_t), 0);
        }

        close(c);
    }

    close(s);
}
