#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>

#define MAX_LEN 1000

int main() {
    int c;
    struct sockaddr_in server;
    char sir[MAX_LEN];
    char caracter;
    uint16_t num_positions;
    uint16_t positions[MAX_LEN];

    c = socket(AF_INET, SOCK_STREAM, 0);
    if (c < 0) {
        printf("Eroare la crearea socketului client\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(c, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la conectarea la server\n");
        return 1;
    }

    printf("Introduceti sirul de caractere: ");
    fgets(sir, MAX_LEN, stdin);

    int len_sir = strlen(sir);
    if (sir[len_sir - 1] == '\n') {
        sir[len_sir - 1] = '\0';
        len_sir--;
    }

    printf("Introduceti caracterul: ");
    scanf(" %c", &caracter);

    uint16_t net_len_sir = htons(len_sir);
    send(c, &net_len_sir, sizeof(net_len_sir), 0);
    send(c, sir, len_sir, 0);

    send(c, &caracter, sizeof(caracter), 0);

    recv(c, &num_positions, sizeof(num_positions), MSG_WAITALL);
    num_positions = ntohs(num_positions);

    if (num_positions > 0) {
        recv(c, positions, num_positions * sizeof(uint16_t), MSG_WAITALL);
        printf("Caracterul '%c' se regaseste la pozitiile: ", caracter);
        for (int i = 0; i < num_positions; i++) {
            printf("%hu ", ntohs(positions[i]));
        }
        printf("\n");
    } else {
        printf("Caracterul '%c' nu a fost gasit in sir.\n", caracter);
    }

    close(c);
}
