#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LEN 1000

int main() {
    int s;
    struct sockaddr_in server, client;
    int c, l;
    char sir[MAX_LEN];
    char subsir[MAX_LEN];
    uint16_t len_sir, i, l_subsir;

    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        printf("Eroare la crearea socketului server\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;

    if (bind(s, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la bind\n");
        return 1;
    }

    listen(s, 5);

    l = sizeof(client);
    memset(&client, 0, sizeof(client));

    while (1) {
        c = accept(s, (struct sockaddr *) &client, &l);
        printf("S-a conectat un client.\n");

        recv(c, &len_sir, sizeof(len_sir), MSG_WAITALL);
        len_sir = ntohs(len_sir);

        recv(c, sir, len_sir, MSG_WAITALL);
        sir[len_sir] = '\0';

        recv(c, &i, sizeof(i), MSG_WAITALL);
        recv(c, &l_subsir, sizeof(l_subsir), MSG_WAITALL);
        i = ntohs(i);
        l_subsir = ntohs(l_subsir);

        if (i + l_subsir > len_sir) {
            l_subsir = len_sir - i;
        }

        strncpy(subsir, sir + i, l_subsir);
        send(c, subsir, l_subsir, 0);

        close(c);
    }

    close(s);
}
