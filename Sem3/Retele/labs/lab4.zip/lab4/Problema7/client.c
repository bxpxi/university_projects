#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>

#define MAX_LEN 1000

int main() {
    int c;
    struct sockaddr_in server;
    char sir[MAX_LEN];
    uint16_t i, l;
    char subsir[MAX_LEN];

    c = socket(AF_INET, SOCK_STREAM, 0);
    if (c < 0) {
        printf("Eroare la crearea socketului client\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(c, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la conectarea la server\n");
        return 1;
    }

    printf("Introduceti sirul de caractere: ");
    fgets(sir, MAX_LEN, stdin);

    int len_sir = strlen(sir);
    if (sir[len_sir - 1] == '\n') {
        sir[len_sir - 1] = '\0';
        len_sir--;
    }

    printf("Introduceti pozitia de inceput i: ");
    scanf("%hu", &i);
    printf("Introduceti lungimea subsirului l: ");
    scanf("%hu", &l);

    uint16_t net_len_sir = htons(len_sir);
    send(c, &net_len_sir, sizeof(net_len_sir), 0);
    send(c, sir, len_sir, 0);

    uint16_t net_i = htons(i);
    uint16_t net_l = htons(l);
    send(c, &net_i, sizeof(net_i), 0);
    send(c, &net_l, sizeof(net_l), 0);

    recv(c, subsir, l, MSG_WAITALL);
    subsir[l] = '\0';

    printf("Subsirul este: %s\n", subsir);

    close(c);
}
