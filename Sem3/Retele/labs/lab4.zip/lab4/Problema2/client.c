#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>

#define MAX_LEN 1000

int main() {
    int c;
    struct sockaddr_in server;
    char sir[MAX_LEN];
    uint16_t numar_spatii;

    c = socket(AF_INET, SOCK_STREAM, 0);
    if (c < 0) {
        printf("Eroare la crearea socketului client\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(c, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la conectarea la server\n");
        return 1;
    }

    printf("Introduceti sirul de caractere: ");
    fgets(sir, MAX_LEN, stdin);

    size_t len = strlen(sir);
    if (len > 0 && sir[len - 1] == '\n') {
        sir[len - 1] = '\0';
        len--;
    }

    uint16_t net_len = htons(len);
    send(c, &net_len, sizeof(net_len), 0);

    send(c, sir, len, 0);

    recv(c, &numar_spatii, sizeof(numar_spatii), MSG_WAITALL);
    numar_spatii = ntohs(numar_spatii);

    printf("Numarul de caractere spatiu din sir este: %hu\n", numar_spatii);

    close(c);
    return 0;
}
