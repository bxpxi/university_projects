#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>

#define MAX_NUMBERS 100

int main() {
    int c;
    struct sockaddr_in server;
    int numbers[MAX_NUMBERS];
    int count;
    uint16_t sum;

    c = socket(AF_INET, SOCK_STREAM, 0);
    if (c < 0) {
        printf("Eroare la crearea socketului client\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(c, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la conectarea la server\n");
        return 1;
    }

    printf("Introduceti numarul de elemente din sir: ");
    scanf("%d", &count);

    printf("Introduceti elementele sirului: ");
    for (int i = 0; i < count; i++) {
        scanf("%d", &numbers[i]);
    }

    send(c, &count, sizeof(count), 0);
    send(c, numbers, count * sizeof(int), 0);

    recv(c, &sum, sizeof(sum), MSG_WAITALL);
    sum = ntohs(sum);

    printf("Suma numerelor este: %hu\n", sum);

    close(c);
}
