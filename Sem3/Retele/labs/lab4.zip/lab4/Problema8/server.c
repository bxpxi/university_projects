#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LEN 100

int este_comun(uint16_t *comune, uint16_t valoare, int nc) {
    for (int i = 0; i < nc; i++) {
        if (comune[i] == valoare) {
            return 1;
        }
    }
    return 0;
}

int main() {
    int s;
    struct sockaddr_in server, client;
    int c, l;

    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        printf("Eroare la crearea socketului server\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;

    if (bind(s, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la bind\n");
        return 1;
    }

    listen(s, 5);

    l = sizeof(client);
    memset(&client, 0, sizeof(client));

    while (1) {
        uint16_t sir1[MAX_LEN], sir2[MAX_LEN], comune[MAX_LEN];
        uint16_t n1, n2, nc = 0;

        c = accept(s, (struct sockaddr *) &client, &l);
        printf("S-a conectat un client.\n");

        recv(c, &n1, sizeof(n1), MSG_WAITALL);
        n1 = ntohs(n1);
        recv(c, sir1, sizeof(uint16_t) * n1, MSG_WAITALL);

        recv(c, &n2, sizeof(n2), MSG_WAITALL);
        n2 = ntohs(n2);
        recv(c, sir2, sizeof(uint16_t) * n2, MSG_WAITALL);

        for (int i = 0; i < n1; i++) {
            for (int j = 0; j < n2; j++) {
                if (sir1[i] == sir2[j] && !este_comun(comune, sir1[i], nc)) {
                    comune[nc++] = htons(sir1[i]);
                }
            }
        }

        uint16_t nc1 = htons(nc);
        send(c, &nc1, sizeof(nc1), 0);
        send(c, comune, sizeof(uint16_t) * nc, 0);

        close(c);
    }
}
