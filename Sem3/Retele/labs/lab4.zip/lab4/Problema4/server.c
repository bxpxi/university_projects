#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LEN 1000

int main() {
    int s;
    struct sockaddr_in server, client;
    int c, l;
    char sir1[MAX_LEN], sir2[MAX_LEN], sir_interclasat[MAX_LEN * 2];
    uint16_t len1, len2, len_interclasat;

    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        printf("Eroare la crearea socketului server\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;

    if (bind(s, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la bind\n");
        return 1;
    }

    listen(s, 5);

    l = sizeof(client);
    memset(&client, 0, sizeof(client));

    while (1) {
        c = accept(s, (struct sockaddr *) &client, &l);
        printf("S-a conectat un client.\n");

        recv(c, &len1, sizeof(len1), MSG_WAITALL);
        recv(c, &len2, sizeof(len2), MSG_WAITALL);
        len1 = ntohs(len1);
        len2 = ntohs(len2);

        recv(c, sir1, len1, MSG_WAITALL);
        recv(c, sir2, len2, MSG_WAITALL);
        sir1[len1] = '\0';
        sir2[len2] = '\0';

        int i = 0, j = 0, k = 0;
        while (i < len1 && j < len2) {
            if (sir1[i] <= sir2[j]) {
                sir_interclasat[k++] = sir1[i++];
            } else {
                sir_interclasat[k++] = sir2[j++];
            }
        }

        while (i < len1) {
            sir_interclasat[k++] = sir1[i++];
        }

        while (j < len2) {
            sir_interclasat[k++] = sir2[j++];
        }

        len_interclasat = k;
        sir_interclasat[len_interclasat] = '\0';

        uint16_t net_len_interclasat = htons(len_interclasat);
        send(c, &net_len_interclasat, sizeof(net_len_interclasat), 0);

        send(c, sir_interclasat, len_interclasat, 0);

        close(c);
    }

    close(s);
}
