#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>

#define MAX_LEN 1000

int main() {
    int c;
    struct sockaddr_in server;
    char sir1[MAX_LEN], sir2[MAX_LEN], sir_interclasat[MAX_LEN * 2];
    uint16_t len1, len2, len_interclasat;

    c = socket(AF_INET, SOCK_STREAM, 0);
    if (c < 0) {
        printf("Eroare la crearea socketului client\n");
        return 1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(c, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la conectarea la server\n");
        return 1;
    }

    printf("Introduceti primul sir de caractere ordonat: ");
    fgets(sir1, MAX_LEN, stdin);
    len1 = strlen(sir1);
    if (sir1[len1 - 1] == '\n') {
        sir1[len1 - 1] = '\0';
        len1--;
    }

    printf("Introduceti al doilea sir de caractere ordonat: ");
    fgets(sir2, MAX_LEN, stdin);
    len2 = strlen(sir2);
    if (sir2[len2 - 1] == '\n') {
        sir2[len2 - 1] = '\0';
        len2--;
    }

    uint16_t net_len1 = htons(len1);
    uint16_t net_len2 = htons(len2);
    send(c, &net_len1, sizeof(net_len1), 0);
    send(c, &net_len2, sizeof(net_len2), 0);

    send(c, sir1, len1, 0);
    send(c, sir2, len2, 0);

    recv(c, &len_interclasat, sizeof(len_interclasat), MSG_WAITALL);
    len_interclasat = ntohs(len_interclasat);

    recv(c, sir_interclasat, len_interclasat, MSG_WAITALL);
    sir_interclasat[len_interclasat] = '\0';

    printf("Sirul interclasat este: %s\n", sir_interclasat);

    close(c);
}
