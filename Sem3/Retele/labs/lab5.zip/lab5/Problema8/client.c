#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LEN 100

int main(int argc, char* argv[]) {
    if(argc < 3) {
	printf("Introduceti si adresa IP, respectiv portul.\n");
	return 1;
    }

    int c;
    struct sockaddr_in server;
    uint16_t sir1[MAX_LEN], sir2[MAX_LEN], comune[MAX_LEN];
    uint16_t n1, n2, nc;

    c = socket(AF_INET, SOCK_STREAM, 0);
    if (c < 0) {
        printf("Eroare la crearea socketului client\n");
        return 1;
    }


    memset(&server, 0, sizeof(server));
    server.sin_port = htons(atoi(argv[2]));
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr(argv[1]);

    if (connect(c, (struct sockaddr *) &server, sizeof(server)) < 0) {
        printf("Eroare la conectarea la server\n");
        return 1;
    }

    printf("Introduceti numarul de elemente din primul sir: ");
    scanf("%hu", &n1);
    printf("Introduceti elementele din primul sir:\n");
    for (int i = 0; i < n1; i++) {
        scanf("%hu", &sir1[i]);
    }

    printf("Introduceti numarul de elemente din al doilea sir: ");
    scanf("%hu", &n2);
    printf("Introduceti elementele din al doilea sir:\n");
    for (int i = 0; i < n2; i++) {
        scanf("%hu", &sir2[i]);
    }

    uint16_t n1_net = htons(n1);
    uint16_t n2_net = htons(n2);

    send(c, &n1_net, sizeof(n1_net), 0);
    send(c, sir1, sizeof(uint16_t) * n1, 0);
    send(c, &n2_net, sizeof(n2_net), 0);
    send(c, sir2, sizeof(uint16_t) * n2, 0);

    recv(c, &nc, sizeof(nc), 0);
    nc = ntohs(nc);
    recv(c, comune, sizeof(uint16_t) * nc, 0);

    if (nc > 0) {
        printf("Numerele comune sunt: ");
        for (int i = 0; i < nc; i++) {
            printf("%hu ", comune[i]);
        }
        printf("\n");
    } else {
        printf("Nu exista elemente comune.\n");
    }

    close(c);
}
