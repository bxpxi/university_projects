import java.io.*;
import java.net.*;

public class Client {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int PORT = 1234;

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_ADDRESS, PORT);
             DataOutputStream out = new DataOutputStream(socket.getOutputStream());
             DataInputStream in = new DataInputStream(socket.getInputStream());
             BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in))) {

            System.out.print("Introdu primul sir de numere (separate prin virgula): ");
            String line1 = userInput.readLine();
            String[] numbers1 = line1.split(",");
            int n1 = numbers1.length;

            out.writeShort(n1);
            for (String number : numbers1) {
                out.writeShort(Short.parseShort(number.trim()));
            }

            System.out.print("Introdu al doilea sir de numere (separate prin virgula): ");
            String line2 = userInput.readLine();
            String[] numbers2 = line2.split(",");
            int n2 = numbers2.length;

            out.writeShort(n2);
            for (String number : numbers2) {
                out.writeShort(Short.parseShort(number.trim()));
            }

            int commonCount = in.readShort();
            System.out.println("Numărul de numere comune: " + commonCount);

            System.out.print("Numerele comune: ");
            for (int i = 0; i < commonCount; i++) {
                System.out.print(in.readShort() + " ");
            }
            System.out.println();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
