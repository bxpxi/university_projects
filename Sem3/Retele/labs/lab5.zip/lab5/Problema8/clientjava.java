import java.net.*;
import java.io.*;
import java.util.Scanner;

public class ClientJava {
	public static void main(String[] args) {
		Socket c = new Socket("127.0.0.1", 1234);
		DataInputStream socketIn = new DataInputStream(c.getInputStream());
		DataOutputStream socketOut = new DataOutputStream(c.getOutputStream());
		Scanner scanner = new Scanner(System.in);

		System.out.println("Introduceti numarul de elemente din primul sir: ");
		int n1 = scanner.nextInt();
		int[] sir1 = new int[n1];
		System.out.println("Introduceti elementele din primul sir: ");
		for(int i=0;i<n1;i++) {
			sir1[i] = scanner.nextInt();
		}

		System.out.println("Introduceti numarul de elemente din al doilea sir: ");
		int n2 = scanner.nextInt();
		int[] sir2 = new int[n2];
		System.out.println("Introduceti elementele din al doilea sir: ");
		for(int i=0;i<n2;i++) {
			sir2[i] = scanner.nextInt();
		}

		socketOut.writeShort(n1);
		for(int val :  sir1) {
			socketOut.writeShort(val);
		}

		socketOut.writeShort(n2);
		for(int val : sir2) {
			socketOut.writeShort(val);
		}

		int nc = socketIn.readUnsignedShort();
		if(nc>0){
			System.out.println("Numerele comune sunt: ");
			for(int i=0;i<nc;i++) {
				int com = socketIn.readUnsignedShort();
				System.out.println(com + " ");
			}
		}else{
			System.out.println("Nu exista elemente comune.");
		}

		scanner.close();
		c.close();
	}
}
