package com.example.rezerva.controller;

import com.example.rezerva.domain.*;
import com.example.rezerva.service.Service;

import com.example.rezerva.utils.TableViewCustom;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class TablePage extends VBox {
    private Service srv;

    private Table table;
    private List<TableViewCustom> tables=new ArrayList<>();

    public TablePage(Service srv, Table table){
        this.srv=srv;
        this.table=table;

        buildEverything();
    }

    private void buildEverything() {
        buildTables();
    }

    private void buildTables() {
        // Grupează produsele după categorie
        Map<String, List<MenuItem>> groupedMenu = new HashMap<>();
        for (MenuItem mi : srv.getMenuItems()) {
            groupedMenu.computeIfAbsent(mi.getCategory(), k -> new ArrayList<>()).add(mi);
        }

        // Afișează fiecare categorie și produsele sale
        for (Map.Entry<String, List<MenuItem>> entry : groupedMenu.entrySet()) {
            String category = entry.getKey();
            List<MenuItem> items = entry.getValue();

            // Afișează titlul categoriei
            Label label = new Label(category);
            getChildren().add(label);

            // Creează un tabel pentru produsele din această categorie
            List<String> headere = new ArrayList<>();
            headere.add("Produs");
            headere.add("Pret");

            Function<MenuItem, String> f1 = MenuItem::getItem;  // Numele produsului
            Function<MenuItem, String> f2 = mi -> mi.getPrice().toString() + " " + mi.getCurrency();  // Pretul

            TableViewCustom<MenuItem> tabel = new TableViewCustom<>(items, headere, f1, f2);
            getChildren().add(tabel);
            tables.add(tabel);
        }

        // Creare buton și onAction pentru plasarea comenzii
        Button placeOrder = new Button("Place Order");
        getChildren().add(placeOrder);
        placeOrder.setOnAction(event -> {
            List<MenuItem> selectedItems = new ArrayList<>();
            for (TableViewCustom<MenuItem> tabel : tables) {
                List<MenuItem> selected = tabel.getSelectedElements();
                System.out.println("Produse selectate din tabel: " + selected);
                selectedItems.addAll(selected);
            }
            System.out.println("Toate produsele selectate: " + selectedItems);
            handleOrder(table.getId(), selectedItems);
        });
    }

    public void show(){
        Scene scene = new Scene(this, 300, 500);
        Stage stage = new Stage();

        //titlul ferestrei
        stage.setTitle("ID table: "+table.getId().toString());
        stage.setScene(scene);

        stage.show();
    }

    public void handleOrder(Integer idTable, List<MenuItem> items){
        Integer id;
        List<Order> all=srv.getOrders();
        id=all.size();

        Order order=new Order(id,idTable, LocalDateTime.now(), Status.PLACED);
        srv.adaugaOrder(order);

        for(MenuItem mi: items){
            OrderItem oi = new OrderItem(id,mi.getId());
            srv.adaugaOrderItem(oi);
        }

    }
}