package com.example.rezerva.utils.events;

public interface Event {
}
