package com.example.rezerva.controller;

import com.example.rezerva.domain.MenuItem;
import com.example.rezerva.domain.Order;
import com.example.rezerva.service.Service;
import com.example.rezerva.utils.observer.Observer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class StaffController implements Observer<Order> {
    @FXML
    private TableView<Order> ordersTable;

    @FXML
    private TableColumn<Order, Integer> tableIdColumn;

    @FXML
    private TableColumn<Order, LocalDateTime> dateColumn;

    @FXML
    private TableColumn<Order, String> itemsColumn;

    private Service service;

    public void setService(Service service) {
        this.service = service;
        service.addObserver(this);
        initializeTable();
        loadOrders();
    }

    private void initializeTable() {
        // Configurează coloanele tabelului
        tableIdColumn.setCellValueFactory(new PropertyValueFactory<>("idTable"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("data"));
        itemsColumn.setCellValueFactory(cellData -> {
            Order order = cellData.getValue();
            List<MenuItem> items = service.getMenuItemsForOrder(order.getId());
            String itemsString = String.join(", ", items.stream()
                    .map(MenuItem::getItem)
                    .toList());
            return new javafx.beans.property.SimpleStringProperty(itemsString);
        });
    }

    private void loadOrders() {
        // Încarcă comenzile plasate în tabel
        Map<Order, List<MenuItem>> ordersWithItems = service.getOrdersWithItems();
        ObservableList<Order> data = FXCollections.observableArrayList(ordersWithItems.keySet());
        data.sort(Comparator.comparing(Order::getData));  // Sortează comenzile după dată
        ordersTable.setItems(data);
    }

    public void updateTable(Order newOrder) {
        // Adaugă noua comandă în tabel
        ordersTable.getItems().add(newOrder);
    }

    @Override
    public void update(Order newOrder) {
        // Adaugă noua comandă în tabel și sortează comenzile după dată
        ordersTable.getItems().add(newOrder);
        ordersTable.getItems().sort(Comparator.comparing(Order::getData));
    }
}