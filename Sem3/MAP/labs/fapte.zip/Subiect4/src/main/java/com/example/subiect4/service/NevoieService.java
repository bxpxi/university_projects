package com.example.subiect4.service;

import com.example.subiect4.database.NevoieDataBaseRepository;
import com.example.subiect4.domain.Nevoie;
import com.example.subiect4.utils.events.ChangeEventType;
import com.example.subiect4.utils.events.NevoieEntityChangeEvent;
import com.example.subiect4.utils.observer.Observable;
import com.example.subiect4.utils.observer.Observer;

import java.util.ArrayList;
import java.util.List;

public class NevoieService implements Observable<NevoieEntityChangeEvent> {

    private final NevoieDataBaseRepository nevoieDataBaseRepository;

    private List<Observer<NevoieEntityChangeEvent>> observers = new ArrayList<>();

    public NevoieService(NevoieDataBaseRepository nevoieDataBaseRepository){
        this.nevoieDataBaseRepository = nevoieDataBaseRepository;
    }

    public List<Nevoie> getAllNevoi(){
        return nevoieDataBaseRepository.getAllNevoi();
    }

    public Nevoie updateNevoie(long idNevoie, long idPersoana) {
        return nevoieDataBaseRepository.updateNevoie(idNevoie, idPersoana);
    }

    public long getMaxId(){
        return nevoieDataBaseRepository.getMaxId();
    }

    public Nevoie adaugaNevoie(Nevoie nevoie) {
        Nevoie nevoie1 = nevoieDataBaseRepository.adaugaNevoie(nevoie);
        notifyObservers(new NevoieEntityChangeEvent(ChangeEventType.ADD, nevoie1));
        return nevoie1;
    }

    @Override
    public void addObserver(Observer<NevoieEntityChangeEvent> e) {
        observers.add(e);
    }

    @Override
    public void removeObserver(Observer<NevoieEntityChangeEvent> e) {
        observers.remove(e);
    }

    @Override
    public void notifyObservers(NevoieEntityChangeEvent t) {
        observers.forEach(x -> x.update(t));
    }
}
