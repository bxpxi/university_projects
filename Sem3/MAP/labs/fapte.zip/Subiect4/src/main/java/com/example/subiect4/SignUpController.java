package com.example.subiect4;

import com.example.subiect4.domain.Oras;
import com.example.subiect4.domain.Persoana;
import com.example.subiect4.service.PersoanaService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class SignUpController {


    private Stage logInStage;

    private Stage signUpStage;
    private LogInController logInController;
    private PersoanaService persoanaService;

    private final ObservableList<String> oraseModel = FXCollections.observableArrayList();

    @FXML
    private ComboBox<String> allOrase;
    @FXML
    private TextField nume;

    @FXML
    private TextField prenume;

    @FXML
    private TextField username;

    @FXML
    private PasswordField parola;

    @FXML
    private TextField strada;


    @FXML
    private TextField numarStrada;

    @FXML
    private TextField telefon;

    @FXML
    public void initialize(){
        allOrase.setItems(oraseModel);
    }
    @FXML
    public void onSignUpButtonClicked(){
        String numeP = nume.getText();
        String prenumeP = prenume.getText();
        String usernameP = username.getText();
        String parolaP = parola.getText();
        String stradaP = strada.getText();
        String numarStradaP = numarStrada.getText();
        String telefonP = telefon.getText();
        String oras = allOrase.getValue();

        Persoana persoana = new Persoana(numeP, prenumeP, usernameP, parolaP, Oras.valueOf(oras), stradaP, numarStradaP, telefonP);
        persoana.setId(persoanaService.getMaxId() + 1);


        if(!persoanaService.verifyIfAPersonExist(usernameP)) {
            persoanaService.addPersoana(persoana);
            signUpStage.close();
            logInController.setListaDePersoane();
            logInStage.show();
        }else{
            System.out.println("Persoana exista deja!");
        }
    }

    public void setPersoanaService(PersoanaService persoanaService) {
        this.persoanaService = persoanaService;
    }

    public void setAllOrase(){

        List<String> orase = new ArrayList<>();

        for(Oras oras : Oras.values()){
            orase.add(oras.name());
        }

        oraseModel.setAll(orase);

    }

    public void setLogInStage(Stage logInStage){
        this.logInStage = logInStage;
    }

    public void setSignUpStage(Stage signUpStage){
        this.signUpStage = signUpStage;
    }

    public void setLogInController(LogInController logInController){
        this.logInController = logInController;
    }

}
