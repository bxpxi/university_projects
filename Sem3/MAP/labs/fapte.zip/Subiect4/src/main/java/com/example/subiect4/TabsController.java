package com.example.subiect4;

import com.example.subiect4.domain.Nevoie;
import com.example.subiect4.domain.Persoana;
import com.example.subiect4.service.NevoieService;
import com.example.subiect4.service.PersoanaService;
import com.example.subiect4.utils.events.NevoieEntityChangeEvent;
import com.example.subiect4.utils.observer.Observable;
import com.example.subiect4.utils.observer.Observer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class TabsController implements Observer<NevoieEntityChangeEvent> {


    private Stage tabsStage;
    private final ObservableList<Nevoie> nevoiModel = FXCollections.observableArrayList();

    private final ObservableList<Nevoie> fapteBuneModel = FXCollections.observableArrayList();

    private NevoieService nevoieService;

    private PersoanaService persoanaService;

    private Persoana persoanaLogata;

    @FXML
    private TabPane tabs;
    @FXML
    private TableView<Nevoie> nevoiTable;

    @FXML
    private TableColumn<Nevoie, String> titlu;

    @FXML
    private TableColumn<Nevoie, String> descriere;

    @FXML
    private TableColumn<Nevoie, LocalDateTime> deadline;

    @FXML
    private TableColumn<Nevoie, Long> omInNevoie;

    @FXML
    private TableColumn<Nevoie, Long> omSalvator;

    @FXML
    private TableColumn<Nevoie, String> status;


    @FXML
    private TableView<Nevoie> fapteBuneTable;

    @FXML
    private TableColumn<Nevoie, String> titlu1;

    @FXML
    private TableColumn<Nevoie, String> descriere1;

    @FXML
    private TableColumn<Nevoie, LocalDateTime> deadline1;

    @FXML
    private TableColumn<Nevoie, Long> omInNevoie1;

    @FXML
    private TableColumn<Nevoie, Long> omSalvator1;

    @FXML
    private TableColumn<Nevoie, String> status1;


    @FXML
    public void initialize() {
        titlu.setCellValueFactory(new PropertyValueFactory<>("titlu"));
        descriere.setCellValueFactory(new PropertyValueFactory<>("descriere"));
        deadline.setCellValueFactory(new PropertyValueFactory<>("deadline"));
        omInNevoie.setCellValueFactory(new PropertyValueFactory<>("omInNevoie"));
        omSalvator.setCellValueFactory(new PropertyValueFactory<>("omSalvator"));
        status.setCellValueFactory(new PropertyValueFactory<>("status"));

        nevoiTable.setItems(nevoiModel);


        titlu1.setCellValueFactory(new PropertyValueFactory<>("titlu"));
        descriere1.setCellValueFactory(new PropertyValueFactory<>("descriere"));
        deadline1.setCellValueFactory(new PropertyValueFactory<>("deadline"));
        omInNevoie1.setCellValueFactory(new PropertyValueFactory<>("omInNevoie"));
        omSalvator1.setCellValueFactory(new PropertyValueFactory<>("omSalvator"));
        status1.setCellValueFactory(new PropertyValueFactory<>("status"));

        fapteBuneTable.setItems(fapteBuneModel);


    }

    @FXML
    public void onTabsPaneClicked() throws IOException {
        String ajutor = tabs.getSelectionModel().getSelectedItem().getText();

        if(ajutor.equals("Doresc sa fiu ajutat!")){
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("nevoie-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);

            Stage nevoieStage = new Stage();

            nevoieStage.setTitle("Nevoie");
            nevoieStage.setScene(scene);

            NevoieController nevoieController = fxmlLoader.getController();
            nevoieController.setNevoieService(nevoieService);
            nevoieController.setPersoanaLogata(persoanaLogata);
            nevoieController.setNevoieStage(nevoieStage);

            nevoieStage.show();

        }

    }


    @FXML
    public void onNevoiTableClicked(){
        Nevoie nevoie = nevoiTable.getSelectionModel().getSelectedItem();

        Nevoie nev = nevoieService.updateNevoie(nevoie.getId(), persoanaLogata.getId());

        if(nev != null){
            setNevoiTable();

            Alert message = new Alert(Alert.AlertType.CONFIRMATION);
            message.initOwner(tabsStage);
            message.setTitle("Sarcina atribuita!");
            message.setContentText("V-ati asumat responsabilitatea rezolvarii unei nevoi!!!");
            message.showAndWait();

            setFapteBuneTable();


        }else{
            System.out.println("NOOO");
        }

    }

    public void setNevoiTable() {

        List<Nevoie> nevoi = nevoieService.getAllNevoi();
        System.out.println("Nevoi din baza de date: " + nevoi);

        List<Nevoie> nevoiRez = new ArrayList<>();

        for (Nevoie nevoie : nevoi) {

            Persoana persoanaInNevoie = persoanaService.findOnePersoana(nevoie.getOmInNevoie());

            if (nevoie.getOmInNevoie() != persoanaLogata.getId() && persoanaInNevoie.getOras().toString().equals(persoanaLogata.getOras().toString())) {
                nevoiRez.add(nevoie);
            }
        }

        nevoiModel.setAll(nevoiRez);

    }

    public void setFapteBuneTable(){
        List<Nevoie> nevoi = nevoieService.getAllNevoi();
        List<Nevoie> fapteBune = new ArrayList<>();

        for(Nevoie nevoie : nevoi){
            if(nevoie.getStatus().equals("Erou gasit!")){
                fapteBune.add(nevoie);
            }
        }

        fapteBuneModel.setAll(fapteBune);

    }

    public void setNevoieService(NevoieService nevoieService) {
        this.nevoieService = nevoieService;
        this.nevoieService.addObserver(this);
    }

    public void setPersoanaService(PersoanaService persoanaService) {
        this.persoanaService = persoanaService;
    }

    public void setPersoanaLogata(Persoana persoanaLogata) {
        this.persoanaLogata = persoanaLogata;
    }

    public void setNevoieStage(Stage tabsStage){
        this.tabsStage = tabsStage;
    }

    @Override
    public void update(NevoieEntityChangeEvent nevoieEntityChangeEvent) {
        System.out.println("da");
        System.out.println(persoanaLogata.getId());
        setNevoiTable();
    }
}
