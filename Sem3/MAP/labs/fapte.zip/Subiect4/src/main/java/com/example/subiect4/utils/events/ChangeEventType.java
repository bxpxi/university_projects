package com.example.subiect4.utils.events;

public enum ChangeEventType {
    ADD, UPDATE, DELETE;
}
