package com.example.subiect4.domain;

public enum Oras {
    Campulung,
    Barcelona,
    Madrid,
    Dubai,
    Cluj
}
