rootProject.name = "curs3"

