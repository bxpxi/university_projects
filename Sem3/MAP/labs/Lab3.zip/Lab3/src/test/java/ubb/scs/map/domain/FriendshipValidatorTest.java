package ubb.scs.map.domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ubb.scs.map.domain.Friendship;
import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.domain.validators.FriendshipValidator;
import ubb.scs.map.domain.validators.UtilizatorValidator;
import ubb.scs.map.domain.validators.ValidationException;
import ubb.scs.map.domain.validators.Validator;
import ubb.scs.map.repository.memory.InMemoryRepository;

import static org.junit.jupiter.api.Assertions.*;

class FriendshipValidatorTest {
    private FriendshipValidator friendshipValidator;
    private InMemoryRepository<Long, Utilizator> utilizatorRepo;

    @BeforeEach
    void setUp() {
        utilizatorRepo = new InMemoryRepository<>(new UtilizatorValidator());
        Utilizator u1 = new Utilizator("John", "Doe");
        u1.setId(1L);
        utilizatorRepo.save(u1);
        Utilizator u2 = new Utilizator("Jane", "Smith");
        u2.setId(2L);
        utilizatorRepo.save(u2);
        friendshipValidator = new FriendshipValidator(utilizatorRepo);
    }

    @Test
    void testValidFriendship() {
        Friendship friendship = new Friendship(1L, 2L);
        assertDoesNotThrow(() -> friendshipValidator.validate(friendship));
    }

    @Test
    void testFriendshipWithNonExistingUser() {
        Friendship friendship = new Friendship(1L, 999L);
        ValidationException exception = assertThrows(ValidationException.class, () -> friendshipValidator.validate(friendship));
        assertEquals("The id doesn't exist.", exception.getMessage());
    }

//    @Test
//    void testFriendshipWithNullId() {
//        Friendship friendship = new Friendship(null, 2L);
//        ValidationException exception = assertThrows(ValidationException.class, () -> friendshipValidator.validate(friendship));
//        assertEquals("The id cannot be null.", exception.getMessage());
//    }

    @Test
    void testBothUsersDoNotExist() {
        Friendship friendship = new Friendship(999L, 888L);
        ValidationException exception = assertThrows(ValidationException.class, () -> friendshipValidator.validate(friendship));
        assertEquals("The id doesn't exist.", exception.getMessage());
    }
}
