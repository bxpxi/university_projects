package ubb.scs.map.domain;

import org.junit.jupiter.api.Test;
import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.domain.validators.UtilizatorValidator;
import ubb.scs.map.domain.validators.ValidationException;

import static org.junit.jupiter.api.Assertions.*;

class UtilizatorValidatorTest {

    UtilizatorValidator validator = new UtilizatorValidator();

    @Test
    void testValidUser() {
        Utilizator user = new Utilizator("John", "Doe");
        assertDoesNotThrow(() -> validator.validate(user));
    }

    @Test
    void testInvalidUser() {
        Utilizator invalidUser = new Utilizator("", "");
        Exception exception = assertThrows(ValidationException.class, () -> validator.validate(invalidUser));
        assertTrue(exception.getMessage().contains("First name cannot be null."));
    }
}
