package ubb.scs.map.domain.validators;

import ubb.scs.map.domain.Friendship;
import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.repository.memory.InMemoryRepository;

public class FriendshipValidator implements Validator<Friendship> {
    private InMemoryRepository<Long, Utilizator> repo;

    public FriendshipValidator(InMemoryRepository<Long, Utilizator> repo) {
        this.repo = repo;
    }

    @Override
    public void validate(Friendship friendship) throws ValidationException {
        Long id1 = friendship.getIdUser1();
        Long id2 = friendship.getIdUser2();

        if(id1 == null || id2 == null) {
            throw new ValidationException("The id cannot be null.");
        }

        Utilizator u1 = repo.findOne(id1);
        Utilizator u2 = repo.findOne(id2);

        if(u1 == null || u2 == null) {
            throw new ValidationException("The id doesn't exist.");
        }
    }
}
