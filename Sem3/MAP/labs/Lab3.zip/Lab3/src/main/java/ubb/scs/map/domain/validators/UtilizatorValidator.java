package ubb.scs.map.domain.validators;


import ubb.scs.map.domain.Utilizator;

public class UtilizatorValidator implements Validator<Utilizator> {
    @Override
    public void validate(Utilizator entity) throws ValidationException {
        String errorMessage = "";

        if(entity.getFirstName().isEmpty())
            errorMessage += "First name cannot be null.";
        if(entity.getLastName().isEmpty())
            errorMessage += "Last name cannot be null.";

        if(!errorMessage.isEmpty())
            throw new ValidationException(errorMessage);
    }
}
