package ubb.scs.map.service;

import ubb.scs.map.domain.Friendship;
import ubb.scs.map.domain.Utilizator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SocialCommunities {
    SocialNetwork socialNetwork;
    HashMap<Long, List<Long>> adjList;

    public SocialCommunities(SocialNetwork socialNetwork) {
        this.socialNetwork = socialNetwork;
    }

    /*
     * Depth-First Search (DFS) function that traverses the graph starting from a given vertex (user).
     * Marks the current vertex as visited and recursively visits all its unvisited neighbors.
     *
     * @param vf      - the ID of the user (vertex) from which the DFS starts
     * @param visited - a HashMap that keeps track of visited users
     */
//    void DFS(Long vf, HashMap<Long, Boolean> visited) {
//        visited.put(vf, true);
//        if(adjList.containsKey(vf)) {
//            for(Long x : adjList.get(vf))
//                if(!visited.containsKey(x))
//                    DFS(x, visited);
//        }
//    }

    void DFS(Long vf, HashMap<Long, Boolean> visited, List<Long> community) {
        visited.put(vf, true);
        community.add(vf);  // Adăugăm utilizatorul în comunitate
        if (adjList.containsKey(vf)) {
            for (Long x : adjList.get(vf)) {
                if (!visited.containsKey(x)) {
                    DFS(x, visited, community);
                }
            }
        }
    }

    /*
     * Counts the number of connected communities in the social network.
     * Uses DFS to explore each unvisited community.
     *
     * @return int - number of communities
     */
    public int connectedCommunities() {
        adjList = new HashMap<Long, List<Long>>();
        for(Utilizator user : socialNetwork.getUsers()){
            List<Long> friends = new ArrayList<>();
            for(Friendship friendship : socialNetwork.getFriendships()){
                if(friendship.getIdUser1().equals(user.getId())){
                    friends.add(friendship.getIdUser2());
                }
                if(friendship.getIdUser2().equals(user.getId())){
                    friends.add(friendship.getIdUser1());
                }
            }
            if(!friends.isEmpty())
                adjList.put(user.getId(), friends);
        }

        List<Long> ids = new ArrayList<>();
        for(Utilizator user : socialNetwork.getUsers()) {
            ids.add(user.getId());
        }

        int nr_communities = 0;
        HashMap<Long, Boolean> visited = new HashMap<Long, Boolean>();
        for(Long v : ids) {
            if(!visited.containsKey(v)){
                List<Long> community = new ArrayList<>();
                DFS(v, visited,community);
                if(community.size() >= 2)
                    nr_communities++;
            }
        }

        return nr_communities;
    }

    /*
     * Finds the largest community in the network.
     * Returns the list of user IDs in that community.
     *
     * @return List<Long> - user IDs of the largest community
     */
    public List<Long> mostSocialCommunity() {
        adjList = new HashMap<Long, List<Long>>();
        List<Long> max = new ArrayList<>();

        for(Utilizator user : socialNetwork.getUsers()) {
            List<Long> friends = new ArrayList<>();
            for(Friendship friendship : socialNetwork.getFriendships()){
                if(friendship.getIdUser1().equals(user.getId())){
                    friends.add(friendship.getIdUser2());
                }
                if(friendship.getIdUser2().equals(user.getId())){
                    friends.add(friendship.getIdUser1());
                }
            }
            if(!friends.isEmpty()){
                adjList.put(user.getId(), friends);
                if(max.size() < friends.size() + 1){
                    max = friends;
                    max.add(user.getId());
                }
            }
        }
        return max;
    }
}
