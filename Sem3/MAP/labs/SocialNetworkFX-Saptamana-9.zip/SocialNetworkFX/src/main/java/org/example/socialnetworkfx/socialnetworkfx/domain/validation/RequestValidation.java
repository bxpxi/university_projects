package org.example.socialnetworkfx.socialnetworkfx.domain.validation;

import org.example.socialnetworkfx.socialnetworkfx.domain.Friendship;
import org.example.socialnetworkfx.socialnetworkfx.domain.FriendshipRequest;

public class RequestValidation implements Validation<FriendshipRequest>{
    @Override
    public void validate(FriendshipRequest entity) throws ValidationException{

    }
}
