package org.example.socialnetworkfx.socialnetworkfx.domain.validation;

public class ValidationException extends RuntimeException {
    public ValidationException(String message) {
        super(message);
    }

}
