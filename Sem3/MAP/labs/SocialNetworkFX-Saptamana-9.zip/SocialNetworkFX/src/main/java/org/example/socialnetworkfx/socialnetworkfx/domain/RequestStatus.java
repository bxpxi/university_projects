package org.example.socialnetworkfx.socialnetworkfx.domain;

public enum RequestStatus {
    PENDING, ACCEPTED, REJECTED;
}
