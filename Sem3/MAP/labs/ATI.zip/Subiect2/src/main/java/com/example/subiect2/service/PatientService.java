package com.example.subiect2.service;

import com.example.subiect2.database.PatientDataBaseRepository;
import com.example.subiect2.domain.Patient;
import com.example.subiect2.utils.events.ChangeEventType;
import com.example.subiect2.utils.events.PatientEntityChangeEvent;
import com.example.subiect2.utils.observer.Observable;
import com.example.subiect2.utils.observer.Observer;

import java.util.ArrayList;
import java.util.List;

public class PatientService implements Observable<PatientEntityChangeEvent> {

    private final PatientDataBaseRepository patientDataBaseRepository;

    private final List<Observer<PatientEntityChangeEvent>> observers = new ArrayList<>();

    public PatientService(PatientDataBaseRepository patientDataBaseRepository){
        this.patientDataBaseRepository = patientDataBaseRepository;
    }

    @Override
    public void addObserver(Observer<PatientEntityChangeEvent> e) {
        observers.add(e);
    }

    @Override
    public void removeObserver(Observer<PatientEntityChangeEvent> e) {
        observers.remove(e);
    }

    @Override
    public void notifyObservers(PatientEntityChangeEvent t) {
        observers.forEach(x -> x.update(t));
    }

    public Patient deletePatient(Patient patient){
        Patient patient1 = patientDataBaseRepository.deletePatient(patient);
        notifyObservers(new PatientEntityChangeEvent(ChangeEventType.DELETE, patient1));
        return patient1;
    }

    public List<Patient> getAllPatientsInPending() {
        return patientDataBaseRepository.getAllPatientsInPending();
    }

    public List<Patient> getAllPatientsInPendingOrderDescendingBySeverity() {
        return patientDataBaseRepository.getAllPatientsInPendingOrderDescendingBySeverity();
    }
}
