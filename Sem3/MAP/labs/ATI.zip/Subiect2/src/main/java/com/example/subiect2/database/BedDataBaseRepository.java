package com.example.subiect2.database;

import com.example.subiect2.domain.Bed;
import com.example.subiect2.domain.BedType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BedDataBaseRepository {

    private final JDBCUtils jdbcUtils = new JDBCUtils();

    public BedDataBaseRepository() {

    }

    public List<Bed> getAllOccupiedBeds() {
        try {
            Connection connection = jdbcUtils.getConnection();

            PreparedStatement statement = connection.prepareStatement("SELECT * FROM beds WHERE cnp IS NOT NULL");

            List<Bed> occupiedBeds = new ArrayList<>();

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                long idBed = resultSet.getLong(1);
                BedType bedType = BedType.valueOf(resultSet.getString(2));
                boolean ventilation = resultSet.getBoolean(3);
                long CNP = resultSet.getLong(4);

                Bed bed = new Bed(idBed, bedType, ventilation, CNP);

                occupiedBeds.add(bed);
            }

            return occupiedBeds;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Bed updateFreeBedOfSomeType(long CNP, String typeOfBed) {
        try {
            Connection connection = jdbcUtils.getConnection();

            PreparedStatement statement = connection.prepareStatement("UPDATE beds SET cnp = ? WHERE idbed IN (SELECT idbed FROM beds WHERE bedtype = ? AND cnp is null LIMIT 1)");

            statement.setLong(1, CNP);
            statement.setString(2, typeOfBed);

            int rowCount = statement.executeUpdate();

            if (rowCount == 0)
                return null;
            return new Bed(0, BedType.TIC, false, CNP);

        } catch (SQLException e) {
            return null;
        }
    }

    public boolean verifyIfExistFreeBeds() {
        try {
            Connection connection = jdbcUtils.getConnection();

            PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM beds WHERE cnp is NULL");

            ResultSet resultSet = statement.executeQuery();

            int numberOfFreeBeds = -1;

            if (resultSet.next()) {
                numberOfFreeBeds = resultSet.getInt(1);
            }

            return numberOfFreeBeds > 0;

        } catch (SQLException e) {
            return false;
        }
    }


    public int getNumberOfFreeBeds() {
        try {
            Connection connection = jdbcUtils.getConnection();

            PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM beds WHERE cnp IS NULL");

            ResultSet resultSet = statement.executeQuery();

            int numberOfFreeBeds = -1;

            if (resultSet.next()) {
                numberOfFreeBeds = resultSet.getInt(1);
            }

            return numberOfFreeBeds;

        } catch (SQLException e) {
            return -1;
        }
    }

    public int getNumberOfFreeBedsOfSomeType(String type){
        try {
            Connection connection = jdbcUtils.getConnection();

            PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM beds WHERE cnp IS NULL AND bedtype = ?");

            statement.setString(1, type);

            ResultSet resultSet = statement.executeQuery();

            int numberOfFreeBedsOfSomeType = -1;

            if (resultSet.next()) {
                numberOfFreeBedsOfSomeType = resultSet.getInt(1);
            }

            return numberOfFreeBedsOfSomeType;

        } catch (SQLException e) {
            return -1;
        }
    }




}
