package com.example.subiect2.domain;

public enum BedType {
    TIC,
    TIM,
    TIIP
}