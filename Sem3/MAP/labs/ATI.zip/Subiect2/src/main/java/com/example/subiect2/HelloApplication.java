package com.example.subiect2;

import com.example.subiect2.database.BedDataBaseRepository;
import com.example.subiect2.database.PatientDataBaseRepository;
import com.example.subiect2.service.BedService;
import com.example.subiect2.service.PatientService;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader1 = new FXMLLoader(HelloApplication.class.getResource("bed-view.fxml"));
        Scene scene = new Scene(fxmlLoader1.load(), 600, 400);
        stage.setTitle("Beds");
        stage.setScene(scene);

        BedDataBaseRepository bedDataBaseRepository = new BedDataBaseRepository();
        BedService bedService = new BedService(bedDataBaseRepository);

        PatientDataBaseRepository patientDataBaseRepository = new PatientDataBaseRepository();
        PatientService patientService = new PatientService(patientDataBaseRepository);


        BedController bedController = fxmlLoader1.getController();
        bedController.setBedService(bedService);
        bedController.setPatientInPendingService(patientService);
        bedController.setBedsModel();
        bedController.setNumberOfFreeBeds();
        bedController.setNumberOfTIMFreeBeds();
        bedController.setNumberOfTICFreeBeds();
        bedController.setNumberOfTIIPFreeBeds();

        stage.show();

        Stage stage2 = new Stage();
        FXMLLoader fxmlLoader2 = new FXMLLoader(HelloApplication.class.getResource("patient-view.fxml"));
        Scene scene2 = new Scene(fxmlLoader2.load(), 600, 400);
        stage2.setTitle("PatientsInPending");
        stage2.setScene(scene2);

        PatientController patientController = fxmlLoader2.getController();
        patientController.setPatientsInPendingService(patientService);
        patientController.setBedService(bedService);
        patientController.setPatientsInPendingTable();
        patientController.setTypesOfBeds();
        patientController.setPatientController(stage2);

        stage2.show();

    }

    public static void main(String[] args) {
        launch();
    }
}