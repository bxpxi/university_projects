package com.example.subiect2.domain.validators;

public class BedTypeValidator implements Validator {

    @Override
    public void validateSelectedType(String typeOfBed) {
        String error = "";

        if (typeOfBed == null) {
            error += "You didn't select a type of bed";
        }

        if (error.length() > 0) {
            throw new ValidationException(error);
        }


    }

    @Override
    public void validateType(String typeOfBed, int numberOfBeds) {

        String error = "";

        if (numberOfBeds == 0) {
            error += "All beds of type " + typeOfBed + " are occupied";
        }

        if (error.length() > 0) {
            throw new ValidationException(error);
        }

    }
}
