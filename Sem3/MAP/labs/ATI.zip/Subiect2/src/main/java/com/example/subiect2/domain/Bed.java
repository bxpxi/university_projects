package com.example.subiect2.domain;

import java.util.Objects;

public class Bed {

    private final long idBed;

    private BedType bedType;

    private boolean ventilation;

    private final long CNP;

    public Bed(long idBed, BedType bedType, boolean ventilation, long CNP){
        this.idBed = idBed;
        this.bedType = bedType;
        this.ventilation = ventilation;
        this.CNP = CNP;
    }

    public long getIdBed(){
        return idBed;
    }

    public BedType getBedType() {
        return bedType;
    }

    public void setBedType(BedType bedType) {
        this.bedType = bedType;
    }

    public boolean isVentilation() {
        return ventilation;
    }

    public void setVentilation(boolean ventilation) {
        this.ventilation = ventilation;
    }

    public long getCNP() {
        return CNP;
    }

    @Override
    public String toString() {
        return "Bed{" +
                "idBed=" + idBed +
                ", bedType=" + bedType +
                ", ventilation=" + ventilation +
                ", CNP=" + CNP +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Bed bed = (Bed) o;
        return idBed == bed.idBed && ventilation == bed.ventilation && CNP == bed.CNP && bedType == bed.bedType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idBed, bedType, ventilation, CNP);
    }
}
