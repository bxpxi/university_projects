package com.example.subiect2.domain;

import java.util.Comparator;
import java.util.Objects;

public class Patient {

    private final long CNP;

    private int months;

    private boolean premature;

    private String mainDiagnostic;

    private Integer severity;

    public Patient(long CNP, int months, boolean premature, String mainDiagnostic, Integer severity) {
        this.CNP = CNP;
        this.months = months;
        this.premature = premature;
        this.mainDiagnostic = mainDiagnostic;
        this.severity = severity;
    }

    public long getCNP() {
        return CNP;
    }

    public int getMonths() {
        return months;
    }

    public void setMonths(int months) {
        this.months = months;
    }

    public boolean isPremature() {
        return premature;
    }

    public void setPremature(boolean premature) {
        this.premature = premature;
    }

    public String getMainDiagnostic() {
        return mainDiagnostic;
    }

    public void setMainDiagnostic(String mainDiagnostic) {
        this.mainDiagnostic = mainDiagnostic;
    }

    public Integer getSeverity() {
        return severity;
    }

    public void setSeverity(Integer severity) {
        this.severity = severity;
    }

    @Override
    public String toString() {
        return "Patient{" +
                "CNP=" + CNP +
                ", months=" + months +
                ", premature=" + premature +
                ", mainDiagnostic='" + mainDiagnostic + '\'' +
                ", severity=" + severity +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Patient patient = (Patient) o;
        return CNP == patient.CNP && months == patient.months && premature == patient.premature && severity.equals(patient.severity) && Objects.equals(mainDiagnostic, patient.mainDiagnostic);
    }

    @Override
    public int hashCode() {
        return Objects.hash(CNP, months, premature, mainDiagnostic, severity);
    }


    public static class ComparatorForSeverity implements Comparator<Patient> {

        @Override
        public int compare(Patient o1, Patient o2) {
            return o2.severity.compareTo(o1.severity);
        }
    }

}
