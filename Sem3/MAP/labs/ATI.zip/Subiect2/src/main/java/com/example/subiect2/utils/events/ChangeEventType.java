package com.example.subiect2.utils.events;

public enum ChangeEventType {
    ADD, UPDATE, DELETE;
}
