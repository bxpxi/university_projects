package com.example.subiect2.domain;

public class BedTypeCNP {

    public static String bedTYPE = null;
    public static long CNP = -1;

}
