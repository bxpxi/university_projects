package com.example.subiect2.database;

import com.example.subiect2.PatientController;
import com.example.subiect2.domain.Bed;
import com.example.subiect2.domain.Patient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PatientDataBaseRepository {

    private final JDBCUtils jdbcUtils = new JDBCUtils();

    private final BedDataBaseRepository bedDataBaseRepository = new BedDataBaseRepository();

    public PatientDataBaseRepository() {

    }

    public Patient deletePatient(Patient patient){
        try{
            Connection connection = jdbcUtils.getConnection();

            PreparedStatement statement = connection.prepareStatement("DELETE FROM patients WHERE cnp = ?");

            statement.setLong(1, patient.getCNP());

            int rowNumber = statement.executeUpdate();

            if(rowNumber == 0)
                return null;

            return patient;

        }catch (SQLException e){
            return null;
        }
    }

    public List<Patient> getAllPatientsInPending() {
        List<Patient> patients = getAllPatients();
        List<Bed> beds = bedDataBaseRepository.getAllOccupiedBeds();

        List<Patient> patientsInPending = new ArrayList<>();

        boolean pending;

        if (patients != null) {
            for (Patient patient : patients) {
                pending = true;

                for (Bed bed : beds) {
                    if (patient.getCNP() == bed.getCNP()) {
                        pending = false;
                        break;
                    }
                }

                if (pending) {
                    patientsInPending.add(patient);
                }
            }

            return patientsInPending;
        }

        return null;

    }

    public List<Patient> getAllPatientsInPendingOrderDescendingBySeverity() {
        List<Patient> patients = getAllPatientsInPending();

        Patient.ComparatorForSeverity comparatorForSeverity = new Patient.ComparatorForSeverity();

        if (patients != null) {
            patients.sort(comparatorForSeverity);
            return patients;
        }

        return null;
    }


    private List<Patient> getAllPatients() {
        try {
            Connection connection = jdbcUtils.getConnection();

            PreparedStatement statement = connection.prepareStatement("SELECT * FROM patients");

            ResultSet resultSet = statement.executeQuery();

            List<Patient> patients = new ArrayList<>();

            while (resultSet.next()) {
                long cnp = resultSet.getLong(1);
                int months = resultSet.getInt(2);
                boolean premature = resultSet.getBoolean(3);
                String mainDiagnostic = resultSet.getString(4);
                int severity = resultSet.getInt(5);

                Patient patient = new Patient(cnp, months, premature, mainDiagnostic, severity);

                patients.add(patient);
            }

            return patients;

        } catch (SQLException e) {
            return null;
        }
    }

}
