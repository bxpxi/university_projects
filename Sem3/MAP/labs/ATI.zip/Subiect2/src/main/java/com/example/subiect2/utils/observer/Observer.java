package com.example.subiect2.utils.observer;


import com.example.subiect2.utils.events.Event;

public interface Observer<E extends Event> {
    void update(E e);
}