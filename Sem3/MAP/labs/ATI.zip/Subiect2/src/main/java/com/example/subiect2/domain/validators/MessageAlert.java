package com.example.subiect2.domain.validators;

import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class MessageAlert {

    public static void showErrorMessageForUnselectedTypeOfBed(Stage owner, String text){
        Alert message = new Alert(Alert.AlertType.ERROR);
        message.initOwner(owner);
        message.setTitle("UnselectedTypeOfBed");
        message.setContentText(text);
        message.showAndWait();
    }

    public static void showErrorMessageForZeroFreeBedsOfSomeType(Stage owner, String text){
        Alert message = new Alert(Alert.AlertType.ERROR);
        message.initOwner(owner);
        message.setTitle("ZeroFreeBedsOfThisType");
        message.setContentText(text);
        message.showAndWait();
    }


}
