package com.example.subiect2;

import com.example.subiect2.domain.Bed;
import com.example.subiect2.domain.BedType;
import com.example.subiect2.domain.BedTypeCNP;
import com.example.subiect2.service.BedService;
import com.example.subiect2.service.PatientService;
import com.example.subiect2.utils.events.PatientEntityChangeEvent;
import com.example.subiect2.utils.observer.Observer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class BedController implements Observer<PatientEntityChangeEvent> {

    private final ObservableList<Bed> bedModel = FXCollections.observableArrayList();

    private BedService bedService;

    @FXML
    private TextField numberOfFreeBeds;

    @FXML
    private TextField numberOfTIMFreeBeds;

    @FXML
    private TextField numberOfTICFreeBeds;

    @FXML
    private TextField numberOfTIIPFreeBeds;

    @FXML
    private TableView<Bed> occupiedBedsTable;

    @FXML
    private TableColumn<Bed, Long> idBed;

    @FXML
    private TableColumn<Bed, String> bedType;

    @FXML
    private TableColumn<Bed, Boolean> ventilation;

    @FXML
    private TableColumn<Bed, Long> cnp;

    @FXML
    public void initialize() {
        idBed.setCellValueFactory(new PropertyValueFactory<>("idBed"));
        bedType.setCellValueFactory(new PropertyValueFactory<>("bedType"));
        ventilation.setCellValueFactory(new PropertyValueFactory<>("ventilation"));
        cnp.setCellValueFactory(new PropertyValueFactory<>("CNP"));

        occupiedBedsTable.setItems(bedModel);

    }

    public void setBedService(BedService bedService) {
        this.bedService = bedService;
    }

    public void setPatientInPendingService(PatientService patientService){
        patientService.addObserver(this);
    }

    public void setBedsModel() {
        List<Bed> occupiedBeds = bedService.getAllOccupiedBeds();
        bedModel.setAll(occupiedBeds);
    }

    public void setNumberOfFreeBeds() {
        int number = bedService.getNumberOfFreeBeds();
        String strNumber = Integer.toString(number);
        numberOfFreeBeds.setText(strNumber);
        numberOfFreeBeds.setEditable(false);
    }

    public void setNumberOfTIMFreeBeds(){
        int number = bedService.getNumberOfFreeBedsOfSomeType(String.valueOf(BedType.TIM));

        String strNumber = Integer.toString(number);
        numberOfTIMFreeBeds.setText(strNumber);
        numberOfTIMFreeBeds.setEditable(false);
    }

    public void setNumberOfTICFreeBeds(){
        int number = bedService.getNumberOfFreeBedsOfSomeType(String.valueOf(BedType.TIC));

        String strNumber = Integer.toString(number);
        numberOfTICFreeBeds.setText(strNumber);
        numberOfTICFreeBeds.setEditable(false);
    }

    public void setNumberOfTIIPFreeBeds(){
        int number = bedService.getNumberOfFreeBedsOfSomeType(String.valueOf(BedType.TIIP));

        String strNumber = Integer.toString(number);
        numberOfTIIPFreeBeds.setText(strNumber);
        numberOfTIIPFreeBeds.setEditable(false);
    }


    @Override
    public void update(PatientEntityChangeEvent patientEntityChangeEvent) {
        int numberOfFreeB = Integer.parseInt(numberOfFreeBeds.getText()) - 1;
        numberOfFreeBeds.setText(Integer.toString(numberOfFreeB));

        switch (BedTypeCNP.bedTYPE) {
            case "TIM" -> {
                int numberOfFreeTIMBeds = Integer.parseInt(numberOfTIMFreeBeds.getText()) - 1;
                numberOfTIMFreeBeds.setText(Integer.toString(numberOfFreeTIMBeds));
            }
            case "TIC" -> {
                int numberOfFreeTICBeds = Integer.parseInt(numberOfTICFreeBeds.getText()) - 1;
                numberOfTICFreeBeds.setText(Integer.toString(numberOfFreeTICBeds));
            }
            case "TIIP" -> {
                int numberOfFreeTIIPBeds = Integer.parseInt(numberOfTIIPFreeBeds.getText()) - 1;
                numberOfTIIPFreeBeds.setText(Integer.toString(numberOfFreeTIIPBeds));
            }
        }

        bedService.updateFreeBedOfSomeType(BedTypeCNP.CNP, BedTypeCNP.bedTYPE);
        setBedsModel();
    }
}
