package com.example.subiect2.domain.validators;

public class ValidationException extends RuntimeException{

    public ValidationException(String message){
        super(message);
    }

}
