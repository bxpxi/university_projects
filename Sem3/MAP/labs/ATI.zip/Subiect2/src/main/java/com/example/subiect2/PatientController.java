package com.example.subiect2;

import com.example.subiect2.domain.Bed;
import com.example.subiect2.domain.BedTypeCNP;
import com.example.subiect2.domain.Patient;
import com.example.subiect2.domain.validators.BedTypeValidator;
import com.example.subiect2.domain.validators.MessageAlert;
import com.example.subiect2.domain.validators.ValidationException;
import com.example.subiect2.service.BedService;
import com.example.subiect2.service.PatientService;
import com.example.subiect2.utils.events.PatientEntityChangeEvent;
import com.example.subiect2.utils.observer.Observable;
import com.example.subiect2.utils.observer.Observer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class PatientController implements Observer<PatientEntityChangeEvent> {

    private final ObservableList<Patient> patientsInPendingModel = FXCollections.observableArrayList();

    private final ObservableList<String> typesOfBedsModel = FXCollections.observableArrayList();

    private PatientService patientService;

    private BedService bedService;

    private final BedTypeValidator bedTypeValidator = new BedTypeValidator();

    private Stage patientStage;

    @FXML
    private ComboBox<String> typesOfBeds;

    @FXML
    private TableView<Patient> patientsInPendingTable;

    @FXML
    private TableColumn<Patient, Long> cnp;

    @FXML
    private TableColumn<Patient, Integer> months;

    @FXML
    private TableColumn<Patient, Boolean> premature;

    @FXML
    private TableColumn<Patient, String> mainDiagnostic;

    @FXML
    private TableColumn<Patient, Integer> severity;

    @FXML
    public void initialize() {
        cnp.setCellValueFactory(new PropertyValueFactory<>("CNP"));
        months.setCellValueFactory(new PropertyValueFactory<>("months"));
        premature.setCellValueFactory(new PropertyValueFactory<>("premature"));
        mainDiagnostic.setCellValueFactory(new PropertyValueFactory<>("mainDiagnostic"));
        severity.setCellValueFactory(new PropertyValueFactory<>("severity"));

        patientsInPendingTable.setItems(patientsInPendingModel);
        typesOfBeds.setItems(typesOfBedsModel);

    }

    @FXML
    public void onPatientsInPendingTableClicked(){

        BedTypeCNP.bedTYPE = typesOfBeds.getSelectionModel().getSelectedItem();
        BedTypeCNP.CNP = patientsInPendingTable.getSelectionModel().getSelectedItem().getCNP();
        Patient patient = patientsInPendingTable.getSelectionModel().getSelectedItem();

        try{
            bedTypeValidator.validateSelectedType(BedTypeCNP.bedTYPE);
            int number = bedService.getNumberOfFreeBedsOfSomeType(BedTypeCNP.bedTYPE);
            try{
                bedTypeValidator.validateType(BedTypeCNP.bedTYPE, number);
                patientService.deletePatient(patient);
            }catch (ValidationException ve){
                MessageAlert.showErrorMessageForZeroFreeBedsOfSomeType(patientStage, ve.getMessage());
            }
        }catch (ValidationException ve){
            MessageAlert.showErrorMessageForUnselectedTypeOfBed(patientStage, ve.getMessage());
        }

    }

    public void setPatientsInPendingService(PatientService patientService) {
        this.patientService = patientService;
        this.patientService.addObserver(this);
    }

    public void setBedService(BedService bedService){
        this.bedService = bedService;
    }

    public void setPatientsInPendingTable() {
        List<Patient> patientsInPending = patientService.getAllPatientsInPendingOrderDescendingBySeverity();
        patientsInPendingModel.setAll(patientsInPending);
    }

    public void setTypesOfBeds() {
        List<String> typeOfBeds = new ArrayList<>();

        typeOfBeds.add("TIC");
        typeOfBeds.add("TIM");
        typeOfBeds.add("TIIP");

        typesOfBedsModel.setAll(typeOfBeds);
    }

    public void setPatientController(Stage patientStage){
        this.patientStage = patientStage;
    }

    @Override
    public void update(PatientEntityChangeEvent patientEntityChangeEvent) {
        setPatientsInPendingTable();
    }
}
