package com.example.subiect2.domain.validators;

public interface Validator {

    void validateSelectedType(String typeOfBed);

    void validateType(String typeOfBed, int numberOfBeds);

}