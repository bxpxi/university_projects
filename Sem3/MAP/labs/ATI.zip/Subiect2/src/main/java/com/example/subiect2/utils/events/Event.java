package com.example.subiect2.utils.events;

public interface Event {
}
