package com.example.subiect2.service;

import com.example.subiect2.database.BedDataBaseRepository;
import com.example.subiect2.domain.Bed;
import com.example.subiect2.utils.events.PatientEntityChangeEvent;
import com.example.subiect2.utils.observer.Observable;
import com.example.subiect2.utils.observer.Observer;

import java.util.ArrayList;
import java.util.List;

public class BedService {

    private final BedDataBaseRepository bedDataBaseRepository;

    private final List<Observer<PatientEntityChangeEvent>> observers = new ArrayList<>();

    public BedService(BedDataBaseRepository bedDataBaseRepository){
        this.bedDataBaseRepository = bedDataBaseRepository;
    }

    public List<Bed> getAllOccupiedBeds(){
        return bedDataBaseRepository.getAllOccupiedBeds();
    }

    public int getNumberOfFreeBeds(){
        return bedDataBaseRepository.getNumberOfFreeBeds();
    }

    public int getNumberOfFreeBedsOfSomeType(String type){
        return bedDataBaseRepository.getNumberOfFreeBedsOfSomeType(type);
    }

    public Bed updateFreeBedOfSomeType(long CNP, String typeOfBed) {
        return bedDataBaseRepository.updateFreeBedOfSomeType(CNP, typeOfBed);
    }

    public boolean verifyIfExistFreeBeds() {
        return bedDataBaseRepository.verifyIfExistFreeBeds();
    }

}
