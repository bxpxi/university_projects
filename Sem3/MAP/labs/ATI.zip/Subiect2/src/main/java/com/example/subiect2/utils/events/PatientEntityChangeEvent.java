package com.example.subiect2.utils.events;

import com.example.subiect2.domain.Patient;

public class PatientEntityChangeEvent implements Event {
    private final ChangeEventType type;
    private final Patient data;
    private Patient oldData;

    public PatientEntityChangeEvent(ChangeEventType type, Patient data) {
        this.type = type;
        this.data = data;
    }

    public PatientEntityChangeEvent(ChangeEventType type, Patient data, Patient oldData) {
        this.type = type;
        this.data = data;
        this.oldData = oldData;
    }

    public ChangeEventType getType() {
        return type;
    }

    public Patient getData() {
        return data;
    }

    public Patient getOldData() {
        return oldData;
    }
}