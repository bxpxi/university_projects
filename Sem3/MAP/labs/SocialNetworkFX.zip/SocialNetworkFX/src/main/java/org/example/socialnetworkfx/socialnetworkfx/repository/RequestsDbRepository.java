package org.example.socialnetworkfx.socialnetworkfx.repository;

import org.example.socialnetworkfx.socialnetworkfx.domain.Entity;
import org.example.socialnetworkfx.socialnetworkfx.domain.FriendshipRequest;

public class RequestsDbRepository extends Entity<FriendshipRequest> {


}
