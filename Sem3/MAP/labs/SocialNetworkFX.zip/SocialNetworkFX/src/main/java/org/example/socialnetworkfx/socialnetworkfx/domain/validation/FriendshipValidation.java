package org.example.socialnetworkfx.socialnetworkfx.domain.validation;

import org.example.socialnetworkfx.socialnetworkfx.domain.Friendship;

public class FriendshipValidation implements Validation<Friendship> {
    @Override
    public void validate(Friendship entity) throws ValidationException{

    }
}
