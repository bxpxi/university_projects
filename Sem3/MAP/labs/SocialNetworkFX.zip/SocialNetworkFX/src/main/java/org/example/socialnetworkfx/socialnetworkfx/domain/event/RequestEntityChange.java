package org.example.socialnetworkfx.socialnetworkfx.domain.event;

public class RequestEntityChange {
}
