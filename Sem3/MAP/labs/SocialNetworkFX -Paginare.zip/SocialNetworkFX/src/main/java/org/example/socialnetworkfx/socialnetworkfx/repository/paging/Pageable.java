package org.example.socialnetworkfx.socialnetworkfx.repository.paging;

public interface Pageable {
    int getPageNumber();
    int getPageSize();
}
