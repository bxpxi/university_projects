package org.example.socialnetworkfx.socialnetworkfx.domain.validation;

import org.example.socialnetworkfx.socialnetworkfx.domain.Message;

public class MessageValidation implements Validation<Message> {
    @Override
    public void validate(Message message) throws ValidationException {

    }
}
