package com.example.anar.domain;

public enum Risc {
    RISC_MAJOR,
    RISC_MEDIU,
    RISC_REDUS
}
