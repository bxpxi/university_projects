package com.example.anar.observer;


public interface Observer {
    void update();
}

