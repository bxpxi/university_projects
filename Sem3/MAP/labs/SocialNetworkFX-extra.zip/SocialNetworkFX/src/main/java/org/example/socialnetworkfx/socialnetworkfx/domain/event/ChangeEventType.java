package org.example.socialnetworkfx.socialnetworkfx.domain.event;

public enum ChangeEventType {
    ADD,UPDATE,DELETE;
}
