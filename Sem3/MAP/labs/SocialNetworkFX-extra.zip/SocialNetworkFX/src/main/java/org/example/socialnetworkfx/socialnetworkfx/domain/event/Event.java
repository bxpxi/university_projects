package org.example.socialnetworkfx.socialnetworkfx.domain.event;

public interface Event {
}
