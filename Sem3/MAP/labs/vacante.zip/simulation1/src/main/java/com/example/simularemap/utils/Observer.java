package com.example.simularemap.utils;

public interface Observer {
    void update();
}
