package com.example.simularemap.service;

import com.example.simularemap.domain.Reservation;
import com.example.simularemap.repository.dbRepo.ReservationDbRepo;
import com.example.simularemap.utils.Observable;

import java.time.LocalDateTime;
import com.example.simularemap.utils.ReservationContext;

public class ReservationService extends Observable{
    private final ReservationDbRepo reservationDbRepo;

    public ReservationService(ReservationDbRepo reservationDbRepo) {
        this.reservationDbRepo = reservationDbRepo;
    }

    public Reservation save(Reservation reservation) {
        Reservation reservation1 = reservationDbRepo.save(reservation);
        ReservationContext.getInstance().setReservingClientId(reservation.getClientId());
        notifyObs();
        return reservation1;
    }

    public Double getLowestId() {
        return reservationDbRepo.getValidId();
    }

    public boolean isRoomAvailable(Double hotelId, LocalDateTime startDate, int noNights) {
        return reservationDbRepo.isRoomAvailable(hotelId, startDate, noNights);
    }



}
