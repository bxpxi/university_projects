package com.example.simularemap;

import com.example.simularemap.domain.Client;
import com.example.simularemap.repository.dbRepo.*;
import com.example.simularemap.service.*;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    private HotelService hotelService;
    private LocationService locationService;
    private SpecialOfferService specialOfferService;
    private ClientsService clientsService;
    private ReservationService reservationService;
    private static String[] sysArgs;

    public static String[] getSysArgs() {
        return sysArgs;
    }

    private void start() {
        String urlDb = "jdbc:postgresql://localhost:5432/vacante";
        String usernameDb = "postgres";
        String passDb = "Bobby";
        HotelsDbRepository hotelsDbRepository = new HotelsDbRepository(urlDb, usernameDb, passDb);
        LocationsDbRepo locationsDbRepo = new LocationsDbRepo(urlDb, usernameDb, passDb);
        SpecialOfferDbRepo specialOfferDbRepo = new SpecialOfferDbRepo(urlDb, usernameDb, passDb);
        ClientsDbRepo clientsDbRepo = new ClientsDbRepo(urlDb, usernameDb, passDb);
        hotelService = new HotelService(hotelsDbRepository);
        ReservationDbRepo reservationDbRepo = new ReservationDbRepo(urlDb, usernameDb, passDb, hotelService);
        locationService = new LocationService(locationsDbRepo);
        specialOfferService = new SpecialOfferService(specialOfferDbRepo);
        clientsService = new ClientsService(clientsDbRepo);
        reservationService = new ReservationService(reservationDbRepo);
    }

    @Override
    public void start(Stage stage) throws IOException {
        start();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        MainController ctr = fxmlLoader.getController();
        ctr.setServices(hotelService, locationService, specialOfferService, clientsService, reservationService);

        // Setează ID-ul clientului în MainController
        if (sysArgs.length > 0) {
            ctr.setClientId(Long.parseLong(sysArgs[0])); // Pasează ID-ul primului client
        }

        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();

        for (String id : sysArgs) {
            Client client = clientsService.findById(Long.parseLong(id));
            FXMLLoader fxmlLoader1 = new FXMLLoader(HelloApplication.class.getResource("clients-offers.fxml"));
            Scene scene1 = new Scene(fxmlLoader1.load());
            ClientsOffer ctr1 = fxmlLoader1.getController();
            ctr1.setHotelService(hotelService);
            ctr1.setServiceClient(clientsService, client);
            ctr1.setSpecialOfferService(specialOfferService); // Setează specialOfferService
            ctr1.setReservationService(reservationService);
            ctr1.setClientId(client.getId());
            reservationService.addObserver(ctr1);
            Stage stage1 = new Stage();
            stage1.setTitle(client.getName());
            stage1.setScene(scene1);
            stage1.show();
        }
    }

    public static void main(String[] args) {
        if(args.length == 0) System.out.println("No args");
        for(String id : args) {
            System.out.println(id);
        }
        sysArgs = args;
        launch();
    }
}