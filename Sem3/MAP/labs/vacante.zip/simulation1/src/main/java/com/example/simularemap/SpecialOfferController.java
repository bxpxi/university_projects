package com.example.simularemap;

import com.example.simularemap.domain.Client;
import com.example.simularemap.domain.Dtos.HotelDTO;
import com.example.simularemap.domain.Dtos.SpecialOfferDTO;
import com.example.simularemap.domain.Reservation;
import com.example.simularemap.service.ClientsService;
import com.example.simularemap.service.HotelService;
import com.example.simularemap.service.ReservationService;
import com.example.simularemap.service.SpecialOfferService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class SpecialOfferController {
    ObservableList<SpecialOfferDTO> offers = FXCollections.observableArrayList();

    private HotelService hotelService;
    private SpecialOfferService specialOfferService;
    private HotelDTO hotel;
    private ReservationService reservationService;

    public void setServices(HotelService hotelService, SpecialOfferService specialOfferService, ReservationService reservationService, ClientsService clientsService) {
        this.hotelService = hotelService;
        this.specialOfferService = specialOfferService;
        this.reservationService = reservationService;
        this.clientsService = clientsService;
    }

    private Long clientId; // Adaugă acest câmp

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public void setHotel(HotelDTO hotel) {
        this.hotel = hotel;
    }

    @FXML
    private DatePicker datePickerBegin;

    @FXML
    private DatePicker datePickerEnd;

    @FXML
    private TableView<SpecialOfferDTO> offersTableView;

    @FXML
    private TableColumn<SpecialOfferDTO, String> startDateCol;

    @FXML
    private TableColumn<SpecialOfferDTO, String> endDateCol;

    @FXML
    private TableColumn<SpecialOfferDTO, String> percentsCol;

    private ClientsService clientsService;

    public void setClientsService(ClientsService clientsService) {
        this.clientsService = clientsService;
    }

    @FXML
    private void initialize() {
        startDateCol.setCellValueFactory(new PropertyValueFactory<>("startDate"));
        endDateCol.setCellValueFactory(new PropertyValueFactory<>("endDate"));
        percentsCol.setCellValueFactory(new PropertyValueFactory<>("percent"));

        offersTableView.setItems(offers);
    }

    public void searchBtnHandle() {
        Date startDate = Date.from(datePickerBegin.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
        Date endDate = Date.from(datePickerEnd.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
        offers.setAll(specialOfferService.findByDateAndId(hotel.getId(), startDate, endDate)
                .stream()
                .map(SpecialOfferDTO::new)
                .collect(Collectors.toList()));
    }

    public void reserveButton() {
        if (hotel == null) {
            System.out.println("Hotelul nu a fost selectat corect.");
            return;
        }

        Date startDate = Date.from(datePickerBegin.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
        Date endDate = Date.from(datePickerEnd.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
        LocalDateTime startDateTime = startDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        long diffInMills = Math.abs(endDate.getTime() - startDate.getTime());
        long diff = TimeUnit.DAYS.convert(diffInMills, TimeUnit.MILLISECONDS);
        int noDays = (int) diff;

        if (!reservationService.isRoomAvailable(hotel.getId(), startDateTime, noDays)) {
            System.out.println("Nu sunt camere disponibile în această perioadă.");
            return;
        }

        Reservation reservation = new Reservation(clientId, hotel.getId(), startDateTime, noDays);
        reservation.setId(reservationService.getLowestId());
        reservationService.save(reservation);

        notifyOtherClients(reservation);
    }


    private void notifyOtherClients(Reservation reservation) {
        // Obține clientul care a făcut rezervarea
        Client reservingClient = clientsService.findById(clientId);
        if (reservingClient == null) {
            System.out.println("Clientul care a făcut rezervarea nu a fost găsit.");
            return;
        }

        // Obține lista tuturor clienților autentificați (citiți din linia de comandă)
        for (String clientIdStr : HelloApplication.getSysArgs()) {
            Long otherClientId = Long.parseLong(clientIdStr);
            if (!otherClientId.equals(clientId)) { // Nu notifica clientul care a făcut rezervarea
                Client otherClient = clientsService.findById(otherClientId);
                if (otherClient != null && otherClient.getHobby().equals(reservingClient.getHobby())) {
                    // Dacă hobby-urile coincid, notifică clientul
                    String message = "Încă un utilizator care " + reservingClient.getHobby().toString().toLowerCase() +
                            " a făcut o rezervare la hotelul " + hotel.getHotelName() + ".";
                    System.out.println("Notificare pentru clientul " + otherClient.getName() + ": " + message);
                    // Aici poți adăuga logica pentru afișarea mesajului în interfața grafică
                }
            }
        }
    }
}
