package com.example.simularemap.domain.enums;

public enum HotelType {
    FAMILY, TEENAGERS, OLD_PEOPLE
}
