package com.example.simularemap;

import com.example.simularemap.domain.Client;
import com.example.simularemap.domain.Dtos.HotelDTO;
import com.example.simularemap.domain.Dtos.OfferDTO;
import com.example.simularemap.service.ClientsService;
import com.example.simularemap.service.HotelService;
import com.example.simularemap.service.ReservationService;
import com.example.simularemap.service.SpecialOfferService;
import com.example.simularemap.utils.Observer;
import com.example.simularemap.utils.ReservationContext;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.stream.Collectors;

public class ClientsOffer implements Observer {
    public Label testLabelObs;
    ObservableList<OfferDTO> offers = FXCollections.observableArrayList();

    private ClientsService clientsService;
    private HotelService hotelService;
    private SpecialOfferService specialOfferService;
    private ReservationService reservationService;

    private Client client;

    private Long clientId; // Adaugă acest câmp

    // Metoda pentru setarea clientId
    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public void setSpecialOfferService(SpecialOfferService specialOfferService) {
        this.specialOfferService = specialOfferService;
    }

    public void setReservationService(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    public void setHotelService(HotelService hotelService) {
        this.hotelService = hotelService;
    }

    @Override
    public void update() {
        // Obține ID-ul clientului care a făcut rezervarea din ReservationContext
        Long reservingClientId = ReservationContext.getInstance().getReservingClientId();
        if (reservingClientId == null) {
            System.out.println("ID-ul clientului care a făcut rezervarea nu a fost setat.");
            return;
        }

        // Obține clientul care a făcut rezervarea
        Client reservingClient = clientsService.findById(reservingClientId); // Folosește reservingClientId
        if (reservingClient == null) {
            System.out.println("Clientul care a făcut rezervarea nu a fost găsit.");
            return;
        }

        // Mesaje de debug
        System.out.println("Clientul curent: " + client.getName() + ", Hobby: " + client.getHobby());
        System.out.println("Clientul care a făcut rezervarea: " + reservingClient.getName() + ", Hobby: " + reservingClient.getHobby());

        // Verifică dacă clientul curent este diferit de clientul care a făcut rezervarea
        if (!client.getId().equals(reservingClient.getId())) {
            // Verifică dacă hobby-ul clientului curent coincide cu hobby-ul clientului care a făcut rezervarea
            if (client.getHobby().equals(reservingClient.getHobby())) {
                // Afișează mesajul de notificare în interfața grafică
                testLabelObs.setText("Another client who likes " + reservingClient.getHobby().toString().toLowerCase() + " booked a room.");
            } else {
                // Dacă hobby-urile nu coincid, nu afișa nimic
                testLabelObs.setText(""); // Sau un mesaj generic, dacă este necesar
                System.out.println("Clientul " + client.getName() + " nu are același hobby ca clientul care a făcut rezervarea.");
            }
        } else {
            System.out.println("Clientul " + client.getName() + " este cel care a făcut rezervarea și nu primește notificare.");
        }
    }

    @FXML
    private TableView<OfferDTO> tableViewOffers;

    @FXML
    private TableColumn<OfferDTO, String> hoNameCol;

    @FXML
    private TableColumn<OfferDTO, String> locNameCol;

    @FXML
    private TableColumn<OfferDTO, String> startCol;

    @FXML
    private TableColumn<OfferDTO, String> endCol;

    @FXML
    private TableView<HotelDTO> hotelsTableView;

    @FXML
    private TableColumn<HotelDTO, String> hotelNameColumn;

    @FXML
    private TableColumn<HotelDTO, String> roomsColumn;

    @FXML
    private TableColumn<HotelDTO, String> priceColumn;

    @FXML
    private TableColumn<HotelDTO, String> typeColumn;

    private ObservableList<HotelDTO> hotels = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        hoNameCol.setCellValueFactory(new PropertyValueFactory<>("hotelName"));
        locNameCol.setCellValueFactory(new PropertyValueFactory<>("locationName"));
        startCol.setCellValueFactory(new PropertyValueFactory<>("startDate"));
        endCol.setCellValueFactory(new PropertyValueFactory<>("endDate"));
        testLabelObs.setText("");
        tableViewOffers.setItems(offers);

        hotelNameColumn.setCellValueFactory(new PropertyValueFactory<>("hotelName"));
        roomsColumn.setCellValueFactory(new PropertyValueFactory<>("noRooms"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("pricePerNight"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("hotelType"));
        hotelsTableView.setItems(hotels);

        hotelsTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                System.out.println("Hotel selectat: " + newSelection.getHotelName());
            } else {
                System.out.println("Niciun hotel selectat.");
            }
        });
    }

    public void setServiceClient(ClientsService clientsService, Client client) {
        this.clientsService = clientsService;
        this.client = client;
        offers.setAll(clientsService.findByPercentage(client.getFidelityGrade()));
        if (hotelService != null) {
            hotels.setAll(hotelService.findAll().stream()
                    .map(HotelDTO::new)
                    .collect(Collectors.toList()));
        } else {
            System.out.println("hotelService este null!");
        }
    }

    private HotelDTO getSelectedHotel() {
        return hotelsTableView.getSelectionModel().getSelectedItem();
    }

    @FXML
    private void openReservationWindow() throws IOException {
        if (hotelService == null) {
            System.out.println("hotelService este null!");
            return;
        }

        HotelDTO selectedHotel = getSelectedHotel();
        if (selectedHotel == null) {
            System.out.println("Selectați un hotel înainte de a face o rezervare.");
            return;
        }

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("special-offer.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        SpecialOfferController specialOfferController = fxmlLoader.getController();
        specialOfferController.setServices(hotelService, specialOfferService, reservationService, clientsService);
        specialOfferController.setClientId(client.getId()); // Pasează ID-ul clientului
        specialOfferController.setHotel(selectedHotel); // Pasează hotelul selectat

        Stage stage = new Stage();
        stage.setTitle("Reservation for " + client.getName());
        stage.setScene(scene);
        stage.show();
    }
}
