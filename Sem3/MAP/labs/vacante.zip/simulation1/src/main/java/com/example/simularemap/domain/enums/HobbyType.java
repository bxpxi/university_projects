package com.example.simularemap.domain.enums;

public enum HobbyType {
    READING, MUSIC, HIKING, WALKING, EXTREME_SPORTS
}
