package com.example.simularemap.repository.dbRepo;

import com.example.simularemap.domain.Hotel;
import com.example.simularemap.domain.Reservation;
import com.example.simularemap.repository.Repository;
import com.example.simularemap.service.HotelService;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.List;

public class ReservationDbRepo implements Repository<Double, Reservation> {
    private final String urlDb;
    private final String usernameDb;
    private final String passwordDb;
    private HotelService hotelService;

    public ReservationDbRepo(String urlDb, String usernameDb, String passwordDb, HotelService hotelService) {
        this.urlDb = urlDb;
        this.usernameDb = usernameDb;
        this.passwordDb = passwordDb;
        this.hotelService = hotelService;
    }

    @Override
    public Reservation findOne(Double aDouble) {
        return null;
    }

    @Override
    public List<Reservation> findAll() {
        return null;
    }

    @Override
    public Reservation save(Reservation entity) {
        String sql = "INSERT INTO reservations(reservationid, clientid, hotelid, startdate, nonights) VALUES\n" +
                        "(?, ?, ?, ?, ?)";
        try (
                Connection connection = DriverManager.getConnection(urlDb, usernameDb, passwordDb);
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                ) {
            preparedStatement.setDouble(1, entity.getId());
            preparedStatement.setLong(2, entity.getClientId());
            preparedStatement.setDouble(3, entity.getHotelId());
            preparedStatement.setTimestamp(4, Timestamp.valueOf(entity.getStartDate()));
            preparedStatement.setInt(5, entity.getNoNights());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return entity;
    }

    public Double getValidId() {
        double id = 1.0; // Valoare implicită dacă nu există rezervări în baza de date
        String sql = "SELECT reservationid FROM reservations ORDER BY reservationid DESC LIMIT 1";
        try (
                Connection connection = DriverManager.getConnection(urlDb, usernameDb, passwordDb);
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ) {
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) { // Verifică dacă există un rând în ResultSet
                id = resultSet.getDouble("reservationid") + 1;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return id;
    }

    @Override
    public Reservation delete(Double aDouble) {
        return null;
    }

    @Override
    public Reservation update(Reservation entity) {
        return null;
    }

    public boolean isRoomAvailable(Double hotelId, LocalDateTime startDate, int noNights) {
        String sql = "SELECT COUNT(*) FROM reservations WHERE hotelid = ? AND startdate <= ? AND startdate + INTERVAL '1 day' * nonights >= ?";
        try (
                Connection connection = DriverManager.getConnection(urlDb, usernameDb, passwordDb);
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ) {
            preparedStatement.setDouble(1, hotelId);
            preparedStatement.setTimestamp(2, Timestamp.valueOf(startDate.plusDays(noNights)));
            preparedStatement.setTimestamp(3, Timestamp.valueOf(startDate));

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int reservationsCount = resultSet.getInt(1);
                Hotel hotel = hotelService.findOne(hotelId); // Obține hotelul din baza de date
                if (hotel != null) {
                    return reservationsCount < hotel.getNoRooms(); // Verifică dacă mai sunt camere disponibile
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // În caz de eroare, consideră că nu sunt camere disponibile
    }
}
