package com.example.simularemap.utils;

public class ReservationContext {
    private static ReservationContext instance;
    private Long reservingClientId;

    private ReservationContext() {} // Constructor privat pentru singleton

    public static ReservationContext getInstance() {
        if (instance == null) {
            instance = new ReservationContext();
        }
        return instance;
    }

    public void setReservingClientId(Long reservingClientId) {
        this.reservingClientId = reservingClientId;
    }

    public Long getReservingClientId() {
        return reservingClientId;
    }
}
