﻿namespace Seminar_10;

public abstract class AbstractTaskRunner : TaskRunner
{
    private TaskRunner taskRunner;

    protected AbstractTaskRunner(TaskRunner taskRunner)
    {
        this.taskRunner = taskRunner;
    }

    public virtual void ExecuteOneTask()
    {
        taskRunner.ExecuteOneTask();
    }

    public virtual void ExecuteAll()
    {
        taskRunner.ExecuteAll();
    }

    public virtual void AddTask(Task t)
    {
        taskRunner.AddTask(t);
    }

    public virtual bool HasTask()
    {
        return taskRunner.HasTask();
    }
}