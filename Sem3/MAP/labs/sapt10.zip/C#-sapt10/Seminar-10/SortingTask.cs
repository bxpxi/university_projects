﻿namespace Seminar_10;

public class SortingTask : Task
{
    private int[] numbers;
    private AbstractSorter sorter;

    public SortingTask(int[] numbers, AbstractSorter sorter, string taskID, string description) : base(taskID,
        description)
    {
        this.numbers = numbers;
        this.sorter = sorter;
    }

    public override void execute()
    {
        sorter.Sort(numbers);
        Console.WriteLine("Sorted numbers: " + string.Join(", ", numbers));
    }
}