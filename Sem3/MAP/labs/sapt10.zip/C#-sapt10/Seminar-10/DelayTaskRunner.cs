﻿namespace Seminar_10;

public class DelayTaskRunner : AbstractTaskRunner
{
    public DelayTaskRunner(TaskRunner taskRunner) : base(taskRunner) {}

    public override void ExecuteOneTask()
    {
        try
        {
            Thread.Sleep(3000);
        }
        catch (ThreadInterruptedException e)
        {
            Console.WriteLine($"Task delay interrupted: {e.Message}");
        }
        base.ExecuteOneTask();
    }
    
    public override void ExecuteAll()
    {
        while (HasTask())
        {
            ExecuteOneTask(); 
        }
    }
}