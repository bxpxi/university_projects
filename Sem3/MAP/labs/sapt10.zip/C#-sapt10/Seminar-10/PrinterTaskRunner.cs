﻿namespace Seminar_10;

public class PrinterTaskRunner : AbstractTaskRunner
{
    public PrinterTaskRunner(TaskRunner taskRunner) : base(taskRunner) {}

    public override void ExecuteOneTask()
    {
        base.ExecuteOneTask();
        Console.WriteLine($"Task executed at: {DateTime.Now}");
    }
    
    public override void ExecuteAll()
    {
        while (HasTask())
        {
            ExecuteOneTask();
        }
    }
}