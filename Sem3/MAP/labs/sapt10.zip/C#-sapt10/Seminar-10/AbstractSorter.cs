﻿namespace Seminar_10;

public abstract class AbstractSorter
{
    public abstract void Sort(int[] array);
}