﻿namespace Seminar_10;

public enum Strategy
{
    Lifo,
    Fifo
}