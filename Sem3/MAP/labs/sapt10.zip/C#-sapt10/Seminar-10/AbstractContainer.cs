﻿namespace Seminar_10;

public abstract class AbstractContainer : Container
{
    protected Task[] tasks;
    protected int count;

    protected AbstractContainer(int capacity)
    {
        tasks = new Task[capacity];
        count = 0;
    }

    protected abstract Task RemoveTask();
    
    public Task Remove()
    {
        if (count == 0)
        {
            throw new InvalidOperationException("Container is empty");
        }
        Task removedTask = RemoveTask();
        count--;
        return removedTask;
    }


    public void Add(Task task)
    {
        if (count == tasks.Length)
        {
            throw new InvalidOperationException("Container is full");
        }
        
        InsertTask(task);
        count++;
    }
    
    protected abstract void InsertTask(Task task);

    public int Size()
    {
        return count;
    }

    public bool IsEmpty()
    {
        return count == 0;
    }
}