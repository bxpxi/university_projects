﻿namespace Seminar_10;

public class StrategyTaskRunner : TaskRunner
{
    private Container container;

    public StrategyTaskRunner(Strategy strategy)
    {
        TaskContainerFactory factory = TaskContainerFactory.Instance;
        container = factory.CreateContainer(strategy);
    }

    public void ExecuteOneTask()
    {
        if (container.IsEmpty())
        {
            Console.WriteLine("No tasks to execute");
            return;
        }

        Task task = container.Remove();
        task.execute();
    }

    public void ExecuteAll()
    {
        while (!container.IsEmpty())
        {
            ExecuteOneTask();
        }
    }

    public void AddTask(Task t)
    {
        container.Add(t);
    }

    public bool HasTask()
    {
        return !container.IsEmpty();
    }
}