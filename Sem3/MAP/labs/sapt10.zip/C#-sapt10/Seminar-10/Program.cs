﻿// See https://aka.ms/new-console-template for more information

using Seminar_10;
using Task = Seminar_10.Task;


class Program
{
    static void Main(string[] args)
    {
        RunSomeTests();
        RunTaskRunnerWithStrategy(args);
        RunPrinterTaskRunnerTask(args);
        RunDelayPrinterTaskRunner(args);
    }


    static void RunSomeTests()
    { 
        //messages
        var messageTask=new MessageTask("A", "Salut",DateTime.Now,"1","Messaj");
        var messageTask2=new MessageTask("B", "Salutare",DateTime.Now,"2","Messaj2");
        var messageTask3=new MessageTask("C", "Salutare",DateTime.Now,"3","Messaj3");
        var messageTask4=new MessageTask("D", "Salutare",DateTime.Now,"4","Messaj4");
        var messageTask5=new MessageTask("E", "Salutare",DateTime.Now,"5","Messaj5");

        var tasks = new List<Task>();
        tasks.Add(messageTask);
        tasks.Add(messageTask2);
        tasks.Add(messageTask3);
        tasks.Add(messageTask4);
        tasks.Add(messageTask5);
        for (int i = 0; i < tasks.Count; i++)
        {
            tasks[i].execute();
        }


        //sorting
        Console.WriteLine("\nSorting\n");

        int[] numbers = { 5, 3, 8, 6, 2, 7, 4, 1 };
        AbstractSorter bubbleSort = new BubbleSort();
        Task bubbleSortTask = new SortingTask(numbers, bubbleSort, "1", "bubblesort");
        bubbleSortTask.execute();

        AbstractSorter quickSort = new QuickSort();
        Task quickSortTask = new SortingTask(numbers, quickSort, "2", "quicksort");
        quickSortTask.execute();


        //containers
        QueueContainer queueContainer = new QueueContainer(5);
        queueContainer.Add(messageTask);
        queueContainer.Add(messageTask2);
        queueContainer.Add(messageTask3);
        queueContainer.Add(messageTask4);
        queueContainer.Add(messageTask5);

        Console.WriteLine("\n Queue container is created successfully ");

        while (!queueContainer.IsEmpty())
        {
            Task task = queueContainer.Remove();
            task.execute();
        }

        StackContainer stackContainer = new StackContainer(5);
        stackContainer.Add(messageTask);
        stackContainer.Add(messageTask2);
        stackContainer.Add(messageTask3);
        stackContainer.Add(messageTask4);
        stackContainer.Add(messageTask5);

        Console.WriteLine("\n Stack container is created successfully ");

        while (!stackContainer.IsEmpty())
        {
            Task task = stackContainer.Remove();
            task.execute();
        }



        //factory
        Console.WriteLine("\nFactory\n ");
        var factory = TaskContainerFactory.Instance;

        var lifoContainer = factory.CreateContainer(Strategy.Lifo);
         
        lifoContainer.Add(messageTask);
        lifoContainer.Add(messageTask2);
        lifoContainer.Add(messageTask3);
        lifoContainer.Add(messageTask4);
        lifoContainer.Add(messageTask5);

        Console.WriteLine("\nLIFO\n ");

        var size = lifoContainer.Size();
        for (int i = 0; i < size; i++)
        {
            lifoContainer.Remove().execute();    
        }

        var fifoContainer = factory.CreateContainer(Strategy.Fifo);
         
        fifoContainer.Add(messageTask);
        fifoContainer.Add(messageTask2);
        fifoContainer.Add(messageTask3);
        fifoContainer.Add(messageTask4);
        fifoContainer.Add(messageTask5);

        Console.WriteLine("\nFIFO\n ");

        var size2 = fifoContainer.Size();
        for (int i = 0; i < size2; i++)
        {
            fifoContainer.Remove().execute();    
        }
    }

    static void RunTaskRunnerWithStrategy(string[] args)
    {
        if (args.Length == 0)
        {
            Console.WriteLine("Specify a strategy for TaskRunner");
            return;
        }
        
        Strategy strategy;
        if (args[0].Equals("FIFO", StringComparison.OrdinalIgnoreCase))
        {
            strategy = Strategy.Fifo;
        }
        else if (args[0].Equals("LIFO", StringComparison.OrdinalIgnoreCase))
        {
            strategy = Strategy.Lifo;
        }
        else
        {
            Console.WriteLine("Invalid strategy");
            return;
        }
        
        Console.WriteLine($"\nTesting StrategyTaskRunner with {strategy} strategy:");

        var tasks = new List<Task>
        {
            new MessageTask("A", "Salut", DateTime.Now, "1", "Messaj"),
            new MessageTask("B", "Salutare", DateTime.Now, "2", "Messaj2"),
            new MessageTask("C", "Salutare", DateTime.Now, "3", "Messaj3"),
            new MessageTask("D", "Salutare", DateTime.Now, "4", "Messaj4"),
            new MessageTask("E", "Salutare", DateTime.Now, "5", "Messaj5")
        };
        
        var taskRunner = new StrategyTaskRunner(strategy);

        foreach (var task in tasks)
        {
            taskRunner.AddTask(task);
        }
        
        taskRunner.ExecuteAll();
    }

    static void RunPrinterTaskRunnerTask(string[] args)
    {
        if (args.Length == 0)
        {
            Console.WriteLine("Specify a strategy for TaskRunner");
            return;
        }
        
        Strategy strategy;
        if (args[0].Equals("FIFO", StringComparison.OrdinalIgnoreCase))
        {
            strategy = Strategy.Fifo;
        }
        else if (args[0].Equals("LIFO", StringComparison.OrdinalIgnoreCase))
        {
            strategy = Strategy.Lifo;
        }
        else
        {
            Console.WriteLine("Invalid strategy");
            return;
        }
        
        Console.WriteLine("\nPrinterTaskRunner");

        var tasks = new List<Task>
        {
            new MessageTask("A", "Salut", DateTime.Now, "1", "Messaj"),
            new MessageTask("B", "Salutare", DateTime.Now, "2", "Messaj2"),
            new MessageTask("C", "Salutare", DateTime.Now, "3", "Messaj3"),
            new MessageTask("D", "Salutare", DateTime.Now, "4", "Messaj4"),
            new MessageTask("E", "Salutare", DateTime.Now, "5", "Messaj5")
        };
        
        var strategyRunner = new StrategyTaskRunner(strategy);
        foreach (var task in tasks)
        {
            strategyRunner.AddTask(task);
        }

        var printerTaskRunner = new PrinterTaskRunner(strategyRunner);
        
        printerTaskRunner.ExecuteAll();
    }

    static void RunDelayPrinterTaskRunner(string[] args)
    {
        if (args.Length == 0)
        {
            Console.WriteLine("Specify a strategy for TaskRunner");
            return;
        }
        
        Strategy strategy;
        if (args[0].Equals("FIFO", StringComparison.OrdinalIgnoreCase))
        {
            strategy = Strategy.Fifo;
        }
        else if (args[0].Equals("LIFO", StringComparison.OrdinalIgnoreCase))
        {
            strategy = Strategy.Lifo;
        }
        else
        {
            Console.WriteLine("Invalid strategy");
            return;
        }
        
        Console.WriteLine("\nDelay & Printer TaskRunner");

        var tasks = new List<Task>
        {
            new MessageTask("A", "Salut", DateTime.Now, "1", "Messaj"),
            new MessageTask("B", "Salutare", DateTime.Now, "2", "Messaj2"),
            new MessageTask("C", "Salutare", DateTime.Now, "3", "Messaj3"),
            new MessageTask("D", "Salutare", DateTime.Now, "4", "Messaj4"),
            new MessageTask("E", "Salutare", DateTime.Now, "5", "Messaj5")
        };
        
        var strategyRunner = new StrategyTaskRunner(strategy);
        foreach (var task in tasks)
        {
            strategyRunner.AddTask(task);
        }

        var delayTaskRunner = new DelayTaskRunner(strategyRunner);
        var printerTaskRunner = new PrinterTaskRunner(delayTaskRunner);
        
        printerTaskRunner.ExecuteAll();
    }
}





