﻿namespace Seminar_10;


public class TaskContainerFactory : Factory
{
    private static TaskContainerFactory? instance;
    
    private TaskContainerFactory() { }

    public static TaskContainerFactory Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new TaskContainerFactory();
            }
            return instance;
        }
    }
    
    public Container CreateContainer(Strategy strategy)
    {
        switch (strategy)
        {
            case Strategy.Fifo:
                return new QueueContainer(10);
            case Strategy.Lifo:
                return new StackContainer(10);
            default:
                throw new ArgumentException("Invalid strategy");
        }
    }
}

