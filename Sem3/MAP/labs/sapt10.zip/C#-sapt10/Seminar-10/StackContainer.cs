﻿namespace Seminar_10;
/*
public class StackContainer : Container
{
    private Task[] tasks;
    private int top;

    public StackContainer(int capacity)
    {
        tasks = new Task[capacity];
        top = -1;

    }
    
    public Task Remove()
    {
        if (top > -1)
        {
            Task task = tasks[top];
            tasks[top] = null;
            top--;
            return task;
        }
        throw new InvalidOperationException("Stack container is empty");
    }

    public void Add(Task task)
    {
        if (top < tasks.Length-1)
        {
            top++;
            tasks[top] = task;
        }
        throw new InvalidOperationException("Stack container is full");
    }

    public int Size()
    {
        return top + 1;
    }

    public bool IsEmpty()
    {
        return top == -1;
    }
}

*/

public class StackContainer : AbstractContainer
{
    public StackContainer(int capacity) : base(capacity) { }

    protected override Task RemoveTask()
    {
        Task task = tasks[count-1];
        tasks[count-1] = null;
        return task;
    }

    protected override void InsertTask(Task task)
    {
        tasks[count] = task;
    }
}
