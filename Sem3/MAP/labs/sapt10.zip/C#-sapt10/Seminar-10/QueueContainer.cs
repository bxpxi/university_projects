﻿namespace Seminar_10;

/*
public class QueueContainer: Container
{
    private Task[] tasks;
    private int front;
    private int back;
    private int count;
    
    public QueueContainer(int capacity)
    {
        tasks = new Task[capacity];
        front = 0;
        back = -1;
        count = 0;
    }

    public Task Remove()
    {
        if (count > 0)
        {
            Task task = tasks[front];
            tasks[front] = null;
            front = (front + 1) % tasks.Length;
            count--;
            return task;
        }
        throw new InvalidOperationException("Queue container is empty");
    }

    public void Add(Task task)
    {
        if (count < tasks.Length)
        {
            back = (back + 1) % tasks.Length;
            tasks[back] = task;
            count++;
            return;
        }
        throw new InvalidOperationException("Queue container is full");
    }

    public int Size()
    {
        return count;
    }

    public bool IsEmpty()
    {
        return count == 0;
    }
}
*/

public class QueueContainer : AbstractContainer
{
    private int front;
    private int back;

    public QueueContainer(int capacity) : base(capacity)
    {
        front = 0;
        back = -1;
    }

    protected override Task RemoveTask()
    {
        Task task = tasks[front];
        tasks[front] = null;
        front = (front + 1) % tasks.Length;
        return task;
    }

    protected override void InsertTask(Task task)
    {
        back = (back + 1) % tasks.Length;
        tasks[back] = task;
    }
}