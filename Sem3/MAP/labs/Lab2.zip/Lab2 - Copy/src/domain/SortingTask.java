package domain;

import sorter.AbstractSorter;

import java.util.Arrays;

public class SortingTask extends Task{
    private int[] array;
    private AbstractSorter sorter;

    public SortingTask(String taskID, String descriere, int[] array, AbstractSorter sorter) {
        super(taskID, descriere);
        this.array = array;
        this.sorter = sorter;
    }

    @Override
    public void execute() {
        sorter.sort(array);
        System.out.println(Arrays.toString(array));
    }
}
