package domain;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Message {
    private String id;
    private String subject;
    private String body;
    private String from;
    private String to;
    private LocalDateTime date;

    public Message(String id, String subject, String body, String from, String to, LocalDateTime date) {
        this.id = id;
        this.subject = subject;
        this.body = body;
        this.to = to;
        this.from = from;
        this.date = date;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return "id=" + id + "|description=" + subject + "|message=" + body + "|from=" + from + "|to=" + to + "|date=" + date.format(formatter) + "\n";
    }
}
