package test;

import domain.Message;
import domain.MessageTask;
import factory.Strategy;
import runner.PrinterTaskRunner;
import runner.StrategyTaskRunner;
import runner.TaskRunner;

import java.time.LocalDateTime;

public class TestStrategyTaskRunner {
    public static void main(String[] args) {
        Strategy strategy = Strategy.valueOf(args[0]);
        //StrategyTaskRunner taskRunner = new StrategyTaskRunner(strategy);
        TaskRunner taskRunner = new StrategyTaskRunner(strategy);

        for(int i=0; i<5; i++) {
            Message message = new Message(String.valueOf(i), "Subject " + i, "Body " + i, "From " + i, "To " + i, LocalDateTime.now());
            taskRunner.addTask(new MessageTask("Task " + i, "Descriere " + i, message));
        }

        TaskRunner printerTaskRunner = new PrinterTaskRunner(taskRunner);
        taskRunner.executeAll();
    }
}
