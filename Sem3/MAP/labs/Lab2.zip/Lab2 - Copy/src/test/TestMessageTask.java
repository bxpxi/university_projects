package test;

import domain.Message;
import domain.MessageTask;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TestMessageTask {
    public static void main(String[] args) {
        Message[] messages = {
                new Message("1", "Feedback lab1", "Ai obtinut 9.60", "Gigi", "Ana", LocalDateTime.of(2018, 9, 27, 9, 29)),
                new Message("2", "Lab2", "Ai obtinut 8.50", "Gigi", "Ana", LocalDateTime.of(2018, 10, 4, 10, 30)),
                new Message("3", "Lab3", "Ai obtinut 9.00", "Gigi", "Ana", LocalDateTime.of(2018, 10, 11, 11, 15)),
                new Message("4", "Lab4", "Ai obtinut 10.00", "Gigi", "Ana", LocalDateTime.of(2018, 10, 18, 12, 40)),
                new Message("5", "Lab5", "Ai obtinut 9.80", "Gigi", "Ana", LocalDateTime.of(2018, 10, 25, 13, 55))
        };

        MessageTask[] tasks = new MessageTask[5];
        for( int i = 0; i < 5; i++ ) {
            tasks[i] = new MessageTask("Task" + (i+1), "Task description " + (i+1), messages[i]);
        }

        for(MessageTask task : tasks) {
            task.execute();
        }
    }
}
