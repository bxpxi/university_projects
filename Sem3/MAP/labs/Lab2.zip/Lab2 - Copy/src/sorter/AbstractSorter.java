package sorter;

public abstract class AbstractSorter {
    public abstract void sort(int[] array);
}
