package container;

import domain.Task;

import java.util.LinkedList;
import java.util.Queue;

/*
public class QueueContainer implements Container {
    private Queue<Task> queue;

    public QueueContainer() {
        queue = new LinkedList<>();
    }

    @Override
    public void add(Task task) {
        queue.add(task);
    }

    @Override
    public Task remove() {
        return queue.isEmpty() ? null : queue.poll();
    }

    @Override
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    @Override
    public int size() {
        return queue.size();
    }
}
*/

// REFACTORIZARE

public class QueueContainer extends AbstractContainer {
    @Override
    public Task remove() {
        return tasks.isEmpty() ? null : tasks.removeFirst();
    }
}