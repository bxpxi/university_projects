package container;

import domain.Task;

import java.util.Stack;

/*
public class StackContainer implements Container {
    private Stack<Task> stack;

    public StackContainer() {
        stack = new Stack<>();
    }

    @Override
    public void add(Task task) {
        stack.push(task);
    }

    @Override
    public Task remove() {
        return stack.isEmpty() ? null : stack.pop();
    }

    @Override
    public boolean isEmpty() {
        return stack.isEmpty();
    }

    @Override
    public int size() {
        return stack.size();
    }
}
 */

// REFACTORIZARE

public class StackContainer extends AbstractContainer {
    @Override
    public Task remove() {
        return tasks.isEmpty() ? null : tasks.removeLast();
    }
}
