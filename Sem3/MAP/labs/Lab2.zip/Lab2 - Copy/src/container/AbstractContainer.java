package container;

import domain.Task;

import java.util.LinkedList;

public abstract class AbstractContainer implements Container {
    protected LinkedList<Task> tasks;

    public AbstractContainer() {
        tasks = new LinkedList<>();
    }

    @Override
    public void add(Task task) {
        tasks.add(task);
    }

    @Override
    public int size() {
        return tasks.size();
    }

    @Override
    public boolean isEmpty() {
        return tasks.isEmpty();
    }
}
