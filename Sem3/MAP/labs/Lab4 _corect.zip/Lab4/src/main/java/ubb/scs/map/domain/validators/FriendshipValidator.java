package ubb.scs.map.domain.validators;

import ubb.scs.map.domain.Friendship;
import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.repository.file.UtilizatorRepository;
import ubb.scs.map.repository.memory.InMemoryRepository;

import java.util.Optional;

public class FriendshipValidator implements Validator<Friendship> {
    //private InMemoryRepository<Long, Utilizator> repo;
    private UtilizatorRepository repo;

//    public FriendshipValidator(InMemoryRepository<Long, Utilizator> repo) {
//        this.repo = repo;
//    }

    public FriendshipValidator(UtilizatorRepository repo) {
        if (repo == null) {
            throw new IllegalArgumentException("Repository cannot be null.");
        }
        this.repo = repo;
    }

        @Override
        public void validate(Friendship friendship) throws ValidationException {
            if(friendship.getIdUser1() == null || friendship.getIdUser2() == null) {
                throw new ValidationException("The id cannot be null.");
            }

            Optional<Utilizator> u1 = repo.findOne(friendship.getIdUser1());
            Optional<Utilizator> u2 = repo.findOne(friendship.getIdUser2());

            if(u1.isEmpty() || u2.isEmpty()) {
                throw new ValidationException("The id doesn't exist.");
            }

            if (friendship.getIdUser1().equals(friendship.getIdUser2())) {
                throw new ValidationException("A user cannot be friends with themselves.");
            }

        }
    }
