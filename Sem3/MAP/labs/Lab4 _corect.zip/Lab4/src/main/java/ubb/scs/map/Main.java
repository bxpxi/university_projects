package ubb.scs.map;

import jdk.jshell.execution.Util;
import ubb.scs.map.domain.Friendship;
import ubb.scs.map.domain.Tuple;
import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.domain.validators.FriendshipValidator;
import ubb.scs.map.domain.validators.UtilizatorValidator;
import ubb.scs.map.domain.validators.ValidationException;
import ubb.scs.map.domain.validators.Validator;
import ubb.scs.map.repository.Repository;
import ubb.scs.map.repository.file.UtilizatorRepository;
import ubb.scs.map.repository.memory.InMemoryRepository;
import ubb.scs.map.service.SocialNetwork;
import ubb.scs.map.ui.Console;
import ubb.scs.map.repository.file.FriendshipRespository;

public class Main {
    public static void main(String[] args) {

        UtilizatorRepository repoUser = new UtilizatorRepository(new UtilizatorValidator(), "data/users.txt");
        FriendshipRespository repoFriendship = new FriendshipRespository(new FriendshipValidator(repoUser),"data/prietenii.txt");

//        InMemoryRepository<Long, Utilizator> repoUser = new InMemoryRepository<>(new UtilizatorValidator());
//        InMemoryRepository<Long, Friendship> repoFriendship = new InMemoryRepository<>(new FriendshipValidator(repoUser));

        SocialNetwork socialNetwork = new SocialNetwork(repoUser, repoFriendship);
        Console ui = new Console(socialNetwork);

//        Utilizator u1 = new Utilizator("A", "A");
//        Utilizator u2 = new Utilizator("B", "B");
//        Utilizator u3 = new Utilizator("C", "C");
//        Utilizator u4 = new Utilizator("D", "D");
//        Utilizator u5 = new Utilizator("E", "E");
//        Utilizator u6 = new Utilizator("F", "F");
//        Utilizator u7 = new Utilizator("G", "G");
//        Utilizator u8 = new Utilizator("H", "H");
//
//        socialNetwork.addUser(u1);
//        socialNetwork.addUser(u2);
//        socialNetwork.addUser(u3);
//        socialNetwork.addUser(u4);
//        socialNetwork.addUser(u5);
//        socialNetwork.addUser(u6);
//        socialNetwork.addUser(u7);
//        socialNetwork.addUser(u8);

        ui.runMenu();
    }
}