package ubb.scs.map.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FriendshipTest {

    @Test
    void testCreateFriendship() {
        Friendship friendship = new Friendship(1L, 2L);
        friendship.setId(1L);
        assertEquals(1L, friendship.getId());
        assertEquals(1L, friendship.getIdUser1());
        assertEquals(2L, friendship.getIdUser2());
    }

    @Test
    void testEqualsAndHashCode() {
        Friendship f1 = new Friendship(1L, 2L);
        f1.setId(1L);
        Friendship f2 = new Friendship(1L, 2L);
        f2.setId(1L);
        assertEquals(f1, f2);
        assertEquals(f1.hashCode(), f2.hashCode());
    }
}
