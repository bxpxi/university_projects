package ubb.scs.map.domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UtilizatorTest {
    @Test
    void testCreateUser() {
        Utilizator user = new Utilizator("John", "Doe");
        user.setId(1L);
        assertEquals(1L, user.getId());
        assertEquals("John", user.getFirstName());
        assertEquals("Doe", user.getLastName());
    }

    @Test
    void testEqualsAndHashCode() {
        Utilizator user1 = new Utilizator("John", "Doe");
        user1.setId(1L);
        Utilizator user2 = new Utilizator("John", "Doe");
        user2.setId(1L);
        assertEquals(user1, user2);
        assertEquals(user1.hashCode(), user2.hashCode());
    }
}