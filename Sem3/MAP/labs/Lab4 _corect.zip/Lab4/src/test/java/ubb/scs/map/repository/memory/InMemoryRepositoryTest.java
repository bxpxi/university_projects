package ubb.scs.map.repository.memory;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.domain.validators.UtilizatorValidator;
import ubb.scs.map.repository.file.UtilizatorRepository;

import java.util.Collection;

import static org.junit.jupiter.api.Assertions.*;

class InMemoryRepositoryTest {
    InMemoryRepository<Long, Utilizator> repository;

    @BeforeEach
    void setUp() {
        repository = new InMemoryRepository<>(new UtilizatorValidator());
    }

    @Test
    void testSave() {
        Utilizator user = new Utilizator("John", "Doe");
        user.setId(1L);
        assertNull(repository.save(user));
        assertEquals(1, ((Collection<?>) repository.findAll()).size());
    }

    @Test
    void testFindOne() {
        Utilizator user = new Utilizator("John", "Doe");
        user.setId(1L);
        repository.save(user);
        assertEquals(user, repository.findOne(1L));
    }

    @Test
    void testDelete() {
        Utilizator user = new Utilizator("John", "Doe");
        user.setId(1L);
        repository.save(user);
        repository.delete(1L);
        assertNull(repository.findOne(1L));
    }
}
