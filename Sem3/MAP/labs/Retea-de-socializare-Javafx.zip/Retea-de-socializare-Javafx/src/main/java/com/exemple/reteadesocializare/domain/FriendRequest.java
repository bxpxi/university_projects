package com.exemple.reteadesocializare.domain;

public enum FriendRequest {
    ACCEPTED,
    REJECTED,
    PENDING
}
