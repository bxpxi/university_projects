package com.exemple.reteadesocializare.domain.Constants;

public enum RepoStrategy {
    memory,
    file,
    database
}
