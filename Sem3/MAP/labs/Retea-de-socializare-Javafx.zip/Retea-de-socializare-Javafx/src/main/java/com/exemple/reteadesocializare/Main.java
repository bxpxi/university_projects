package com.exemple.reteadesocializare;

public class Main {
    public static void main(String[] args) {
        MainApp.main(args);
    }
}


