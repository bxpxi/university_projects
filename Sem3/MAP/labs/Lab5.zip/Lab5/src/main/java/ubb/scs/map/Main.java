package ubb.scs.map;

import jdk.jshell.execution.Util;
import ubb.scs.map.domain.Friendship;
import ubb.scs.map.domain.Tuple;
import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.domain.validators.FriendshipValidator;
import ubb.scs.map.domain.validators.UtilizatorValidator;
import ubb.scs.map.domain.validators.ValidationException;
import ubb.scs.map.domain.validators.Validator;
import ubb.scs.map.repository.Repository;
import ubb.scs.map.repository.database.FriendshipDBRepository;
import ubb.scs.map.repository.database.UtilizatorDBRepository;
import ubb.scs.map.repository.file.UtilizatorRepository;
import ubb.scs.map.repository.memory.InMemoryRepository;
import ubb.scs.map.service.SocialNetwork;
import ubb.scs.map.ui.Console;

public class Main {
    public static void main(String[] args) {

        UtilizatorDBRepository repoUser = new UtilizatorDBRepository(new UtilizatorValidator());
        FriendshipDBRepository repoFriendship = new FriendshipDBRepository(new FriendshipValidator(repoUser));

        SocialNetwork socialNetwork = new SocialNetwork(repoUser, repoFriendship);
        Console ui = new Console(socialNetwork);

        ui.runMenu();
    }
}