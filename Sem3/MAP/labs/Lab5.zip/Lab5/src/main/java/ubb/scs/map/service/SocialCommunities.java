package ubb.scs.map.service;

import ubb.scs.map.domain.Friendship;
import ubb.scs.map.domain.Utilizator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SocialCommunities {
    SocialNetwork socialNetwork;
    HashMap<Long, List<Long>> adjList;

    public SocialCommunities(SocialNetwork socialNetwork) {
        this.socialNetwork = socialNetwork;
    }

    /*
     * Depth-First Search (DFS) function that traverses the graph starting from a given vertex (user).
     * Marks the current vertex as visited and recursively visits all its unvisited neighbors.
     *
     * @param vf      - the ID of the user (vertex) from which the DFS starts
     * @param visited - a HashMap that keeps track of visited users
     */
    void DFS(Long vf, HashMap<Long, Boolean> visited, List<Long> community) {
        visited.put(vf, true);
        community.add(vf);
        if (adjList.containsKey(vf)) {
            adjList.get(vf).stream().filter(x -> !visited.containsKey(x)).forEach(x -> DFS(x, visited, community));
        }
    }

    /*
     * Counts the number of connected communities in the social network.
     * Uses DFS to explore each unvisited community.
     *
     * @return int - number of communities
     */
    public int connectedCommunities() {
        adjList = new HashMap<Long, List<Long>>();
        socialNetwork.getUsers().forEach(user ->{
            if(!socialNetwork.getFriends(user).isEmpty()) {
                List<Long> friends = new ArrayList<>();
                socialNetwork.getFriends(user).forEach(friend -> friends.add(friend.getId()));
                adjList.put(user.getId(), friends);
            }
        });

        List<Long> ids = new ArrayList<>();
        socialNetwork.getUsers().forEach(user -> {
            ids.add(user.getId());
        });

        int nr_communities = 0;
        HashMap<Long, Boolean> visited = new HashMap<Long, Boolean>();
        for(Long v : ids) {
            if(!visited.containsKey(v)){
                List<Long> community = new ArrayList<>();
                DFS(v, visited,community);
                if(community.size() >= 2)
                    nr_communities++;
            }
        }

        return nr_communities;
    }

    /*
     * Finds the largest community in the network.
     * Returns the list of user IDs in that community.
     *
     * @return List<Long> - user IDs of the largest community
     */
    public List<Long> mostSocialCommunity() {
        adjList = new HashMap<Long, List<Long>>();

        socialNetwork.getUsers().forEach(user -> {
            List<Long> friends = new ArrayList<>();
            socialNetwork.getFriends(user).forEach(friend -> friends.add(friend.getId()));
            if(!friends.isEmpty()) {
                adjList.put(user.getId(), friends);
            }
        });

        List<Long> ids = new ArrayList<>();
        socialNetwork.getUsers().forEach(user -> {
            ids.add(user.getId());
        });

        HashMap<Long, Boolean> visited = new HashMap<Long, Boolean>();
        List<Long> communityMax = new ArrayList<>();

        for(Long v : ids) {
            if(!visited.containsKey(v)){
                List<Long> community = new ArrayList<>();
                DFS(v, visited,community);
                if(community.size() > communityMax.size()) {
                    communityMax = community;
                }
            }
        }
        return communityMax;
    }
}
