package ubb.scs.map.repository.database;

import ubb.scs.map.domain.Friendship;

import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.domain.validators.FriendshipValidator;
import ubb.scs.map.repository.Repository;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class FriendshipDBRepository implements Repository<Long, Friendship> {
    FriendshipValidator friendshipValidator;

    public FriendshipDBRepository(FriendshipValidator friendshipValidator) {
        this.friendshipValidator = friendshipValidator;
    }

    @Override
    public Optional<Friendship> findOne(Long id) {
        String sql = "SELECT * FROM \"FRIENDSHIPS\" WHERE \"ID\" = ?";
        Friendship friendship = null;

        try(Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SocialNetwork", "postgres", "Bobby");
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setLong(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()) {
                Long idFriend1 = resultSet.getLong("IDFriend1");
                Long idFriend2 = resultSet.getLong("IDFriend2");
                Timestamp date = resultSet.getTimestamp("FriendsFrom");
                LocalDateTime friendsFrom = new java.sql.Timestamp(date.getTime()).toLocalDateTime();
                friendship = new Friendship(idFriend1, idFriend2, friendsFrom);
                friendship.setId(id);
            }

        } catch(SQLException e) {
            throw new RuntimeException(e);
        }

        return Optional.ofNullable(friendship);
    }

    @Override
    public Iterable<Friendship> findAll() {
        String sql = "SELECT * FROM \"FRIENDSHIPS\"";
        HashMap<Long, Friendship> friendships = new HashMap<>();

        try(Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SocialNetwork", "postgres", "Bobby");
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()) {
                Long id = resultSet.getLong("ID");
                Long idFriend1 = resultSet.getLong("IDFriend1");
                Long idFriend2 = resultSet.getLong("IDFriend2");
                Timestamp date = resultSet.getTimestamp("FriendsFrom");
                LocalDateTime friendsFrom = LocalDateTime.ofInstant(date.toInstant(), ZoneOffset.ofHours(0));
                Friendship friendship = new Friendship(idFriend1, idFriend2, friendsFrom);
                friendship.setId(id);
                friendships.put(id, friendship);
            }
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }

        return friendships.values();
    }

    @Override
    public Optional<Friendship> save(Friendship friendship) {
        if(friendship == null) {
            throw new IllegalArgumentException("Friendship cannot be null");
        }

        String sql = "INSERT INTO \"FRIENDSHIPS\" (\"IDFriend1\", \"IDFriend2\") VALUES (?, ?)";
        try(Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SocialNetwork", "postgres", "Bobby");
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setLong(1, friendship.getIdUser1());
            preparedStatement.setLong(2, friendship.getIdUser2());
            preparedStatement.executeUpdate();
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }

        return Optional.of(friendship);
    }

    @Override
    public Optional<Friendship> delete(Long id) {
        String sql = "DELETE FROM \"FRIENDSHIPS\" WHERE \"ID\" = ?";

        try(Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SocialNetwork", "postgres", "Bobby");
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setLong(1, id);
            preparedStatement.executeUpdate();
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }

        Friendship friendshipDeleted = null;
        for(Friendship f : findAll()) {
            if(f.getId().equals(id)) {
                friendshipDeleted = f;
            }
        }

        return Optional.ofNullable(friendshipDeleted);
    }

    @Override
    public Optional<Friendship> update(Friendship friendship) {
        return Optional.empty();
    }
}
