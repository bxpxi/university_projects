//package ubb.scs.map.repository.file;
//
//import ubb.scs.map.domain.Friendship;
//import ubb.scs.map.domain.Utilizator;
//import ubb.scs.map.domain.validators.Validator;
//
//import java.util.List;
//
//public class FriendshipRespository extends AbstractFileRepository<Long, Friendship> {
//    public FriendshipRespository(Validator<Friendship> validator, String filename) {
//        super(validator, filename);
//    }
//
//    @Override
//    public Friendship createEntity(List<String> attributes) {
//        Long id1 = Long.parseLong(attributes.get(1));
//        Long id2 = Long.parseLong(attributes.get(2));
//        Friendship friendship = new Friendship(id1, id2);
//        friendship.setId(Long.parseLong(attributes.get(0)));
//        return friendship;
//    }
//
//    @Override
//    public String saveEntity(Friendship entity) {
//        String s = entity.getId() + ";" + entity.getIdUser1() + ";" + entity.getIdUser2();
//        return s;
//    }
//}
