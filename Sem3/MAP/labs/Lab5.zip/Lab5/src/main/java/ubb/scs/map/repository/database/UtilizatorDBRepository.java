package ubb.scs.map.repository.database;

import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.domain.validators.UtilizatorValidator;
import ubb.scs.map.repository.Repository;

import java.sql.*;
import java.util.HashMap;
import java.util.Optional;

public class UtilizatorDBRepository implements Repository<Long, Utilizator> {
    UtilizatorValidator utilizatorValidator;

    public UtilizatorDBRepository(UtilizatorValidator utilizatorValidator) {
        this.utilizatorValidator = utilizatorValidator;
    }

    @Override
    public Optional<Utilizator> findOne(Long id) {
        String sql = "SELECT * FROM \"USERS\" WHERE \"ID\"=?";
        Utilizator utilizator = null;

        try(Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SocialNetwork", "postgres", "Bobby");
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setLong(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()) {
                String firstName = resultSet.getString("FirstName");
                String lastName = resultSet.getString("LastName");
                utilizator = new Utilizator(firstName, lastName);
                utilizator.setId(id);
            }
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }
        return Optional.ofNullable(utilizator);
    }

    @Override
    public Iterable<Utilizator> findAll() {
        String sql = "SELECT * FROM \"USERS\"";
        HashMap<Long, Utilizator> utilizatori = new HashMap<>();

        try(Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SocialNetwork", "postgres", "Bobby");
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()) {
                Long id = resultSet.getLong("ID");
                String firstName = resultSet.getString("FirstName");
                String lastName = resultSet.getString("LastName");
                Utilizator utilizator = new Utilizator(firstName, lastName);
                utilizator.setId(id);
                utilizatori.put(id, utilizator);
            }
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }
        return utilizatori.values();
    }

    @Override
    public Optional<Utilizator> save(Utilizator utilizator) {
        if(utilizator == null) {
            throw new IllegalArgumentException("User cannot be null");
        }

        String sql = "INSERT INTO \"USERS\"(\"FirstName\", \"LastName\") VALUES(?,?)";

        try(Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SocialNetwork", "postgres", "Bobby");
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, utilizator.getFirstName());
            preparedStatement.setString(2, utilizator.getLastName());
            preparedStatement.executeUpdate();
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }

        return Optional.of(utilizator);
    }

    @Override
    public Optional<Utilizator> delete(Long id) {
        String sql = "DELETE FROM \"USERS\" WHERE \"ID\"=?";

        try(Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SocialNetwork", "postgres", "Bobby");
            PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setLong(1, id);
            preparedStatement.executeUpdate();
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }

        Utilizator utilizatorSters = null;
        for(Utilizator u : findAll()) {
            if(u.getId() == id) {
                utilizatorSters = u;
            }
        }

        return Optional.ofNullable(utilizatorSters);
    }

    @Override
    public Optional<Utilizator> update(Utilizator utilizator) {
        return Optional.empty();
    }

}
