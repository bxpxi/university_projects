package ubb.scs.map.ui;

import ubb.scs.map.domain.Friendship;
import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.domain.validators.ValidationException;
import ubb.scs.map.service.SocialCommunities;
import ubb.scs.map.service.SocialNetwork;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

public class Console {
    private SocialNetwork socialNetwork;
    private SocialCommunities socialCommunities;

    public Console(SocialNetwork socialNetwork) {
        this.socialNetwork = socialNetwork;
        this.socialCommunities = new SocialCommunities(socialNetwork);
    }

    /*
     * Displays the menu options for the user.
     */
    void printMenu() {
        System.out.println("Menu:");
        System.out.println("1. Add user");
        System.out.println("2. Remove user");
        System.out.println("3. Add friendship");
        System.out.println("4. Remove friendship");
        System.out.println("5. List users");
        System.out.println("6. List friendships");
        System.out.println("7. Number of communities");
        System.out.println("8. The most social community");
        System.out.println("0. Exit");
    }

    /*
     * Runs the main menu loop, allowing the user to select different options
     * such as adding/removing users or friendships, and displaying data.
     */
    public void runMenu() {
        Scanner scan = new Scanner(System.in);
        boolean ok = true;
        while(ok) {
            printMenu();
            String input = scan.nextLine();
            switch (input) {
                case "1":
                    addUser();
                    break;
                case "2":
                    removeUser();
                    break;
                case "3":
                    addFriendship();
                    break;
                case "4":
                    removeFriendship();
                    break;
                case "5":
                    printUsers();
                    break;
                case "6":
                    printFriendships();
                    break;
                case "7":
                    printConnectedCommunities();
                    break;
                case "8":
                    printMostSocialCommunity();
                    break;
                case "0":
                    ok = false;
                    break;
                default:
                    System.out.println("Invalid input");
                    break;
            }
        }
    }

    /*
     * Prints all users currently in the social network.
     */
    void printUsers() {
        System.out.println("Users:");
        socialNetwork.getUsers().forEach(u -> {
            System.out.println("Id: " + u.getId() + " First name: " + u.getFirstName() + " Last name: " + u.getLastName());
        });
    }

    /*
     * Prompts the user for first and last name and adds a new user to the social network.
     * Handles validation errors if the user data is invalid.
     */
    void addUser(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter first name: ");
        String firstName = scan.nextLine();
        System.out.println("Enter last name: ");
        String lastName = scan.nextLine();

        try {
            socialNetwork.addUser(new Utilizator(firstName, lastName));
        } catch (ValidationException e) {
            System.out.println("Invalid user.");
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid arguments.");
        }
    }

    /*
     * Prompts the user for an ID and removes the user with that ID from the social network.
     * Handles errors if the user doesn't exist or the ID is invalid.
     */
    void removeUser(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter id: ");
        String idString = scan.nextLine();

        try {
            Long id = Long.parseLong(idString);
            Utilizator user = socialNetwork.removeUser(id);
            if(user == null)
                throw new ValidationException("User not found");
            System.out.println("User removed.");
        } catch (ValidationException e) {
            System.out.println("Invalid user.");
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid id.");
        }
    }

    /*
     * Prints all friendships in the social network, along with the list of friends for each user.
     */
    void printFriendships(){
        socialNetwork.getUsers().forEach(u -> {
            if(socialNetwork.getFriends(u).size() > 0) {
                System.out.println("Id: " + u.getId() + " First name: " + u.getFirstName() + " Last name: " + u.getLastName() + " Number of friends: " + socialNetwork.getFriends(u).size());
                System.out.println("+User's friends: ");
                socialNetwork.getFriends(u).forEach(friend -> {
                    System.out.println("-> Id: " + friend.getId() + " First name: " + friend.getFirstName() + " Last name: " + friend.getLastName());
                    System.out.println();
                });
            }
        });
    }

    /*
     * Prompts the user for the IDs of two users and adds a friendship between them.
     * Handles validation errors if the friendship is invalid or if the IDs are invalid.
     */
    void addFriendship(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter id of User1: ");
        String id1String = scan.nextLine();
        System.out.println("Enter id of User2: ");
        String id2String = scan.nextLine();

        try {
            Long id1 = 0L;
            Long id2 = 0L;
            try {
                id1 = Long.parseLong(id1String);
                id2 = Long.parseLong(id2String);
            } catch(IllegalArgumentException e) {
                System.out.println("Invalid id. Id must be a number.");
            }
            socialNetwork.addFriendship(new Friendship(id1, id2, LocalDateTime.now()));
        } catch(ValidationException e) {
            System.out.println("Invalid friendship.");
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid arguments.");
        }
    }

    /*
     * Prompts the user for the IDs of two users and removes the friendship between them.
     * Handles errors if the friendship doesn't exist or the IDs are invalid.
     */
    void removeFriendship(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter id of User1: ");
        String id1String = scan.nextLine();
        System.out.println("Enter id of User2: ");
        String id2String = scan.nextLine();

        try {
            Long id1 = 0L;
            Long id2 = 0L;
            try{
                id1 = Long.parseLong(id1String);
                id2 = Long.parseLong(id2String);
            } catch(IllegalArgumentException e) {
                System.out.println("Invalid id. Id must be a number.");
            }
            socialNetwork.removeFriendship(new Friendship(id1, id2, LocalDateTime.now()));
        } catch(ValidationException e) {
            System.out.println("Invalid friendship.");
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid arguments.");
        }
    }

    /*
     * Prints the total number of connected communities in the social network.
     */
    void printConnectedCommunities(){
        int nr_communities = socialCommunities.connectedCommunities();
        System.out.println("Number of communities: " + nr_communities);
    }

    /*
     * Prints the IDs of users in the largest (most social) community in the network.
     */
    void printMostSocialCommunity(){
        List<Long> mostSocial = socialCommunities.mostSocialCommunity();
        mostSocial.forEach(u -> System.out.println("User's id: "+ u));
    }
}
