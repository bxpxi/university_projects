package ubb.scs.map.service;

import ubb.scs.map.domain.Friendship;
import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.domain.validators.ValidationException;
import ubb.scs.map.repository.database.UtilizatorDBRepository;
import ubb.scs.map.repository.database.FriendshipDBRepository;
import ubb.scs.map.repository.memory.InMemoryRepository;
import ubb.scs.map.repository.file.UtilizatorRepository;
//import ubb.scs.map.repository.file.FriendshipRespository;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class SocialNetwork {
   private final UtilizatorDBRepository repoUser;
   private final FriendshipDBRepository repoFriendship;

    public SocialNetwork(UtilizatorDBRepository repoUser, FriendshipDBRepository repoFriendship) {
        this.repoUser = repoUser;
        this.repoFriendship = repoFriendship;
    }


    /*
     * Retrieves all users from the repository.
     *
     * @return Iterable<Utilizator> - an iterable collection of all users
     */
    public Iterable<Utilizator> getUsers() {
        return repoUser.findAll();
    }

    /*
     * Finds a user by their ID.
     *
     * @param id - the ID of the user to find
     * @return Utilizator - the user with the given ID or throw ValidationException if not found
     */
    public Utilizator findUser(Long id) {
        return repoUser.findOne(id).orElseThrow(()->new ValidationException("User not found"));
    }

    /*
     * Adds a new user to the repository.
     *
     * @param u - the user to be added
     */
    public void addUser(Utilizator u) {
        repoUser.save(u);
    }

    /*
     * Retrieves all friendships from the repository.
     *
     * @return Iterable<Friendship> - an iterable collection of all friendships
     */
    public Iterable<Friendship> getFriendships() {
        return repoFriendship.findAll();
    }

    public List<Utilizator> getFriends(Utilizator utilizator) {
        List<Utilizator> friends = new ArrayList<>();
        getFriendships().forEach(friendship -> {
            if(friendship.getIdUser1().equals(utilizator.getId())) {
                friends.add(findUser(friendship.getIdUser2()));
            } else if(friendship.getIdUser2().equals(utilizator.getId())) {
                friends.add(findUser(friendship.getIdUser1()));
            }
        });
        return friends;
    }

    /*
     * Removes a user by their ID, along with all their friendships.
     * Removes the user from the friend lists of their friends.
     *
     * @param id - the ID of the user to be removed
     * @return Utilizator - the removed user, or null if the user doesn't exist
     */
    public Utilizator removeUser(Long id) {
        try {
            Utilizator u = repoUser.findOne(id).orElseThrow(()->new ValidationException("User not found"));

            Vector<Long> toDelete = new Vector<>();
            getFriendships().forEach(friendship -> {
                if (friendship.getIdUser1().equals(id) || friendship.getIdUser2().equals(id))
                    toDelete.add(friendship.getId());
            });

            toDelete.forEach(repoFriendship::delete);

            repoUser.delete(id).orElseThrow(()->new ValidationException("User not found"));

            return u;

        } catch(IllegalArgumentException e) {
            System.out.println("Invalid user.");
        } catch(ValidationException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }


    /*
     * Adds a new friendship between two users.
     * Validates that the friendship doesn't already exist, that both users exist, and that the users are different.
     *
     * @param friendship - the friendship to be added
     * @throws ValidationException if the friendship already exists, if the users don't exist, or if the IDs are the same
     */
    public void addFriendship(Friendship friendship) {
        Utilizator user1 = null;
        Utilizator user2 = null;

        try{
            user1 = repoUser.findOne(friendship.getIdUser1()).orElseThrow(ValidationException::new);
            user2 = repoUser.findOne(friendship.getIdUser2()).orElseThrow(ValidationException::new);
        } catch(ValidationException e) {
            System.out.println(e.getMessage());
        }

        if(getFriendships() != null){
            getFriendships().forEach(f -> {
                if(f.getIdUser1().equals(friendship.getIdUser1()) && f.getIdUser2().equals(friendship.getIdUser2()))
                    throw new ValidationException("Friendship already exists");
                    });
            if(repoUser.findOne(friendship.getIdUser1()).isEmpty() || repoUser.findOne(friendship.getIdUser2()).isEmpty()) {
                throw new ValidationException("The user doesn't exist.");
            }
            if(friendship.getIdUser1().equals(friendship.getIdUser2())) {
                throw new ValidationException("The Ids cannot be the same.");
            }
        }

        repoFriendship.save(friendship);
    }

    /*
     * Removes a friendship between two users.
     * If the friendship exists, it is deleted and both users are removed from each other's friend lists.
     *
     * @param friendship - the friendship to be removed
     * @throws ValidationException if the friendship doesn't exist
     */
    public void removeFriendship(Friendship friendship) {
        Utilizator user1 = null;
        Utilizator user2 = null;

        try {
            user1 = repoUser.findOne(friendship.getIdUser1()).orElseThrow(() -> new ValidationException("User not found"));
            user2 = repoUser.findOne(friendship.getIdUser2()).orElseThrow(() -> new ValidationException("User not found"));
        } catch(ValidationException e) {
            System.out.println(e.getMessage());
        }

        Long id = 0L;
        for(Friendship f : getFriendships())
            if(f.getIdUser1().equals(friendship.getIdUser1()) || f.getIdUser2().equals(friendship.getIdUser2()))
                id = f.getId();

        if(id == 0L)
            throw new ValidationException("The friendship doesn't exist.");

        repoFriendship.delete(id);
    }
}
