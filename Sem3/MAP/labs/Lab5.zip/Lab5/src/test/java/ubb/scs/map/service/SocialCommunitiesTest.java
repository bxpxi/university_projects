package ubb.scs.map.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ubb.scs.map.domain.Friendship;
import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.domain.validators.FriendshipValidator;
import ubb.scs.map.domain.validators.UtilizatorValidator;
import ubb.scs.map.domain.validators.ValidationException;
import ubb.scs.map.repository.memory.InMemoryRepository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

class SocialCommunitiesTest {
    private SocialNetwork socialNetwork;
    private SocialCommunities socialCommunities;

    @BeforeEach
    void setUp() {
        InMemoryRepository<Long, Utilizator> utilizatorRepo = new InMemoryRepository<>(new UtilizatorValidator());
        InMemoryRepository<Long, Friendship> friendshipRepo = new InMemoryRepository<>(new FriendshipValidator(utilizatorRepo));
        socialNetwork = new SocialNetwork(utilizatorRepo, friendshipRepo);
        socialCommunities = new SocialCommunities(socialNetwork);
    }

    @Test
    void testConnectedCommunities() {
        Utilizator user1 = new Utilizator("John", "Doe");
        Utilizator user2 = new Utilizator("Jane", "Doe");
        Utilizator user3 = new Utilizator("Sam", "Smith");
        Utilizator user4 = new Utilizator("Mary", "Smith");

        socialNetwork.addUser(user1);
        socialNetwork.addUser(user2);
        socialNetwork.addUser(user3);
        socialNetwork.addUser(user4);

        socialNetwork.addFriendship(new Friendship(user1.getId(), user2.getId()));
        socialNetwork.addFriendship(new Friendship(user3.getId(), user4.getId()));

        assertEquals(2, socialCommunities.connectedCommunities());
    }

//    @Test
//    void testMostSocialCommunity() {
//        Utilizator user1 = new Utilizator("John", "Doe");
//        Utilizator user2 = new Utilizator("Jane", "Doe");
//        Utilizator user3 = new Utilizator("Sam", "Smith");
//
//        socialNetwork.addUser(user1);
//        socialNetwork.addUser(user2);
//        socialNetwork.addUser(user3);
//
//
//        try {
//            socialNetwork.addFriendship(new Friendship(user1.getId(), user2.getId()));
//            socialNetwork.addFriendship(new Friendship(user1.getId(), user3.getId()));
//            socialNetwork.addFriendship(new Friendship(user2.getId(), user3.getId()));
//        } catch (ValidationException e) {
//            fail("Friendship already exists: " + e.getMessage());
//        }
//
//
//        List<Long> mostSocialCommunity = socialCommunities.mostSocialCommunity();
//        assertEquals(3, mostSocialCommunity.size());
//        assertTrue(mostSocialCommunity.contains(user1.getId()));
//        assertTrue(mostSocialCommunity.contains(user2.getId()));
//        assertTrue(mostSocialCommunity.contains(user3.getId()));
//    }

    @Test
    void testMostSocialCommunityWithNoFriendships() {
        Utilizator user1 = new Utilizator("John", "Doe");
        Utilizator user2 = new Utilizator("Jane", "Doe");

        socialNetwork.addUser(user1);
        socialNetwork.addUser(user2);

        List<Long> mostSocialCommunity = socialCommunities.mostSocialCommunity();
        assertEquals(0, mostSocialCommunity.size());
    }
}
