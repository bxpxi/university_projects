package ubb.scs.map.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ubb.scs.map.domain.Friendship;
import ubb.scs.map.domain.Utilizator;
import ubb.scs.map.domain.validators.FriendshipValidator;
import ubb.scs.map.domain.validators.UtilizatorValidator;
import ubb.scs.map.domain.validators.ValidationException;
import ubb.scs.map.repository.memory.InMemoryRepository;

import static org.junit.jupiter.api.Assertions.*;

class SocialNetworkTest {
    private SocialNetwork socialNetwork;

    @BeforeEach
    void setUp() {
        InMemoryRepository<Long, Utilizator> utilizatorRepo = new InMemoryRepository<>(new UtilizatorValidator());
        InMemoryRepository<Long, Friendship> friendshipRepo = new InMemoryRepository<>(new FriendshipValidator(utilizatorRepo));
        socialNetwork = new SocialNetwork(utilizatorRepo, friendshipRepo);
    }

    @Test
    void testAddUser() {
        Utilizator user = new Utilizator("John", "Doe");
        socialNetwork.addUser(user);
        assertNotNull(user.getId());
        assertEquals(1L, user.getId());
        assertEquals(1, socialNetwork.getUsers().spliterator().getExactSizeIfKnown());
    }

    @Test
    void testRemoveUser() {
        Utilizator user = new Utilizator("Jane", "Doe");
        socialNetwork.addUser(user);
        Long userId = user.getId();

        assertEquals(user, socialNetwork.removeUser(userId));
        assertNull(socialNetwork.findUser(userId));
    }

    @Test
    void testAddFriendship() {
        Utilizator user1 = new Utilizator("John", "Doe");
        Utilizator user2 = new Utilizator("Jane", "Doe");
        socialNetwork.addUser(user1);
        socialNetwork.addUser(user2);

        Friendship friendship = new Friendship(user1.getId(), user2.getId());
        socialNetwork.addFriendship(friendship);

        assertEquals(1, socialNetwork.getFriendships().spliterator().getExactSizeIfKnown());
    }

    @Test
    void testRemoveFriendship() {
        Utilizator user1 = new Utilizator("John", "Doe");
        Utilizator user2 = new Utilizator("Jane", "Doe");
        socialNetwork.addUser(user1);
        socialNetwork.addUser(user2);

        Friendship friendship = new Friendship(user1.getId(), user2.getId());
        socialNetwork.addFriendship(friendship);
        socialNetwork.removeFriendship(friendship);

        assertEquals(0, socialNetwork.getFriendships().spliterator().getExactSizeIfKnown());
    }

    @Test
    void testAddDuplicateFriendship() {
        Utilizator user1 = new Utilizator("John", "Doe");
        Utilizator user2 = new Utilizator("Jane", "Doe");
        socialNetwork.addUser(user1);
        socialNetwork.addUser(user2);

        Friendship friendship = new Friendship(user1.getId(), user2.getId());
        socialNetwork.addFriendship(friendship);

        assertThrows(ValidationException.class, () -> socialNetwork.addFriendship(friendship));
    }

    @Test
    void testRemoveNonExistentFriendship() {
        Utilizator user1 = new Utilizator("John", "Doe");
        Utilizator user2 = new Utilizator("Jane", "Doe");
        socialNetwork.addUser(user1);
        socialNetwork.addUser(user2);

        Friendship friendship = new Friendship(user1.getId(), user2.getId());

        assertThrows(ValidationException.class, () -> socialNetwork.removeFriendship(friendship));
    }
}
