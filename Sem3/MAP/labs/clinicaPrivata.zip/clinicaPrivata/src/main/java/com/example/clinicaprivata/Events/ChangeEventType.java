package com.example.clinicaprivata.Events;

public enum ChangeEventType {
    ADD,UPDATE,DELETE;
}

