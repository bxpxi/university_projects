package com.example.clinicaprivata.Events;

public interface Event {
}
