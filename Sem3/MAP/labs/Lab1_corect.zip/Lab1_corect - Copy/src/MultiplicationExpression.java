public class MultiplicationExpression extends ComplexExpression{
    public MultiplicationExpression(ComplexNumber[] args) {
        super(args);
    }

    @Override
    public ComplexNumber executeOneOperation(ComplexNumber num1, ComplexNumber num2) {
        return num1.multiply(num2);
    }
}
