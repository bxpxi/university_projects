import java.text.DecimalFormat;

public class ComplexNumber {
    private double re;
    private double im;

    public ComplexNumber(double re, double im) {
        this.re = re;
        this.im = im;
    }

    public double getRe() {
        return re;
    }

    public double getIm() {
        return im;
    }

    public ComplexNumber conjugate() {
        return new ComplexNumber(this.re, -this.im);
    }

    public ComplexNumber add(ComplexNumber other) {
        return new ComplexNumber(this.re + other.re, this.im + other.im);
    }

    public ComplexNumber subtract(ComplexNumber other) {
        return new ComplexNumber(this.re - other.re, this.im - other.im);
    }

    public ComplexNumber multiply(ComplexNumber other) {
        return new ComplexNumber(this.re*other.re - this.im*other.im, this.re*other.im + this.im*other.re);
    }

    public ComplexNumber divide(ComplexNumber other) {
        double denominator = other.re * other.re + other.im * other.im;
        if(denominator == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        return new ComplexNumber((this.re * other.re + this.im * other.im)/denominator, (this.im * other.re - this.re * other.im)/denominator);
    }

    @Override
    public String toString() {
        DecimalFormat df = new DecimalFormat("#.00");
        String real = df.format(this.re);
        String imag = df.format(this.im);
        return real + (im >= 0 ? " + " : " ") + imag + "*i";
    }
}
