public class ExpressionFactory {
    private static ExpressionFactory instance = new ExpressionFactory();

    private ExpressionFactory() {}

    public static ExpressionFactory getInstance() {
        return instance;
    }

    public ComplexExpression createExpression(Operation operation, ComplexNumber[] args) {
        switch(operation) {
            case ADDITION :
                return new AdditionExpression(args);
            case SUBTRACTION :
                return new SubtractionExpression(args);
            case MULTIPLICATION :
                return new MultiplicationExpression(args);
            case DIVISION :
                return new DivisionExpression(args);
            default :
                throw new IllegalArgumentException("Invalid operation.");
        }
    }
}
