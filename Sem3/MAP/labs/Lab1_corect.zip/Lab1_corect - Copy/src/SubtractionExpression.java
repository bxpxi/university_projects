public class SubtractionExpression extends ComplexExpression{
    public SubtractionExpression(ComplexNumber[] args) {
        super(args);
    }

    @Override
    public ComplexNumber executeOneOperation(ComplexNumber num1, ComplexNumber num2) {
        return num1.subtract(num2);
    }
}
