import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExpressionParser {
   public static ComplexNumber parse(String[] args) {
       ArrayList<ComplexNumber> numbers = new ArrayList<>();
       ArrayList<Operation> operations = new ArrayList<>();

       for(int i = 0; i < args.length; i++) {
           String arg = args[i];

           if(i%2 == 1) {
               switch (arg) {
                   case "+":
                       operations.add(Operation.ADDITION);
                       break;
                   case "-":
                       operations.add(Operation.SUBTRACTION);
                       break;
                   case "*":
                       operations.add(Operation.MULTIPLICATION);
                       break;
                   case "/":
                       operations.add(Operation.DIVISION);
                       break;
                   default:
                       throw new IllegalArgumentException("Invalid operation: " + arg);
               }
           }else {
               numbers.add(parseComplexNumber(arg));
           }
       }

       ArrayList<ComplexNumber> intermediateResults = new ArrayList<>();
       ArrayList<Operation> remainingOperations = new ArrayList<>();
       intermediateResults.add(numbers.get(0));

       for(int i =1; i< numbers.size(); i++) {
           if(operations.get(i-1) == Operation.MULTIPLICATION || operations.get(i-1) == Operation.DIVISION) {
               ComplexExpression expression = ExpressionFactory.getInstance().createExpression(operations.get(i-1), new ComplexNumber[]{intermediateResults.get(intermediateResults.size()-1), numbers.get(i)});
               intermediateResults.set(intermediateResults.size() - 1, expression.execute());
           }else {
               intermediateResults.add(numbers.get(i));
               remainingOperations.add(operations.get(i-1));
           }
       }

       ComplexNumber finalResult = intermediateResults.get(0);

       for(int i=1; i< intermediateResults.size(); i++) {
           if(remainingOperations.get(i-1) == Operation.ADDITION) {
               ComplexExpression expression = ExpressionFactory.getInstance().createExpression(Operation.ADDITION, new ComplexNumber[]{finalResult, intermediateResults.get(i)});
               finalResult = expression.execute();
           }else if(remainingOperations.get(i-1) == Operation.SUBTRACTION) {
                ComplexExpression expression = ExpressionFactory.getInstance().createExpression(Operation.SUBTRACTION, new ComplexNumber[]{finalResult, intermediateResults.get(i)});
                finalResult = expression.execute();
           }
       }
       return finalResult;
   }

   private static ComplexNumber parseComplexNumber(String number) {
       Pattern pattern = Pattern.compile("([-]?\\d+\\.?\\d*)\\s*([+-])\\s*(\\d+\\.?\\d*)\\*i");
       Matcher matcher = pattern.matcher(number);
       if (!matcher.matches()) throw new IllegalArgumentException("Invalid complex number: " + number);

       double re = Double.parseDouble(matcher.group(1));
       double im = Double.parseDouble(matcher.group(3)) * (matcher.group(2).equals("-") ? -1 : 1);
       return new ComplexNumber(re, im);
   }
}
