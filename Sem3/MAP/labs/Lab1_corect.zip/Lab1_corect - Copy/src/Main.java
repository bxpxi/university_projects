import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter expression (n1 op n2 ...): ");
        String input = scanner.nextLine();

        String[] tokens = input.split(" ");

        try {
            ComplexNumber result = ExpressionParser.parse(tokens);
            System.out.println("Result: " + result);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        scanner.close();
    }
}