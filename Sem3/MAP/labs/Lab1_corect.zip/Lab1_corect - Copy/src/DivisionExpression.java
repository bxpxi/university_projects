public class DivisionExpression extends ComplexExpression {
    public DivisionExpression(ComplexNumber[] args) {
        super(args);
    }

    @Override
    public ComplexNumber executeOneOperation(ComplexNumber num1, ComplexNumber num2) {
        return num1.divide(num2);
    }
}
