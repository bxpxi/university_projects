public abstract class ComplexExpression {
    protected ComplexNumber[] args;

    public ComplexExpression(ComplexNumber[] args) {
        this.args = args;
    }

    protected abstract ComplexNumber executeOneOperation(ComplexNumber num1, ComplexNumber num2);

    public ComplexNumber execute() {
        ComplexNumber result = args[0];
        for (int i = 1; i < args.length; i++) {
            result = executeOneOperation(result, args[i]);
        }
        return result;
    }
}
