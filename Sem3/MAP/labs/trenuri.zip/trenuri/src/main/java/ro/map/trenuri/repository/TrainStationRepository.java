package ro.map.trenuri.repository;

import ro.map.trenuri.domain.TrainStation;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TrainStationRepository {
    private Connection connection;

    public TrainStationRepository(Connection connection) {
        this.connection = connection;
    }

    public List<TrainStation> getAllTrainStations() {
        List<TrainStation> trainStations = new ArrayList<>();
        String sql = "SELECT * FROM trainstations";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String trainId = rs.getString("trainid");
                String departureCityId = rs.getString("departurecityid");
                String destinationCityId = rs.getString("destinationcityid");
                trainStations.add(new TrainStation(trainId, departureCityId, destinationCityId));
            }
        } catch (SQLException e) {
            System.err.println("Eroare la citirea statiilor de tren din baza de date: " + e.getMessage());
        }

        return trainStations;
    }

    public List<TrainStation> findTrainStationsByDepartureCity(String departureCityId) {
        List<TrainStation> trainStations = new ArrayList<>();
        String sql = "SELECT * FROM trainstations WHERE departurecityid = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, departureCityId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String trainId = rs.getString("trainid");
                String destCityId = rs.getString("destinationcityid");
                trainStations.add(new TrainStation(trainId, departureCityId, destCityId));
            }
        } catch (SQLException e) {
            System.err.println("Eroare la cautarea statiilor de tren pentru orasul de plecare " + departureCityId + ": " + e.getMessage());
        }

        return trainStations;
    }
}
