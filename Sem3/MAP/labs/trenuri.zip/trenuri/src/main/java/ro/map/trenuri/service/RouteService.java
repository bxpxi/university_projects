package ro.map.trenuri.service;

import ro.map.trenuri.domain.City;
import ro.map.trenuri.domain.TrainStation;
import ro.map.trenuri.repository.CityRepository;
import ro.map.trenuri.repository.TrainStationRepository;

import java.util.*;

public class RouteService {
    private CityRepository cityRepository;
    private TrainStationRepository trainStationRepository;

    public RouteService(CityRepository cityRepository, TrainStationRepository trainStationRepository) {
        this.cityRepository = cityRepository;
        this.trainStationRepository = trainStationRepository;
    }

    public List<String> findRoutes(String departureCityId, String destinationCityId, boolean directRoutesOnly) {
        List<String> routes = new ArrayList<>();
        Map<String, String> cityNames = new HashMap<>();
        for (City city : cityRepository.getAllCities()) {
            cityNames.put(city.getId(), city.getName());
        }

        List<TrainStation> stations = trainStationRepository.getAllTrainStations();
        Map<String, List<TrainStation>> graph = new HashMap<>();
        for (TrainStation station : stations) {
            graph.computeIfAbsent(station.getDepartureCityId(), k -> new ArrayList<>()).add(station);
        }

        if (directRoutesOnly) {
            findDirectRoutesWithSameTrain(departureCityId, destinationCityId, graph, routes, cityNames);
        } else {
            Set<String> visited = new HashSet<>();
            dfs(departureCityId, destinationCityId, graph, visited, new ArrayList<>(), routes, cityNames);
        }

        return routes;
    }

    private void findRoutesWithSameTrain(String currentCityId, String destinationCityId, Map<String, List<TrainStation>> graph, List<String> routes, Map<String, String> cityNames, String trainId, String currentPath) {
        if (currentCityId.equals(destinationCityId)) {
            routes.add(currentPath);
            return;
        }

        List<TrainStation> stationsFromCurrent = graph.getOrDefault(currentCityId, new ArrayList<>());
        for (TrainStation station : stationsFromCurrent) {
            if (station.getTrainId().equals(trainId)) {
                String nextStep = cityNames.get(currentCityId) + " —" + station.getTrainId() + "→ " + cityNames.get(station.getDestinationCityId());
                findRoutesWithSameTrain(station.getDestinationCityId(), destinationCityId, graph, routes, cityNames, trainId, currentPath + " " + nextStep);
            }
        }
    }

    private void findDirectRoutesWithSameTrain(String departureCityId, String destinationCityId, Map<String, List<TrainStation>> graph, List<String> routes, Map<String, String> cityNames) {
        List<TrainStation> stationsFromDeparture = graph.getOrDefault(departureCityId, new ArrayList<>());
        for (TrainStation station : stationsFromDeparture) {
            if (station.getDestinationCityId().equals(destinationCityId)) {
                routes.add(cityNames.get(departureCityId) + " —" + station.getTrainId() + "→ " + cityNames.get(destinationCityId));
            } else {
                String initialPath = cityNames.get(departureCityId) + " —" + station.getTrainId() + "→ " + cityNames.get(station.getDestinationCityId());
                findRoutesWithSameTrain(station.getDestinationCityId(), destinationCityId, graph, routes, cityNames, station.getTrainId(), initialPath);
            }
        }
    }

    private void dfs(String currentCityId, String destinationCityId, Map<String, List<TrainStation>> graph, Set<String> visited, List<String> path, List<String> routes, Map<String, String> cityNames) {
        if (currentCityId.equals(destinationCityId)) {
            StringBuilder route = new StringBuilder();
            for (String step : path) {
                route.append(step).append(" ");
            }
            routes.add(route.toString().trim());
            return;
        }

        visited.add(currentCityId);
        for (TrainStation station : graph.getOrDefault(currentCityId, new ArrayList<>())) {
            if (!visited.contains(station.getDestinationCityId())) {
                path.add(cityNames.get(currentCityId) + " —" + station.getTrainId() + "→ " + cityNames.get(station.getDestinationCityId()));
                dfs(station.getDestinationCityId(), destinationCityId, graph, visited, path, routes, cityNames);
                path.remove(path.size() - 1);
            }
        }
        visited.remove(currentCityId);
    }

    public double calculatePrice(int numberOfStations) {
        double PRICE_PER_STATION = 10.0;
        return PRICE_PER_STATION * numberOfStations;
    }
}
