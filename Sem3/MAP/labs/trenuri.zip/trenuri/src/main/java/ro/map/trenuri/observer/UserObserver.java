package ro.map.trenuri.observer;

import java.util.HashMap;
import java.util.Map;

public class UserObserver {
    private static UserObserver instance;
    private Map<String, Integer> routeCounts;

    public UserObserver() {
        routeCounts = new HashMap<>();
    }

    public static UserObserver getInstance() {
        if (instance == null) {
            instance = new UserObserver();
        }
        return instance;
    }

    public void incrementRouteCount(String routeKey) {
        routeCounts.put(routeKey, routeCounts.getOrDefault(routeKey, 0) + 1);
    }

    public void decrementRouteCount(String routeKey) {
        routeCounts.put(routeKey, routeCounts.getOrDefault(routeKey, 0) - 1);
    }

    public int getRouteCount(String routeKey) {
        return routeCounts.getOrDefault(routeKey, 0);
    }
}
