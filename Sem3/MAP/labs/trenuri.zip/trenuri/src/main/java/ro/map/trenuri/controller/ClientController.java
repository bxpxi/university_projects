package ro.map.trenuri.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import ro.map.trenuri.domain.City;
import ro.map.trenuri.observer.UserObserver;
import ro.map.trenuri.repository.CityRepository;
import ro.map.trenuri.repository.TrainStationRepository;
import ro.map.trenuri.service.RouteService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class ClientController {
    @FXML
    private ComboBox<String> departureCityComboBox;
    @FXML
    private ComboBox<String> destinationCityComboBox;
    @FXML
    private CheckBox directRoutesOnlyCheckBox;
    @FXML
    private Button searchButton;
    @FXML
    private TextArea resultTextArea;
    @FXML
    private Label userCountLabel;

    private RouteService routeService;
    private UserObserver userObserver;
    private String currentRouteKey;

    public void initialize() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/trenuri", "postgres", "Bobby");
            CityRepository cityRepository = new CityRepository(connection);
            TrainStationRepository trainStationRepository = new TrainStationRepository(connection);
            routeService = new RouteService(cityRepository, trainStationRepository);
            userObserver = UserObserver.getInstance();

            List<City> cities = cityRepository.getAllCities();
            System.out.println("Orase incarcate din baza de date:");
            for (City city : cities) {
                System.out.println(city.getId() + ": " + city.getName());
            }

            for (City city : cityRepository.getAllCities()) {
                departureCityComboBox.getItems().add(city.getName());
                destinationCityComboBox.getItems().add(city.getName());
            }

            departureCityComboBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> updateUserCount());
            destinationCityComboBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> updateUserCount());

            Timer timer = new Timer(true);
            timer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    javafx.application.Platform.runLater(() -> {
                        if (currentRouteKey != null) {
                            int userCount = userObserver.getRouteCount(currentRouteKey) - 1;
                            userCountLabel.setText(userCount + " other user(s) are looking at the same route");
                        }
                    });
                }
            }, 0, 1000);

        } catch (SQLException e) {
            System.err.println("Eroare la conectarea la baza de date: " + e.getMessage());
        }
    }

    @FXML
    private void searchRoutes() {
        String departureCity = departureCityComboBox.getValue();
        String destinationCity = destinationCityComboBox.getValue();
        boolean directRoutesOnly = directRoutesOnlyCheckBox.isSelected();

        if (departureCity != null && destinationCity != null) {
            String departureCityId = getCityIdByName(departureCity);
            String destinationCityId = getCityIdByName(destinationCity);

            List<String> routes = routeService.findRoutes(departureCityId, destinationCityId, directRoutesOnly);
            resultTextArea.clear();
            for (String route : routes) {
                int numberOfStations = route.split("→").length;
                double price = routeService.calculatePrice(numberOfStations-1);
                resultTextArea.appendText(route + ", price: " + price + "\n");
            }

            Stage stage = (Stage) resultTextArea.getScene().getWindow();
            stage.setOnCloseRequest(event -> {
                if (currentRouteKey != null) {
                    userObserver.decrementRouteCount(currentRouteKey);
                }
            });
        }
    }

    private String getCityIdByName(String name) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/trenuri", "postgres", "Bobby");
            CityRepository cityRepository = new CityRepository(connection);
            for (City city : cityRepository.getAllCities()) {
                if (city.getName().equals(name)) {
                    return city.getId();
                }
            }
        } catch (SQLException e) {
            System.err.println("Eroare la cautarea orasului: " + e.getMessage());
        }
        return null;
    }

    private void updateUserCount() {
        String departureCity = departureCityComboBox.getValue();
        String destinationCity = destinationCityComboBox.getValue();

        if (departureCity != null && destinationCity != null) {
            String newRouteKey = departureCity + " -> " + destinationCity;

            if (currentRouteKey != null && !currentRouteKey.equals(newRouteKey)) {
                userObserver.decrementRouteCount(currentRouteKey);
            }

            currentRouteKey = newRouteKey;
            userObserver.incrementRouteCount(currentRouteKey);

            int userCount = userObserver.getRouteCount(currentRouteKey) - 1;
            userCountLabel.setText(userCount + " other user(s) are looking at the same route");
        }
    }
}
