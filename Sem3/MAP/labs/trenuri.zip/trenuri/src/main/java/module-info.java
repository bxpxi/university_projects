module ro.map.trenuri {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens ro.map.trenuri to javafx.fxml;
    exports ro.map.trenuri.controller to javafx.fxml;
    opens ro.map.trenuri.controller to javafx.fxml;

    exports ro.map.trenuri;
}