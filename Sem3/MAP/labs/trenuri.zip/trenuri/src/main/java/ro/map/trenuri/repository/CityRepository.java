package ro.map.trenuri.repository;

import ro.map.trenuri.domain.City;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CityRepository {
    private Connection connection;

    public CityRepository(Connection connection) {
        this.connection = connection;
    }

    public List<City> getAllCities() {
        List<City> cities = new ArrayList<>();
        String sql = "SELECT * FROM cities";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                cities.add(new City(id, name));
            }
        } catch (SQLException e) {
            System.err.println("Eroare la citirea oraselor din baza de date: " + e.getMessage());
        }

        return cities;
    }

    public City findCityById(String cityId) {
        String sql = "SELECT * FROM cities WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, cityId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                return new City(id, name);
            }
        } catch (SQLException e) {
            System.err.println("Eroare la cautarea orasului cu ID-ul " + cityId + ": " + e.getMessage());
        }
        return null;
    }
}
