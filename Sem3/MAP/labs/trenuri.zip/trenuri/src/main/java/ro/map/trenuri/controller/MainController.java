package ro.map.trenuri.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class MainController {
    @FXML
    private Button openClientButton;

    @FXML
    private void openClientWindow() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/ro/map/trenuri/client.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle("Client Window");
        stage.show();
    }
}
