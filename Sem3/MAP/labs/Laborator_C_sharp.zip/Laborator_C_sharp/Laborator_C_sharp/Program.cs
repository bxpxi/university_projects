﻿using System;
using System.Collections.Generic;
using System.Linq;
using Laborator_C_sharp.UI;

namespace Lab7
{
    class Program
    {
        static void Main(string[] args)
        {
            UI console = new UI();
            console.Start();
        }
    }
}