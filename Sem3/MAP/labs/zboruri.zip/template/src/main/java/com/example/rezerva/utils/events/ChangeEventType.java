package com.example.rezerva.utils.events;

public enum ChangeEventType {
    ADD, DELETE, UPDATE;
}
