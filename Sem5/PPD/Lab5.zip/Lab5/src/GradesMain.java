import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class GradesMain {

    private static final int NUM_PROJECTS = 10;
    private static final String RESULT_FILE = "rezultate.txt";

    private static final int DEFAULT_QUEUE_CAPACITY = 100;
    private static final int QUEUE_CAPACITY = Integer.parseInt(System.getProperty("QUEUE_CAPACITY", String.valueOf(DEFAULT_QUEUE_CAPACITY)));

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.err.println("Utilizare:");
            System.err.println("  java GradesMain seq");
            System.err.println("  java GradesMain par <p_r> <p_w>");
            System.exit(1);
        }

        String mode = args[0];

        String[] files = new String[NUM_PROJECTS];
        for (int i = 0; i < NUM_PROJECTS; i++) {
            files[i] = "proiect" + (i + 1) + ".txt";
        }

        long start = System.nanoTime();

        if (mode.equalsIgnoreCase("seq")) {
            runSequential(files);
        } else if (mode.equalsIgnoreCase("par")) {
            if (args.length < 3) {
                System.err.println("Pentru modul paralel: java GradesMain par <p_r> <p_w>");
                System.exit(1);
            }
            int p_r = Integer.parseInt(args[1]);
            int p_w = Integer.parseInt(args[2]);

            runParallel(files, p_r, p_w);
        } else {
            System.err.println("Mod necunoscut: " + mode);
            System.exit(1);
        }

        long end = System.nanoTime();
        long elapsedMs = (end - start) / 1_000_000;
        System.out.println(elapsedMs);
    }

    private static void runSequential(String[] files) throws IOException {
        FineGrainedList gradeList = new FineGrainedList();

        BufferedReader[] readers = new BufferedReader[files.length];
        try {
            for (int i = 0; i < files.length; i++) {
                readers[i] = new BufferedReader(new FileReader(files[i]));
            }

            boolean anyData;
            do {
                anyData = false;
                for (int i = 0; i < files.length; i++) {
                    if (readers[i] == null)
                        continue;

                    String line = readers[i].readLine();
                    if (line != null) {
                        anyData = true;
                        Record r = parseLine(line);
                        if (r != null) {
                            gradeList.addOrUpdate(r.id, r.grade);
                        }
                    } else {
                        readers[i].close();
                        readers[i] = null;
                    }
                }
            } while (anyData);
        } finally {
            for (int i = 0; i < readers.length; i++) {
                if (readers[i] != null) {
                    readers[i].close();
                }
            }
        }

        SortedList sortedList = new SortedList();
        gradeList.forEach((id, total) -> sortedList.insert(id, total));
        sortedList.writeToFile(RESULT_FILE);
    }

    private static void runParallel(String[] files, int p_r, int p_w) throws InterruptedException, IOException {
        FineGrainedList mainList = new FineGrainedList();
        BoundedQueue queue = new BoundedQueue(QUEUE_CAPACITY);

        ExecutorService executor = Executors.newFixedThreadPool(p_r);
        for (String f : files) {
            executor.submit(new ReaderTask(f, queue));
        }

        WorkerThread[] workers = new WorkerThread[p_w];
        for (int i = 0; i < p_w; i++) {
            workers[i] = new WorkerThread(queue, mainList);
            workers[i].start();
        }

        executor.shutdown();
        executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);

        queue.setFinished();

        for (WorkerThread wt : workers) {
            wt.join();
        }

        SortedList sortedList = new SortedList();
        BoundedQueue sortQueue = new BoundedQueue(QUEUE_CAPACITY);

        SortWorkerThread[] sortWorkers = new SortWorkerThread[p_w];
        for (int i = 0; i < p_w; i++) {
            sortWorkers[i] = new SortWorkerThread(sortQueue, sortedList);
            sortWorkers[i].start();
        }

        mainList.forEach((id, total) -> {
            try {
                sortQueue.put(new Record(id, total));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        sortQueue.setFinished();

        for (SortWorkerThread sw : sortWorkers) {
            sw.join();
        }

        sortedList.writeToFile(RESULT_FILE);
    }

    private static Record parseLine(String line) {
        if (line == null)
            return null;
        String s = line.trim();
        if (s.isEmpty())
            return null;

        if (s.startsWith("(") && s.endsWith(")")) {
            s = s.substring(1, s.length() - 1);
        }

        s = s.replaceAll("\\s+", "");
        String[] parts = s.split(",");
        if (parts.length != 2) {
            return null;
        }

        try {
            int id = Integer.parseInt(parts[0]);
            int grade = Integer.parseInt(parts[1]);
            return new Record(id, grade);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
