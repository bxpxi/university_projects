import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReaderTask implements Runnable {
    private final String filename;
    private final BoundedQueue queue;

    public ReaderTask(String filename, BoundedQueue queue) {
        this.filename = filename;
        this.queue = queue;
    }

    @Override
    public void run() {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                Record r = parseLine(line);
                if (r != null) {
                    queue.put(r);
                }
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            Thread.currentThread().interrupt();
        }
    }

    private Record parseLine(String line) {
        if (line == null)
            return null;
        String s = line.trim();
        if (s.isEmpty())
            return null;

        if (s.startsWith("(") && s.endsWith(")")) {
            s = s.substring(1, s.length() - 1);
        }

        s = s.replaceAll("\\s+", "");
        String[] parts = s.split(",");
        if (parts.length != 2) {
            return null;
        }

        try {
            int id = Integer.parseInt(parts[0]);
            int grade = Integer.parseInt(parts[1]);
            return new Record(id, grade);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
