import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.BiConsumer;

public class FineGrainedList {

    private static class Node {
        int id;
        int total;
        Node next;
        final Lock lock = new ReentrantLock();

        Node(int id, int total) {
            this.id = id;
            this.total = total;
        }
    }

    private final Node head;
    private final Node tail;

    public FineGrainedList() {
        head = new Node(Integer.MIN_VALUE, 0);
        tail = new Node(Integer.MAX_VALUE, 0);
        head.next = tail;
    }

    public void addOrUpdate(int id, int grade) {
        Node prev = head;
        prev.lock.lock();
        try {
            Node curr = prev.next;
            curr.lock.lock();
            try {
                while (curr.id < id) {
                    prev.lock.unlock();
                    prev = curr;
                    curr = curr.next;
                    curr.lock.lock();
                }

                if (curr.id == id) {
                    curr.total += grade;
                } else {
                    Node newNode = new Node(id, grade);
                    newNode.next = curr;
                    prev.next = newNode;
                }
            } finally {
                curr.lock.unlock();
            }
        } finally {
            prev.lock.unlock();
        }
    }

    public void forEach(BiConsumer<Integer, Integer> consumer) {
        Node curr = head.next;
        while (curr != tail) {
            consumer.accept(curr.id, curr.total);
            curr = curr.next;
        }
    }
}
