import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SortedList {

    private static class Node {
        int id;
        int total;
        Node next;
        final Lock lock = new ReentrantLock();

        Node(int id, int total) {
            this.id = id;
            this.total = total;
        }
    }

    private final Node head;
    private final Node tail;

    public SortedList() {
        head = new Node(-1, Integer.MAX_VALUE);
        tail = new Node(-1, Integer.MIN_VALUE);
        head.next = tail;
    }

    public void insert(int id, int total) {
        Node prev = head;
        prev.lock.lock();
        try {
            Node curr = prev.next;
            curr.lock.lock();
            try {
                while (curr.total > total || (curr.total == total && curr.id < id)) {
                    prev.lock.unlock();
                    prev = curr;
                    curr = curr.next;
                    curr.lock.lock();
                }

                Node newNode = new Node(id, total);
                newNode.next = curr;
                prev.next = newNode;
            } finally {
                curr.lock.unlock();
            }
        } finally {
            prev.lock.unlock();
        }
    }

    public void writeToFile(String filename) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename))) {
            Node curr = head.next;
            while (curr != tail) {
                pw.println(curr.id + " " + curr.total);
                curr = curr.next;
            }
        }
    }
}
