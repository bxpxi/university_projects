public class WorkerThread extends Thread {
    private final BoundedQueue queue;
    private final FineGrainedList gradeList;

    public WorkerThread(BoundedQueue queue, FineGrainedList gradeList) {
        this.queue = queue;
        this.gradeList = gradeList;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Record r = queue.take();
                if (r == null) {
                    break;
                }
                gradeList.addOrUpdate(r.id, r.grade);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
