import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedQueue {
    private final Record[] buffer;
    private int head = 0;
    private int tail = 0;
    private int count = 0;
    private boolean finished = false;

    private final Lock lock = new ReentrantLock();
    private final Condition notEmpty = lock.newCondition();
    private final Condition notFull = lock.newCondition();

    public BoundedQueue(int capacity) {
        this.buffer = new Record[capacity];
    }

    public void put(Record r) throws InterruptedException {
        lock.lock();
        try {
            while (count == buffer.length) {
                notFull.await();
            }
            buffer[tail] = r;
            tail = (tail + 1) % buffer.length;
            count++;
            notEmpty.signal();
        } finally {
            lock.unlock();
        }
    }

    public Record take() throws InterruptedException {
        lock.lock();
        try {
            while (count == 0 && !finished) {
                notEmpty.await();
            }
            if (count == 0) {
                return null;
            }
            Record r = buffer[head];
            buffer[head] = null;
            head = (head + 1) % buffer.length;
            count--;
            notFull.signal();
            return r;
        } finally {
            lock.unlock();
        }
    }

    public void setFinished() {
        lock.lock();
        try {
            finished = true;
            notEmpty.signalAll();
        } finally {
            lock.unlock();
        }
    }
}
