public class SortWorkerThread extends Thread {
    private final BoundedQueue queue;
    private final SortedList sortedList;

    public SortWorkerThread(BoundedQueue queue, SortedList sortedList) {
        this.queue = queue;
        this.sortedList = sortedList;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Record r = queue.take();
                if (r == null) {
                    break;
                }
                sortedList.insert(r.id, r.grade);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
