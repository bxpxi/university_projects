#include <mpi.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <string>

using namespace std;
using namespace std::chrono;

vector<int> citesteNumar(const string &numeFisier) {
    ifstream fin(numeFisier);
    if (!fin) {
        cerr << "Eroare la deschiderea fisierului " << numeFisier << endl;
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    int N;
    fin >> N;
    if (!fin) {
        cerr << "Eroare: fisierul " << numeFisier << " nu contine un N valid!" << endl;
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    vector<int> digits(N);
    for (int i = 0; i < N; ++i) {
        if (!(fin >> digits[i])) {
            cerr << "Eroare: fisierul " << numeFisier << " are mai putine cifre decat N=" << N << endl;
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
    }
    fin.close();

    reverse(digits.begin(), digits.end());
    return digits;
}

int main(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    auto start = high_resolution_clock::now();

    vector<int> A, B;
    int N1 = 0, N2 = 0;

    if (rank == 0) {
        A = citesteNumar("Numar1.txt");
        B = citesteNumar("Numar2.txt");
        N1 = (int)A.size();
        N2 = (int)B.size();
    }

    MPI_Bcast(&N1, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&N2, 1, MPI_INT, 0, MPI_COMM_WORLD);

    int N = max(N1, N2);
    int rem = N % size;
    if (rem != 0)
        N += size - rem;

    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);

    int seg = N / size;

    vector<int> padA(N, 0), padB(N, 0);
    if (rank == 0) {
        for (int i = 0; i < N1; ++i)
            padA[i] = A[i];
        for (int i = 0; i < N2; ++i)
            padB[i] = B[i];
    }

    vector<int> localA(seg, 0), localB(seg, 0), localSum(seg, 0);
    MPI_Scatter(padA.data(), seg, MPI_INT, localA.data(), seg, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Scatter(padB.data(), seg, MPI_INT, localB.data(), seg, MPI_INT, 0, MPI_COMM_WORLD);

    for (int i = 0; i < seg; ++i)
        localSum[i] = localA[i] + localB[i];

    int carry = 0;

    if (rank > 0)
        MPI_Recv(&carry, 1, MPI_INT, rank - 1, 2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

    for (int i = 0; i < seg; ++i) {
        int s = localSum[i] + carry;
        localSum[i] = s % 10;
        carry = s / 10;
    }

    if (rank < size - 1)
        MPI_Ssend(&carry, 1, MPI_INT, rank + 1, 2, MPI_COMM_WORLD);

    vector<int> rezultat(N, 0);
    MPI_Gather(localSum.data(), seg, MPI_INT, rezultat.data(), seg, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == size - 1)
        MPI_Ssend(&carry, 1, MPI_INT, 0, 4, MPI_COMM_WORLD);

    if (rank == 0) {
        int globalCarry = 0;
        MPI_Recv(&globalCarry, 1, MPI_INT, size - 1, 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        ofstream fout("Numar3.txt");
        if (!fout) {
            cerr << "Eroare la deschiderea fisierului de iesire!" << endl;
            MPI_Abort(MPI_COMM_WORLD, 1);
        }

        int realN = max(N1, N2);
        int outN = realN + (globalCarry > 0 ? 1 : 0);

        fout << outN << '\n';
        if (globalCarry > 0)
            fout << "1 ";

        for (int i = realN - 1; i >= 0; --i) {
            fout << rezultat[i];
            if (i != 0)
                fout << ' ';
        }
        fout << '\n';
        fout.close();

        auto stop = high_resolution_clock::now();
        cout << "Timp de executie MPI Scatter/Gather Ssend (ms): " << duration_cast<milliseconds>(stop - start).count() << endl;
    }

    MPI_Finalize();
    return 0;
}
