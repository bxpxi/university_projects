#include <mpi.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <string>

using namespace std;
using namespace std::chrono;

static void citesteSegment_LSB(const string &numeFisier, int Ni, int startLSB, int len, vector<int> &outLSB)
{
    outLSB.assign(len, 0);
    if (Ni <= 0 || len <= 0)
        return;

    int posStartMSB = Ni - (startLSB + len);
    int posEndMSB   = Ni - 1 - startLSB;

    if (posEndMSB < 0)
        return;
    if (posStartMSB < 0)
        posStartMSB = 0;
    if (posStartMSB > posEndMSB)
        return;

    int need = posEndMSB - posStartMSB + 1;

    ifstream fin(numeFisier);
    if (!fin) {
        cerr << "Eroare fisier " << numeFisier << "\n";
        MPI_Abort(MPI_COMM_WORLD,1);
    }
    int headerN; fin >> headerN;

    int dump;
    for (int s = 0; s < posStartMSB; ++s) {
        if (!(fin >> dump)) {
            cerr << "Eroare skip " << numeFisier << "\n";
            MPI_Abort(MPI_COMM_WORLD,1);
        }
    }

    vector<int> chunk(need);
    for (int i = 0; i < need; ++i) {
        if (!(fin >> chunk[i])) {
            cerr << "Eroare citire cifra din " << numeFisier << "\n";
            MPI_Abort(MPI_COMM_WORLD,1);
        }
    }
    fin.close();

    for (int t = 0; t < need; ++t) {
        int k = Ni - 1 - (posStartMSB + t);
        int i = k - startLSB;
        if (0 <= i && i < len)
            outLSB[i] = chunk[t];
    }
}

static void wait_req_nonblock(MPI_Request &req){
    if (req == MPI_REQUEST_NULL)
        return;
    int flag = 0;
    while (!flag)
        MPI_Test(&req, &flag, MPI_STATUS_IGNORE);
}

int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Comm_size(MPI_COMM_WORLD,&size);

    if (size < 2) {
        if (rank == 0) cerr << "Necesare cel putin 2 procese.\n";
        MPI_Finalize(); return 1;
    }

    auto start = high_resolution_clock::now();

    int N1 = 0, N2 = 0;
    if (rank == 0) {
        ifstream f1("Numar1.txt"), f2("Numar2.txt");
        if (!f1 || !f2) {
            cerr << "Eroare la deschiderea fisierelor!\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        f1 >> N1; f2 >> N2;
        if (!f1 || !f2) {
            cerr << "Eroare la citirea dimensiunilor!\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
    }

    MPI_Bcast(&N1, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&N2, 1, MPI_INT, 0, MPI_COMM_WORLD);

    const int N = max(N1, N2);
    const int workers = size - 1;
    const int seg = (N + workers - 1) / workers;
    const int totalSeg = (N + seg - 1) / seg;
    const int lastWorker = min(workers, totalSeg);

    if (rank == 0) {
        vector<vector<int>> sendA(lastWorker + 1), sendB(lastWorker + 1);
        vector<MPI_Request> send_reqA(lastWorker + 1, MPI_REQUEST_NULL);
        vector<MPI_Request> send_reqB(lastWorker + 1, MPI_REQUEST_NULL);

        int idxLSB = 0;
        for (int id = 1; id <= lastWorker; ++id) {
            int len = min(seg, N - idxLSB);

            sendA[id].assign(len, 0);
            sendB[id].assign(len, 0);
            citesteSegment_LSB("Numar1.txt", N1, idxLSB, len, sendA[id]);
            citesteSegment_LSB("Numar2.txt", N2, idxLSB, len, sendB[id]);

            MPI_Isend(sendA[id].data(), len, MPI_INT, id, 0, MPI_COMM_WORLD, &send_reqA[id]);
            MPI_Isend(sendB[id].data(), len, MPI_INT, id, 1, MPI_COMM_WORLD, &send_reqB[id]);

            idxLSB += len;
        }

        vector<vector<int>> seg_buf(lastWorker + 1);
        vector<MPI_Request> recv_reqs(lastWorker + 1, MPI_REQUEST_NULL);
        vector<char> ready(lastWorker + 1, 0);

        for (int id = 1; id <= lastWorker; ++id) {
            int len = min(seg, N - (id - 1) * seg);
            seg_buf[id].assign(len, 0);
            MPI_Irecv(seg_buf[id].data(), len, MPI_INT, id, 3, MPI_COMM_WORLD, &recv_reqs[id]);
        }

        int globalCarry = 0;
        MPI_Request carry_req = MPI_REQUEST_NULL;
        MPI_Irecv(&globalCarry, 1, MPI_INT, lastWorker, 4, MPI_COMM_WORLD, &carry_req);

        vector<int> fullResult;
        fullResult.reserve(N + 1);
        int next_to_write = lastWorker;
        int written = 0;

        while (written < lastWorker) {
            for (int id = 1; id <= lastWorker; ++id) {
                if (ready[id])
                    continue;
                int flag = 0;
                MPI_Test(&recv_reqs[id], &flag, MPI_STATUS_IGNORE);
                if (flag) ready[id] = 1;
            }
            while (next_to_write >= 1 && ready[next_to_write]) {
                const auto &S = seg_buf[next_to_write];
                for (int i = (int)S.size() - 1; i >= 0; --i) {
                    fullResult.push_back(S[i]);
                }
                --next_to_write;
                ++written;
            }
        }

        int cflag = 0;
        while (!cflag)
            MPI_Test(&carry_req, &cflag, MPI_STATUS_IGNORE);

        ofstream fout("Numar3.txt");
        if (!fout) {
            cerr << "Eroare la deschiderea fisierului de iesire!\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }

        int outN = N + (globalCarry > 0 ? 1 : 0);
        fout << outN << '\n';
        if (globalCarry > 0)
            fout << "1 ";
        for (size_t i = 0; i < fullResult.size(); ++i) {
            fout << fullResult[i];
            if (i + 1 < fullResult.size())
                fout << ' ';
        }
        fout << '\n';
        fout.close();

        for (int id = 1; id <= lastWorker; ++id) {
            wait_req_nonblock(send_reqA[id]);
            wait_req_nonblock(send_reqB[id]);
        }

        auto stop = high_resolution_clock::now();
        cout << "Timp de executie MPI Async (ms): " << duration_cast<milliseconds>(stop - start).count() << "\n";
    }
    else if (rank <= lastWorker) {
        int startLSB = (rank - 1) * seg;
        int len = min(seg, N - startLSB);

        vector<int> A(len, 0), B(len, 0), S(len, 0);
        int carry = 0;

        MPI_Request ra = MPI_REQUEST_NULL, rb = MPI_REQUEST_NULL, rc = MPI_REQUEST_NULL;
        MPI_Irecv(A.data(), len, MPI_INT, 0, 0, MPI_COMM_WORLD, &ra);
        MPI_Irecv(B.data(), len, MPI_INT, 0, 1, MPI_COMM_WORLD, &rb);
        if (rank > 1)
            MPI_Irecv(&carry, 1, MPI_INT, rank - 1, 2, MPI_COMM_WORLD, &rc);

        vector<int> pre(len, 0);
        int a_ready = 0, b_ready = 0, c_ready = (rank == 1 ? 1 : 0), presum_done = 0;
        while (!(a_ready && b_ready)) {
            if (!a_ready)
                MPI_Test(&ra, &a_ready, MPI_STATUS_IGNORE);
            if (!b_ready)
                MPI_Test(&rb, &b_ready, MPI_STATUS_IGNORE);
            if (!presum_done && a_ready && b_ready) {
                for (int i = 0; i < len; ++i)
                    pre[i] = A[i] + B[i];
                presum_done = 1;
            }
        }
        if (rank > 1) {
            while (!c_ready)
                MPI_Test(&rc, &c_ready, MPI_STATUS_IGNORE);
        }

        for (int i = 0; i < len; ++i) {
            int x = pre[i] + carry;
            S[i] = x % 10;
            carry = x / 10;
        }

        MPI_Request rs_carry = MPI_REQUEST_NULL, rs_seg = MPI_REQUEST_NULL, rs_gcarry = MPI_REQUEST_NULL;
        if (rank < lastWorker)
            MPI_Isend(&carry, 1, MPI_INT, rank + 1, 2, MPI_COMM_WORLD, &rs_carry);

        MPI_Isend(S.data(), len, MPI_INT, 0, 3, MPI_COMM_WORLD, &rs_seg);

        if (rank == lastWorker)
            MPI_Isend(&carry, 1, MPI_INT, 0, 4, MPI_COMM_WORLD, &rs_gcarry);

        wait_req_nonblock(rs_carry);
        wait_req_nonblock(rs_seg);
        wait_req_nonblock(rs_gcarry);
    }

    MPI_Finalize();
    return 0;
}
