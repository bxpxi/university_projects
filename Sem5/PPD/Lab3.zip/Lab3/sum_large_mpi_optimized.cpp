#include <mpi.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <string>

using namespace std;
using namespace std::chrono;

static void citesteSegment_LSB(const string &numeFisier, int Ni, int N, int startLSB, int len, vector<int> &outLSB) {
    outLSB.assign(len, 0);
    if (Ni <= 0)
        return;

    int posStartMSB = Ni - (startLSB + len);
    int posEndMSB   = Ni - 1 - startLSB;
    if (posEndMSB < 0)
        return;
    if (posStartMSB < 0)
        posStartMSB = 0;
    if (posStartMSB > posEndMSB)
        return;

    int need = posEndMSB - posStartMSB + 1;

    ifstream fin(numeFisier);
    if (!fin) {
        cerr << "Eroare deschidere " << numeFisier << "\n";
        MPI_Abort(MPI_COMM_WORLD, 1);
    }
    int headerN;
    fin >> headerN;
    if (!fin) {
        cerr << "Eroare citire N din " << numeFisier << "\n";
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    int dump;
    for (int s = 0; s < posStartMSB; ++s) {
        if (!(fin >> dump)) {
            cerr << "Eroare skip in " << numeFisier << "\n";
            MPI_Abort(MPI_COMM_WORLD, 1); }
    }

    vector<int> msbChunk; msbChunk.reserve(need);
    for (int i = 0; i < need; ++i) {
        int d;
        if (!(fin >> d)) {
            cerr << "Eroare citire cifra in " << numeFisier << "\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        msbChunk.push_back(d);
    }
    fin.close();

    for (int t = 0; t < need; ++t) {
        int k = Ni - 1 - (posStartMSB + t);
        int i = k - startLSB;
        if (0 <= i && i < len)
            outLSB[i] = msbChunk[t];
    }
}

int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size < 2) {
        if (rank == 0) cerr << "Necesare cel putin 2 procese.\n";
        MPI_Finalize(); return 1;
    }

    auto t0 = high_resolution_clock::now();

    int N1 = 0, N2 = 0;
    if (rank == 0) {
        ifstream f1("Numar1.txt"), f2("Numar2.txt");
        if (!f1 || !f2) {
            cerr << "Eroare la deschiderea fisierelor de intrare!\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        if (!(f1 >> N1) || !(f2 >> N2)) {
            cerr << "Eroare la citirea dimensiunilor!\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
    }

    MPI_Bcast(&N1, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&N2, 1, MPI_INT, 0, MPI_COMM_WORLD);

    const int N = max(N1, N2);
    const int workers = size - 1;
    const int seg = (N + workers - 1) / workers;
    const int totalSeg = (N + seg - 1) / seg;
    const int lastWorker = min(workers, totalSeg);

    if (rank == 0) {
        for (int id = 1; id <= lastWorker; ++id) {
            int startLSB = (id - 1) * seg;
            int len = min(seg, N - startLSB);

            vector<int> A(len, 0), B(len, 0);
            if (N1 > 0)
                citesteSegment_LSB("Numar1.txt", N1, N, startLSB, len, A);
            if (N2 > 0)
                citesteSegment_LSB("Numar2.txt", N2, N, startLSB, len, B);

            MPI_Ssend(A.data(), len, MPI_INT, id, 0, MPI_COMM_WORLD);
            MPI_Ssend(B.data(), len, MPI_INT, id, 1, MPI_COMM_WORLD);
        }

        ofstream fout("Numar3.txt");
        if (!fout) {
            cerr << "Eroare la deschiderea Numar3.txt\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        fout << N << '\n';

        for (int id = lastWorker; id >= 1; --id) {
            int startLSB = (id - 1) * seg;
            int len = min(seg, N - startLSB);
            vector<int> S(len, 0);
            MPI_Recv(S.data(), len, MPI_INT, id, 3, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            for (int i = len - 1; i >= 0; --i) {
                fout << S[i];
                bool lastDigit = (id == 1 && i == 0);
                if (!lastDigit)
                    fout << ' ';
            }
        }
        fout << '\n';
        fout.close();

        int globalCarry = 0;
        MPI_Recv(&globalCarry, 1, MPI_INT, lastWorker, 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        if (globalCarry > 0) {
            ifstream fin("Numar3.txt");
            string lineN, lineDigits;
            getline(fin, lineN);
            getline(fin, lineDigits);
            fin.close();

            ofstream fout2("Numar3.txt");
            fout2 << (stoi(lineN) + 1) << '\n';
            fout2 << "1 " << lineDigits << '\n';
            fout2.close();
        }

        auto t1 = high_resolution_clock::now();
        cout << "Timp de executie MPI standard optimizat (ms): " << duration_cast<milliseconds>(t1 - t0).count() << "\n";
    }
    else if (rank <= lastWorker) {
        int startLSB = (rank - 1) * seg;
        int len = min(seg, N - startLSB);

        vector<int> A(len, 0), B(len, 0), S(len, 0);

        MPI_Recv(A.data(), len, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(B.data(), len, MPI_INT, 0, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        for (int i = 0; i < len; ++i)
            S[i] = A[i] + B[i];

        int carry = 0;
        if (rank > 1)
            MPI_Recv(&carry, 1, MPI_INT, rank - 1, 2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        for (int i = 0; i < len; ++i) {
            int x = S[i] + carry;
            S[i] = x % 10;
            carry = x / 10;
        }

        if (rank < lastWorker)
            MPI_Ssend(&carry, 1, MPI_INT, rank + 1, 2, MPI_COMM_WORLD);

        MPI_Ssend(S.data(), len, MPI_INT, 0, 3, MPI_COMM_WORLD);

        if (rank == lastWorker)
            MPI_Ssend(&carry, 1, MPI_INT, 0, 4, MPI_COMM_WORLD);
    }

    MPI_Finalize();
    return 0;
}
