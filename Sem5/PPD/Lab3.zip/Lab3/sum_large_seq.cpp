#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <string>
#include <cctype>

using namespace std;
using namespace std::chrono;

vector<int> citesteNumar(const string &numeFisier) {
    ifstream fin(numeFisier);
    if (!fin) {
        cerr << "Eroare la deschiderea fisierului " << numeFisier << endl;
        exit(1);
    }

    int N;
    fin >> N;
    if (!fin) {
        cerr << "Eroare: fisierul " << numeFisier << " nu contine un N valid!" << endl;
        exit(1);
    }

    vector<int> digits_msb;
    digits_msb.reserve(N);

    int d;
    for (int i = 0; i < N; ++i) {
        if (!(fin >> d)) {
            cerr << "Eroare: fisierul " << numeFisier << " are mai putine cifre decat N=" << N << endl;
            exit(1);
        }
        digits_msb.push_back(d);
    }
    fin.close();

    reverse(digits_msb.begin(), digits_msb.end());
    return digits_msb;
}


void scrieNumar(const string &numeFisier, const vector<int> &numar) {
    ofstream fout(numeFisier);
    if (!fout) {
        cerr << "Eroare la deschiderea fisierului " << numeFisier << endl;
        exit(1);
    }

    int N = (int)numar.size();
    fout << N << endl;
    for (int i = N - 1; i >= 0; --i) {
        fout << numar[i];
        if (i != 0)
            fout << " ";
    }
    fout << endl;
    fout.close();
}

vector<int> sumaNumereMari(const vector<int> &A, const vector<int> &B) {
    int n = (int)max(A.size(), B.size());
    vector<int> rezultat(n + 1, 0); // n+1 pt carry final

    for (int i = 0; i < n; ++i) {
        int suma = (i < (int)A.size() ? A[i] : 0) + (i < (int)B.size() ? B[i] : 0) + rezultat[i];
        rezultat[i] = suma % 10;
        rezultat[i + 1] = suma / 10; // carry
    }

    if (rezultat.back() == 0)
        rezultat.pop_back();

    return rezultat;
}

int main() {
    auto start = high_resolution_clock::now();

    vector<int> numar1 = citesteNumar("Numar1.txt");
    vector<int> numar2 = citesteNumar("Numar2.txt");

    vector<int> suma = sumaNumereMari(numar1, numar2);

    scrieNumar("Numar3.txt", suma);

    auto stop = high_resolution_clock::now();
    auto durata = duration_cast<milliseconds>(stop - start).count();
    cout << "Timp de executie (ms): " << durata << endl;

    return 0;
}
