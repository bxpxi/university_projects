#!/bin/bash
set -e

echo "Compilare executabile..."
mpicxx -std=c++11 -O3 sum_large_mpi_standard.cpp -o sum_large_mpi_standard
mpicxx -std=c++11 -O3 sum_large_mpi_optimized.cpp -o sum_large_mpi_optimized
mpicxx -std=c++11 -O3 sum_large_mpi_scatter.cpp -o sum_large_mpi_scatter
mpicxx -std=c++11 -O3 sum_large_mpi_async.cpp -o sum_large_mpi_async
g++ -std=c++11 -O3 sum_large_seq.cpp -o sum_large_seq
echo "Compile done."

generate_number() {
    local N=$1
    local filename=$2
    echo $N > "$filename"
    for ((i=0;i<N;i++)); do
        printf "%d " $((RANDOM % 10)) >> "$filename"
    done
    echo >> "$filename"
}

run_test() {
    local exe=$1
    local nproc=$2
    local num1=$3
    local num2=$4
    local label=$5

    if [[ "$num1" != "Numar1.txt" ]]; then cp "$num1" Numar1.txt; fi
    if [[ "$num2" != "Numar2.txt" ]]; then cp "$num2" Numar2.txt; fi

    local sum_time=0
    for i in $(seq 1 10); do
        echo "Rulare $i pentru $label, $exe cu $nproc procese"
        start=$(date +%s%3N)
        if [[ $exe == "sum_large_seq" ]]; then
            ./$exe >/dev/null
        else
            mpirun --oversubscribe -np $nproc ./$exe >/dev/null
        fi
        end=$(date +%s%3N)
        runtime=$((end-start))
        sum_time=$((sum_time+runtime))
        if [[ $exe != "sum_large_seq" ]]; then
            if ! cmp -s "Numar3.txt" "Numar3_sequential.txt"; then
                echo "Eroare: rezultatul $exe nu corespunde cu cel secvential"
                diff "Numar3.txt" "Numar3_sequential.txt" || true
                exit 1
            fi
        fi
    done
    avg_time=$((sum_time/10))
    echo "$label,$exe,$nproc,$avg_time" >> rezultate.csv
}

echo "Test,Executable,Procese,MedieTimp(ms)" > rezultate.csv

# Varianta 1 - standard
for exe in "sum_large_mpi_standard"; do
    echo "=== VARIANTA 1: MPI STANDARD ==="

    # Mic
    echo "16
9 9 9 9 4 4 4 4 4 4 4 4 9 9 9 9" > Numar1.txt
    echo "16
9 9 9 9 5 5 5 5 5 5 5 5 9 9 9 9" > Numar2.txt

    run_test sum_large_seq 1 Numar1.txt Numar2.txt "Varianta1_Mic"
    cp Numar3.txt Numar3_sequential.txt
    run_test $exe 5 Numar1.txt Numar2.txt "Varianta1_Mic"

    # Mediu
    generate_number 10000 Numar1.txt
    generate_number 10000 Numar2.txt
    run_test sum_large_seq 1 Numar1.txt Numar2.txt "Varianta1_10000"
    cp Numar3.txt Numar3_sequential.txt
    for nproc in 5 9 17; do
        run_test $exe $nproc Numar1.txt Numar2.txt "Varianta1_10000_$nproc"
    done

    # Mare
    generate_number 100 Numar1.txt
    generate_number 100000 Numar2.txt
    run_test sum_large_seq 1 Numar1.txt Numar2.txt "Varianta1_100_100000"
    cp Numar3.txt Numar3_sequential.txt
    for nproc in 5 9 17; do
        run_test $exe $nproc Numar1.txt Numar2.txt "Varianta1_100_100000_$nproc"
    done
done

# Varianta 2 - Scatter/Gather
for exe in "sum_large_mpi_scatter"; do
    echo "=== VARIANTA 2: MPI SCATTER/GATHER ==="

    # Mic
    echo "16
9 9 9 9 4 4 4 4 4 4 4 4 9 9 9 9" > Numar1.txt
    echo "16
9 9 9 9 5 5 5 5 5 5 5 5 9 9 9 9" > Numar2.txt
    run_test sum_large_seq 1 Numar1.txt Numar2.txt "Varianta2_Mic"
    cp Numar3.txt Numar3_sequential.txt
    run_test $exe 4 Numar1.txt Numar2.txt "Varianta2_Mic"

    # Mediu
    generate_number 1000 Numar1.txt
    generate_number 1000 Numar2.txt
    run_test sum_large_seq 1 Numar1.txt Numar2.txt "Varianta2_1000"
    cp Numar3.txt Numar3_sequential.txt
    for nproc in 4 8 16; do
        run_test $exe $nproc Numar1.txt Numar2.txt "Varianta2_1000_$nproc"
    done

    # Mare
    generate_number 100 Numar1.txt
    generate_number 100000 Numar2.txt
    run_test sum_large_seq 1 Numar1.txt Numar2.txt "Varianta2_100_100000"
    cp Numar3.txt Numar3_sequential.txt
    for nproc in 4 8 16; do
        run_test $exe $nproc Numar1.txt Numar2.txt "Varianta2_100_100000_$nproc"
    done
done

# Varianta 3 - async
for exe in "sum_large_mpi_async"; do
    echo "=== VARIANTA 3: MPI ASYNC ==="

    # Mic
    echo "16
9 9 9 9 4 4 4 4 4 4 4 4 9 9 9 9" > Numar1.txt
    echo "16
9 9 9 9 5 5 5 5 5 5 5 5 9 9 9 9" > Numar2.txt
    run_test sum_large_seq 1 Numar1.txt Numar2.txt "Varianta3_Mic"
    cp Numar3.txt Numar3_sequential.txt
    run_test $exe 5 Numar1.txt Numar2.txt "Varianta3_Mic"

    # Mediu
    generate_number 10000 Numar1.txt
    generate_number 10000 Numar2.txt
    run_test sum_large_seq 1 Numar1.txt Numar2.txt "Varianta3_10000"
    cp Numar3.txt Numar3_sequential.txt
    for nproc in 5 9 17; do
        run_test $exe $nproc Numar1.txt Numar2.txt "Varianta3_10000_$nproc"
    done

    # Mare
    generate_number 100 Numar1.txt
    generate_number 100000 Numar2.txt
    run_test sum_large_seq 1 Numar1.txt Numar2.txt "Varianta3_100_100000"
    cp Numar3.txt Numar3_sequential.txt
    for nproc in 5 9 17; do
        run_test $exe $nproc Numar1.txt Numar2.txt "Varianta3_100_100000_$nproc"
    done
done

# Varianta 4 - standard optimizat
for exe in "sum_large_mpi_optimized"; do
    echo "=== VARIANTA 4: MPI OPTIMIZED ==="

    # Mic
    echo "16
9 9 9 9 4 4 4 4 4 4 4 4 9 9 9 9" > Numar1.txt
    echo "16
9 9 9 9 5 5 5 5 5 5 5 5 9 9 9 9" > Numar2.txt
    run_test sum_large_seq 1 Numar1.txt Numar2.txt "Varianta4_Mic"
    cp Numar3.txt Numar3_sequential.txt
    run_test $exe 5 Numar1.txt Numar2.txt "Varianta4_Mic"

    # Mediu
    generate_number 10000 Numar1.txt
    generate_number 10000 Numar2.txt
    run_test sum_large_seq 1 Numar1.txt Numar2.txt "Varianta4_10000"
    cp Numar3.txt Numar3_sequential.txt
    for nproc in 5 9 17; do
        run_test $exe $nproc Numar1.txt Numar2.txt "Varianta4_10000_$nproc"
    done

    # Mare
    generate_number 100 Numar1.txt
    generate_number 100000 Numar2.txt
    run_test sum_large_seq 1 Numar1.txt Numar2.txt "Varianta4_100_100000"
    cp Numar3.txt Numar3_sequential.txt
    for nproc in 5 9 17; do
        run_test $exe $nproc Numar1.txt Numar2.txt "Varianta4_100_100000_$nproc"
    done
done

echo "Testare finalizata. Timpii medii sunt in rezultate.csv"
