import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReaderThread extends Thread {
    private final WorkQueue queue;
    private final FileDistributor distributor;

    public ReaderThread(WorkQueue queue, FileDistributor distributor) {
        this.queue = queue;
        this.distributor = distributor;
    }

    @Override
    public void run() {
        try {
            String filename;
            while ((filename = distributor.nextFile()) != null) {
                try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        Record r = parseLine(line);
                        if (r != null) {
                            queue.put(r);
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Record parseLine(String line) {
        if (line == null)
            return null;
        String s = line.trim();
        if (s.isEmpty())
            return null;

        if (s.startsWith("(") && s.endsWith(")")) {
            s = s.substring(1, s.length() - 1);
        }

        s = s.replaceAll("\\s+", "");

        String[] parts = s.split(",");
        if (parts.length != 2) {
            return null;
        }

        try {
            int id = Integer.parseInt(parts[0]);
            int grade = Integer.parseInt(parts[1]);
            return new Record(id, grade);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
