import java.util.LinkedList;

public class WorkQueue {
    private final LinkedList<Record> queue = new LinkedList<>();
    private boolean finished = false;

    public synchronized void put(Record r) {
        queue.addLast(r);
        notifyAll();
    }

    public synchronized Record take() throws InterruptedException {
        while (queue.isEmpty() && !finished) {
            wait();
        }
        if (queue.isEmpty()) {
            return null;
        }
        return queue.removeFirst();
    }

    public synchronized void setFinished() {
        finished = true;
        notifyAll();
    }
}
