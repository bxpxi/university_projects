public class Record {
    public final int id;
    public final int grade;

    public Record(int id, int grade) {
        this.id = id;
        this.grade = grade;
    }
}