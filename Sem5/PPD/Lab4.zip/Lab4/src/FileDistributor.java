public class FileDistributor {
    private final String[] files;
    private int index = 0;

    public FileDistributor(String[] files) {
        this.files = files;
    }

    public synchronized String nextFile() {
        if (index >= files.length) {
            return null;
        }
        String f = files[index];
        index++;
        return f;
    }
}
