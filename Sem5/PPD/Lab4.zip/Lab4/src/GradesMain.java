import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class GradesMain {

    private static final int NUM_PROJECTS = 10;
    private static final String RESULT_FILE = "rezultate.txt";

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.err.println("Utilizare:");
            System.err.println("  java GradesMain seq");
            System.err.println("  java GradesMain par <p> <p_r>");
            System.exit(1);
        }

        String mode = args[0];

        String[] files = new String[NUM_PROJECTS];
        for (int i = 0; i < NUM_PROJECTS; i++) {
            files[i] = "proiect" + (i + 1) + ".txt";
        }

        long start = System.nanoTime();

        if (mode.equalsIgnoreCase("seq")) {
            runSequential(files);
        } else if (mode.equalsIgnoreCase("par")) {
            if (args.length < 3) {
                System.err.println("Pentru modul paralel: java GradesMain par <p> <p_r>");
                System.exit(1);
            }
            int p = Integer.parseInt(args[1]);
            int p_r = Integer.parseInt(args[2]);
            if (p_r <= 0 || p_r >= p) {
                System.err.println("Trebuie 0 < p_r < p (cel putin un worker).");
                System.exit(1);
            }
            runParallel(files, p, p_r);
        } else {
            System.err.println("Mod necunoscut: " + mode);
            System.exit(1);
        }

        long end = System.nanoTime();
        long elapsedMs = (end - start) / 1_000_000;

        System.out.println(elapsedMs);
    }

    private static void runSequential(String[] files) throws IOException {
        GradeList gradeList = new GradeList();

        BufferedReader[] readers = new BufferedReader[files.length];
        try {
            for (int i = 0; i < files.length; i++) {
                readers[i] = new BufferedReader(new FileReader(files[i]));
            }

            boolean anyData;
            do {
                anyData = false;
                for (int i = 0; i < files.length; i++) {
                    if (readers[i] == null)
                        continue;

                    String line = readers[i].readLine();
                    if (line != null) {
                        anyData = true;
                        Record r = parseLine(line);
                        if (r != null) {
                            gradeList.addOrUpdate(r.id, r.grade);
                        }
                    } else {
                        readers[i].close();
                        readers[i] = null;
                    }
                }
            } while (anyData);
        } finally {
            for (int i = 0; i < readers.length; i++) {
                if (readers[i] != null) {
                    readers[i].close();
                }
            }
        }

        gradeList.writeToFile(RESULT_FILE);
    }

    private static void runParallel(String[] files, int p, int p_r) throws InterruptedException, IOException {
        int p_w = p - p_r;

        GradeList gradeList = new GradeList();
        WorkQueue queue = new WorkQueue();
        FileDistributor distributor = new FileDistributor(files);

        ReaderThread[] readers = new ReaderThread[p_r];
        for (int i = 0; i < p_r; i++) {
            readers[i] = new ReaderThread(queue, distributor);
        }

        WorkerThread[] workers = new WorkerThread[p_w];
        for (int i = 0; i < p_w; i++) {
            workers[i] = new WorkerThread(queue, gradeList);
        }

        for (ReaderThread rt : readers) {
            rt.start();
        }

        for (WorkerThread wt : workers) {
            wt.start();
        }

        for (ReaderThread rt : readers) {
            rt.join();
        }

        queue.setFinished();

        for (WorkerThread wt : workers) {
            wt.join();
        }

        gradeList.writeToFile(RESULT_FILE);
    }

    private static Record parseLine(String line) {
        if (line == null)
            return null;
        String s = line.trim();
        if (s.isEmpty())
            return null;

        if (s.startsWith("(") && s.endsWith(")")) {
            s = s.substring(1, s.length() - 1);
        }

        s = s.replaceAll("\\s+", "");
        String[] parts = s.split(",");
        if (parts.length != 2) {
            return null;
        }

        try {
            int id = Integer.parseInt(parts[0]);
            int grade = Integer.parseInt(parts[1]);
            return new Record(id, grade);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
