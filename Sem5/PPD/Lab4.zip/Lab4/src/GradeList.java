import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class GradeList {

    private static class Node {
        int id;
        int total;
        Node next;

        Node(int id, int total) {
            this.id = id;
            this.total = total;
        }
    }

    private Node head = null;

    public synchronized void addOrUpdate(int id, int grade) {
        if (head == null) {
            head = new Node(id, grade);
            return;
        }

        Node prev = null;
        Node curr = head;

        while (curr != null && curr.id < id) {
            prev = curr;
            curr = curr.next;
        }

        if (curr != null && curr.id == id) {
            curr.total += grade;
            return;
        }

        Node newNode = new Node(id, grade);

        if (prev == null) {
            newNode.next = head;
            head = newNode;
        } else {
            newNode.next = curr;
            prev.next = newNode;
        }
    }

    public synchronized void writeToFile(String filename) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename))) {
            Node curr = head;
            while (curr != null) {
                pw.println(curr.id + " " + curr.total);
                curr = curr.next;
            }
        }
    }
}
