#!/bin/bash
set -euo pipefail

NUM_STUDENTS=200
NUM_PROJECTS=10
MIN_GRADES_PER_FILE=80
NUM_RUNS=10

CSV_FILE="timpi.csv"
BASELINE_FILE="rezultate_seq_baseline.txt"

generate_data() {
  echo "Generare date random pentru ${NUM_STUDENTS} studenti in ${NUM_PROJECTS} fisiere..."

  for proj in $(seq 1 "${NUM_PROJECTS}"); do
    file="proiect${proj}.txt"
    echo "  -> ${file}"
    : > "${file}"

    max_count=${NUM_STUDENTS}
    range=$((max_count - MIN_GRADES_PER_FILE + 1))
    count=$((MIN_GRADES_PER_FILE + RANDOM % range))

    declare -A used_ids=()
    written=0

    while [ "${written}" -lt "${count}" ]; do
      id=$((1 + RANDOM % NUM_STUDENTS))
      if [ -z "${used_ids[$id]+x}" ]; then
        used_ids[$id]=1
        grade=$((RANDOM % 11))
        echo "(${id}, ${grade})" >> "${file}"
        written=$((written + 1))
      fi
    done
  done
}

compile_java() {
  echo "Compilare cod Java..."
  javac src/*.java
}

run_sequential() {
  echo "Rulari secventiale (${NUM_RUNS} rulari)..."
  local sum=0

  time_ms=$(java -cp src GradesMain seq)
  sum=$((sum + time_ms))
  cp rezultate.txt "${BASELINE_FILE}"

  for i in $(seq 2 "${NUM_RUNS}"); do
    time_ms=$(java -cp src GradesMain seq)
    sum=$((sum + time_ms))
    if ! cmp -s rezultate.txt "${BASELINE_FILE}"; then
      echo "Eroare: rezultate secventiale difera la rularea ${i}." >&2
      exit 1
    fi
  done

  avg=$((sum / NUM_RUNS))
  echo "Timp mediu secvential: ${avg} ms"

  echo "mode,p,p_r,avg_ms" > "${CSV_FILE}"
  echo "seq,1,0,${avg}" >> "${CSV_FILE}"
}

run_parallel_config() {
  local p=$1
  local pr=$2

  echo "Rulari paralele pentru p=${p}, p_r=${pr} (${NUM_RUNS} rulari)..."
  local sum=0

  for i in $(seq 1 "${NUM_RUNS}"); do
    time_ms=$(java -cp src GradesMain par "${p}" "${pr}")
    sum=$((sum + time_ms))

    if ! cmp -s rezultate.txt "${BASELINE_FILE}"; then
      echo "Eroare: rezultate paralele diferite de secvential (p=${p}, p_r=${pr}, run=${i})." >&2
      exit 1
    fi
  done

  avg=$((sum / NUM_RUNS))
  echo "Timp mediu paralel p=${p}, p_r=${pr}: ${avg} ms"
  echo "par,${p},${pr},${avg}" >> "${CSV_FILE}"
}

main() {
  generate_data
  compile_java
  run_sequential

  for p in 4 8 16; do
    run_parallel_config "${p}" 1
    run_parallel_config "${p}" 2
  done

  echo "Rezultate scrise in ${CSV_FILE}"
}

main "$@"
