#!/bin/bash
set -e

mkdir -p tests

echo "Compiling..."
g++ -O2 -std=c++17 -pthread main.cpp -o convolutie

echo "Running..."
./convolutie

echo "All done"
