#include <bits/stdc++.h>
#include <thread>
#include <chrono>
using namespace std;
using hr_clock = chrono::high_resolution_clock;

struct DynM {
    int n=0,m=0;
    int **a=nullptr;

    void init(int n_, int m_){
        n=n_;
        m=m_;
        a=new int*[n];
        for(int i=0;i<n;i++)
            a[i]=new int[m];
    }

    void free_all() {
        if(a) {
            for(int i=0;i<n;i++)
                delete[] a[i];
            delete[] a;
            a=nullptr;
        }
        n=m=0;
    }

    ~DynM() {
        free_all();
    }
};

class my_barrier{
public:
    my_barrier(int count): thread_count(count), counter(0), waiting(0){}
    void wait(){
        unique_lock<mutex> lk(m);
        ++counter; ++waiting;
        cv.wait(lk,[&]{return counter>=thread_count;});
        cv.notify_all();
        --waiting;
        if(waiting==0) counter=0;
    }
private:
    mutex m; condition_variable cv; int counter,waiting,thread_count;
};

void read_matrix_and_kernel(DynM &F,int ker[3][3],const string &fname){
    ifstream fin(fname);
    int n,m;
    fin>>n>>m;
    F.init(n,m);
    for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)
            fin>>F.a[i][j];

    for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
            fin>>ker[i][j];
    fin.close();
}

void write_matrix(const DynM &F,const string &fname){
    ofstream fout(fname);
    fout<<F.n<<" "<<F.m<<"\n";
    for(int i=0;i<F.n;i++) {
        for(int j=0;j<F.m;j++)
            fout<<F.a[i][j]<<" ";
        fout<<"\n";
    }
    fout.close();
}

inline int conv_cell_row(const int *up,const int *curr,const int *down,int ker[3][3],int j,int m){
    int jm1=max(0,j-1), jp1=min(m-1,j+1); // clamping
    long long s=0;
    s+=up[jm1]*ker[0][0]+up[j]*ker[0][1]+up[jp1]*ker[0][2];
    s+=curr[jm1]*ker[1][0]+curr[j]*ker[1][1]+curr[jp1]*ker[1][2];
    s+=down[jm1]*ker[2][0]+down[j]*ker[2][1]+down[jp1]*ker[2][2];
    return s;
}

void seq_inplace(DynM &F,int ker[3][3]){
    int n=F.n,m=F.m;
    if(n==0)
        return;

    vector<int> prev(m), curr(m), next(m), new_row(m);

    for(int j=0;j<m;j++)
        prev[j]=F.a[0][j];
    for(int j=0;j<m;j++)
        curr[j]=F.a[0][j];
    if(n>=2)
        for(int j=0;j<m;j++)
            next[j]=F.a[1][j];
    else
        for(int j=0;j<m;j++)
            next[j]=curr[j];

    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++)
            new_row[j]=conv_cell_row(prev.data(),curr.data(),next.data(),ker,j,m);

        for(int j=0;j<m;j++)
            F.a[i][j]=new_row[j];

        if(i+1<n){
            prev.swap(curr);
            curr.swap(next);
            if(i+2<n)
                for(int j=0;j<m;j++)
                    next[j]=F.a[i+2][j];
            else
                for(int j=0;j<m;j++)
                    next[j]=curr[j];
        }
    }
}

// 2b
void worker(DynM &F,int ker[3][3],int r0,int r1,my_barrier &bar){
    int n=F.n,m=F.m;
    vector<int> prev(m), curr(m), next(m), new_row(m);
    vector<int> top_border(m), bottom_border(m);

    for(int j=0;j<m;j++)
        curr[j]=F.a[r0][j];
    for(int j=0;j<m;j++)
        prev[j]=(r0>0)?F.a[r0-1][j]:curr[j];
    for(int j=0;j<m;j++)
        next[j]=(r0+1<=r1)?F.a[r0+1][j]:((r0+1<n)?F.a[r0+1][j]:curr[j]);

    bool top_border_needed=r0>0;
    bool bottom_border_needed=r1<n-1;

    for(int i=r0;i<=r1;i++){
        for(int j=0;j<m;j++)
            new_row[j]=conv_cell_row(prev.data(),curr.data(),next.data(),ker,j,m);

        if(i==r0 && top_border_needed)
            top_border=new_row;
        else if(i==r1 && bottom_border_needed)
            bottom_border=new_row;
        else
            for(int j=0;j<m;j++)
                F.a[i][j]=new_row[j];

        if(i<r1){
            prev.swap(curr);
            curr.swap(next);
            int next_row=i+2;
            if(next_row<=r1)
                for(int j=0;j<m;j++)
                    next[j]=F.a[next_row][j];
            else if(next_row<n)
                for(int j=0;j<m;j++)
                    next[j]=F.a[next_row][j];
            else
                for(int j=0;j<m;j++)
                    next[j]=curr[j];
        }
    }

    bar.wait();

    if(top_border_needed)
        for(int j=0;j<m;j++)
            F.a[r0][j]=top_border[j];
    if(bottom_border_needed)
        for(int j=0;j<m;j++)
            F.a[r1][j]=bottom_border[j];
}

void run_parallel(DynM &F,int ker[3][3],int p){
    int n=F.n;
    my_barrier bar(max(1,p));
    vector<thread> th;
    int base=n/p, rem=n%p, curr=0;
    for(int t=0;t<p;t++){
        int add=(t<rem)?1:0;
        int start=curr,end=start+base+add-1;
        if(start>end)
            th.emplace_back([&bar]() {
                bar.wait();
            });
        else
            th.emplace_back(worker,ref(F),ker,start,end,ref(bar));
        curr=end+1;
    }
    for(auto &tt:th)
        if(tt.joinable())
            tt.join();
}

bool compare_matrices(const DynM &A,const DynM &B){
    if(A.n!=B.n || A.m!=B.m)
        return false;
    for(int i=0;i<A.n;i++)
        for(int j=0;j<A.m;j++)
            if(A.a[i][j]!=B.a[i][j])
                return false;
    return true;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    vector<tuple<int,int,int,int>> configs={{10,10,3,3},{1000,1000,3,3},{10000,10000,3,3}};
    vector<int> threads={2,4,8,16};
    int repeat=10;
    ofstream csv("results.csv");
    csv << "N,M,n,m,p,mode,time,correct\n";

    for(auto &[N,M,n,m] : configs) {
        cout << "\n=== Config N=" << N << ", M=" << M << " ===\n";

        ofstream fout("date.txt");
        fout << N << " " << M << "\n";
        for(int i=0; i<N; i++) {
            for(int j=0; j<M; j++)
                fout << rand()%256 << " ";
            fout << "\n";
        }
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++)
                fout << rand()%3-1 << " ";
            fout << "\n";
        }
        fout.close();
        cout << "Generated date.txt\n";

        DynM F;
        int ker[3][3];
        read_matrix_and_kernel(F, ker, "date.txt");

        cout << "Running sequential...\n";
        double sum=0;
        DynM Fseq;
        Fseq.init(F.n, F.m);
        for(int r=0; r<repeat; r++) {
            for(int i=0; i<F.n; i++)
                for(int j=0; j<F.m; j++)
                    Fseq.a[i][j] = F.a[i][j];
            auto t0 = hr_clock::now();
            seq_inplace(Fseq, ker);
            auto t1 = hr_clock::now();
            sum += chrono::duration<double>(t1-t0).count();
        }
        double avg = sum / repeat;
        cout << "Sequential average time: " << avg*1000 << " ms\n";
        write_matrix(Fseq, "tests/test_" + to_string(N) + "x" + to_string(M) + "_3x3.out");
        cout << "Saved sequential output\n";
        csv << N << "," << M << "," << n << "," << m << ",1,seq," << avg << ",yes\n";

        for(int p : threads) {
            if(N==10 && p>2)
                continue;

            cout << "Running parallel with " << p << " threads...\n";
            sum = 0;
            DynM Fpar;
            Fpar.init(F.n, F.m);
            bool correct = true;
            for(int r=0; r<repeat; r++) {
                for(int i=0; i<F.n; i++)
                    for(int j=0; j<F.m; j++)
                        Fpar.a[i][j] = F.a[i][j];
                auto t0 = hr_clock::now();
                run_parallel(Fpar, ker, p);
                auto t1 = hr_clock::now();
                sum += chrono::duration<double>(t1-t0).count();
                if(!compare_matrices(Fpar, Fseq))
                    correct = false;
            }
            double avgp = sum / repeat;
            cout << "Average time with " << p << " threads: " << avgp*1000 << " ms\n";
            csv << N << "," << M << "," << n << "," << m << "," << p << ",horiz," << avgp << "," << (correct ? "yes" : "no") << "\n";
        }

        F.free_all();
    }

    csv.close();
    cout << "\nAll done. Results saved to results.csv\n";
    return 0;
}
