#!/bin/bash

set -e

echo "Compiling..."
javac -encoding UTF-8 src/Convolutie.java

mkdir -p tests

echo "Running..."
java -Xmx4G -cp src Convolutie

echo ""
echo "Done"
echo "Results written to results.csv"
echo "Test outputs saved in tests/ directory"
