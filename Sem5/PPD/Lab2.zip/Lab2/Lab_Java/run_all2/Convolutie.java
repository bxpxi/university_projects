import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class Convolutie {

    static class DynM {
        int n, m;
        int[][] a;

        void init(int n, int m) {
            this.n = n;
            this.m = m;
            a = new int[n][m];
        }

        void freeAll() {
            a = null;
            n = m = 0;
        }
    }

    static void readMatrixAndKernel(DynM F, int[][] ker, String fname) throws IOException {
        try (Scanner sc = new Scanner(new File(fname))) {
            int n = sc.nextInt(), m = sc.nextInt();
            F.init(n, m);
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    F.a[i][j] = sc.nextInt();
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    ker[i][j] = sc.nextInt();
        }
    }

    static void writeMatrix(DynM F, String fname) throws IOException {
        try (PrintWriter out = new PrintWriter(new FileWriter(fname))) {
            out.println(F.n + " " + F.m);
            for (int i = 0; i < F.n; i++) {
                for (int j = 0; j < F.m; j++)
                    out.print(F.a[i][j] + " ");
                out.println();
            }
        }
    }

    static int convCellRow(int[] up, int[] curr, int[] down, int[][] ker, int j, int m) {
        // clamping
        int jm1 = Math.max(0, j - 1);
        int jp1 = Math.min(m - 1, j + 1);
        int s = 0;
        s += up[jm1] * ker[0][0] + up[j] * ker[0][1] + up[jp1] * ker[0][2];
        s += curr[jm1] * ker[1][0] + curr[j] * ker[1][1] + curr[jp1] * ker[1][2];
        s += down[jm1] * ker[2][0] +down[j] * ker[2][1] + down[jp1] * ker[2][2];
        return s;
    }

    static void seqInplace(DynM F, int[][] ker) {
        int n = F.n, m = F.m;
        if (n == 0)
            return;

        int[] prev = new int[m];
        int[] curr = new int[m];
        int[] next = new int[m];
        int[] newRow = new int[m];

        System.arraycopy(F.a[0], 0, prev, 0, m);
        System.arraycopy(F.a[0], 0, curr, 0, m);
        if (n >= 2)
            System.arraycopy(F.a[1], 0, next, 0, m);
        else
            System.arraycopy(curr, 0, next, 0, m);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++)
                newRow[j] = convCellRow(prev, curr, next, ker, j, m);

            System.arraycopy(newRow, 0, F.a[i], 0, m);

            if (i + 1 < n) {
                int[] temp = prev;
                prev = curr;
                curr = next;
                next = temp;
                if (i + 2 < n)
                    System.arraycopy(F.a[i + 2], 0, next, 0, m);
                else
                    System.arraycopy(curr, 0, next, 0, m);
            }
        }
    }

    // 2b
    static class Worker implements Runnable {
        DynM F;
        int[][] ker;
        int r0, r1, n, m;
        CyclicBarrier bar;

        Worker(DynM F, int[][] ker, int r0, int r1, CyclicBarrier bar) {
            this.F = F;
            this.ker = ker;
            this.r0 = r0;
            this.r1 = r1;
            this.bar = bar;
            this.n = F.n;
            this.m = F.m;
        }

        @Override
        public void run() {
            int[] prev = new int[m];
            int[] curr = new int[m];
            int[] next = new int[m];
            int[] newRow = new int[m];
            int[] topBorder = new int[m];
            int[] bottomBorder = new int[m];

            System.arraycopy(F.a[r0], 0, curr, 0, m);
            if (r0 > 0)
                System.arraycopy(F.a[r0 - 1], 0, prev, 0, m);
            else
                System.arraycopy(curr, 0, prev, 0, m);

            if (r0 + 1 <= r1)
                System.arraycopy(F.a[r0 + 1], 0, next, 0, m);
            else if (r0 + 1 < n)
                System.arraycopy(F.a[r0 + 1], 0, next, 0, m);
            else
                System.arraycopy(curr, 0, next, 0, m);

            boolean topNeeded = r0 > 0;
            boolean bottomNeeded = r1 < n - 1;

            for (int i = r0; i <= r1; i++) {
                for (int j = 0; j < m; j++)
                    newRow[j] = convCellRow(prev, curr, next, ker, j, m);

                if (i == r0 && topNeeded)
                    System.arraycopy(newRow, 0, topBorder, 0, m);
                else if (i == r1 && bottomNeeded)
                    System.arraycopy(newRow, 0, bottomBorder, 0, m);
                else
                    System.arraycopy(newRow, 0, F.a[i], 0, m);

                if (i < r1) {
                    int[] temp = prev;
                    prev = curr;
                    curr = next;
                    next = temp;
                    int nextRow = i + 2;
                    if (nextRow <= r1)
                        System.arraycopy(F.a[nextRow], 0, next, 0, m);
                    else if (nextRow < n)
                        System.arraycopy(F.a[nextRow], 0, next, 0, m);
                    else
                        System.arraycopy(curr, 0, next, 0, m);
                }
            }

            try {
                bar.await();
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (topNeeded)
                System.arraycopy(topBorder, 0, F.a[r0], 0, m);
            if (bottomNeeded)
                System.arraycopy(bottomBorder, 0, F.a[r1], 0, m);
        }
    }

    static void runParallel(DynM F, int[][] ker, int p) throws InterruptedException {
        int n = F.n;
        CyclicBarrier bar = new CyclicBarrier(p);
        List<Thread> threads = new ArrayList<>();

        int base = n / p, rem = n % p, curr = 0;
        for (int t = 0; t < p; t++) {
            int add = (t < rem) ? 1 : 0;
            int start = curr;
            int end = start + base + add - 1;
            if (start > end)
                continue;
            threads.add(new Thread(new Worker(F, ker, start, end, bar)));
            curr = end + 1;
        }

        for (Thread th : threads)
            th.start();
        for (Thread th : threads)
            th.join();
    }

    static boolean compareMatrices(DynM A, DynM B) {
        if (A.n != B.n || A.m != B.m) return false;
        for (int i = 0; i < A.n; i++)
            for (int j = 0; j < A.m; j++)
                if (A.a[i][j] != B.a[i][j])
                    return false;
        return true;
    }

    public static void main(String[] args) throws Exception {
        int[][] configs = {{10,10},{1000,1000},{10000,10000}};
        int[] threads = {2,4,8,16};
        int repeat = 10;

        try (PrintWriter csv = new PrintWriter(new FileWriter("results.csv"))) {
            csv.println("N,M,n,m,p,mode,time,correct");

            for (int[] cfg : configs) {
                int N = cfg[0], M = cfg[1];
                System.out.println("\n=== Config N=" + N + ", M=" + M + " ===");

                try (PrintWriter fout = new PrintWriter("date.txt")) {
                    fout.println(N + " " + M);
                    Random rnd = new Random();
                    for (int i = 0; i < N; i++) {
                        for (int j = 0; j < M; j++)
                            fout.print(rnd.nextInt(256) + " ");
                        fout.println();
                    }
                    for (int i = 0; i < 3; i++) {
                        for (int j = 0; j < 3; j++)
                            fout.print(rnd.nextInt(3) - 1 + " ");
                        fout.println();
                    }
                }
                System.out.println("Generated date.txt");

                DynM F = new DynM();
                int[][] ker = new int[3][3];
                readMatrixAndKernel(F, ker, "date.txt");

                System.out.println("Running sequential...");
                double sum = 0;
                DynM Fseq = new DynM();
                Fseq.init(F.n, F.m);

                for (int r = 0; r < repeat; r++) {
                    for (int i = 0; i < F.n; i++)
                        System.arraycopy(F.a[i], 0, Fseq.a[i], 0, F.m);
                    long t0 = System.nanoTime();
                    seqInplace(Fseq, ker);
                    long t1 = System.nanoTime();
                    sum += (t1 - t0) / 1e9;
                }

                double avg = sum / repeat;
                System.out.printf("Sequential avg: %.3f ms%n", avg * 1000);
                writeMatrix(Fseq, "tests/test_" + N + "x" + M + "_3x3.out");
                csv.printf("%d,%d,3,3,1,seq,%.6f,yes%n", N, M, avg);

                for (int p : threads) {
                    if (N == 10 && p > 2) continue;
                    System.out.println("Running parallel with " + p + " threads...");
                    sum = 0;
                    DynM Fpar = new DynM();
                    Fpar.init(F.n, F.m);
                    boolean correct = true;

                    for (int r = 0; r < repeat; r++) {
                        for (int i = 0; i < F.n; i++)
                            System.arraycopy(F.a[i], 0, Fpar.a[i], 0, F.m);
                        long t0 = System.nanoTime();
                        runParallel(Fpar, ker, p);
                        long t1 = System.nanoTime();
                        sum += (t1 - t0) / 1e9;
                        if (!compareMatrices(Fpar, Fseq))
                            correct = false;
                    }

                    double avgp = sum / repeat;
                    System.out.printf("Parallel %d threads avg: %.3f ms%n", p, avgp * 1000);
                    csv.printf("%d,%d,3,3,%d,horiz,%.6f,%s%n",
                            N, M, p, avgp, correct ? "yes" : "no");
                }

                F.freeAll();
            }
        }

        System.out.println("\nAll done. Results saved to results.csv");
    }
}
