import java.util.*;

public class TestConvolutie {

    static int convCell(int[][] F, int[][] C, int i, int j) {
        int n = F.length, m = F[0].length;
        int s = 0;
        for (int di = -1; di <= 1; di++) {
            for (int dj = -1; dj <= 1; dj++) {
                int ni = Math.min(Math.max(i + di, 0), n - 1);
                int nj = Math.min(Math.max(j + dj, 0), m - 1);
                s += F[ni][nj] * C[di + 1][dj + 1];
            }
        }
        return s;
    }

    static void seq(int[][] F, int[][] C, int[][] V) {
        for (int i = 0; i < F.length; i++)
            for (int j = 0; j < F[0].length; j++)
                V[i][j] = convCell(F, C, i, j);
    }

    static void seqInplace(int[][] F, int[][] ker) {
        int n = F.length, m = F[0].length;
        int[] prev = new int[m];
        int[] curr = new int[m];
        int[] next = new int[m];
        int[] newRow = new int[m];

        System.arraycopy(F[0], 0, prev, 0, m);
        System.arraycopy(F[0], 0, curr, 0, m);
        if (n >= 2)
            System.arraycopy(F[1], 0, next, 0, m);
        else
            System.arraycopy(curr, 0, next, 0, m);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++)
                newRow[j] = convCellRow(prev, curr, next, ker, j, m);

            System.arraycopy(newRow, 0, F[i], 0, m);

            if (i + 1 < n) {
                int[] temp = prev;
                prev = curr;
                curr = next;
                next = temp;
                if (i + 2 < n)
                    System.arraycopy(F[i + 2], 0, next, 0, m);
                else
                    System.arraycopy(curr, 0, next, 0, m);
            }
        }
    }

    static int convCellRow(int[] up, int[] curr, int[] down, int[][] ker, int j, int m) {
        int jm1 = Math.max(0, j - 1);
        int jp1 = Math.min(m - 1, j + 1);
        int s = 0;
        s += up[jm1] * ker[0][0] + up[j] * ker[0][1] + up[jp1] * ker[0][2];
        s += curr[jm1] * ker[1][0] + curr[j] * ker[1][1] + curr[jp1] * ker[1][2];
        s += down[jm1] * ker[2][0] + down[j] * ker[2][1] + down[jp1] * ker[2][2];
        return s;
    }

    static boolean equal(int[][] A, int[][] B) {
        if (A.length != B.length || A[0].length != B[0].length)
            return false;
        for (int i = 0; i < A.length; i++)
            for (int j = 0; j < A[0].length; j++)
                if (A[i][j] != B[i][j])
                    return false;
        return true;
    }

    public static void main(String[] args) {
        int N = 100, M = 100;
        Random rnd = new Random();

        int[][] F1 = new int[N][M];
        int[][] F2 = new int[N][M];
        int[][] V = new int[N][M];
        int[][] ker = new int[3][3];

        for (int i = 0; i < N; i++)
            for (int j = 0; j < M; j++)
                F1[i][j] = F2[i][j] = rnd.nextInt(256);

        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                ker[i][j] = rnd.nextInt(3) - 1;

        seq(F1, ker, V);
        seqInplace(F2, ker);

        System.out.println(equal(V, F2)
                ? "Rezultatele sunt identice!"
                : " Rezultatele difera!");
    }
}
