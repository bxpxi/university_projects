#pragma once
#include <vector>

void filterSequentialInPlace(int N, int M, std::vector<int>& F, const int K[3][3]);
