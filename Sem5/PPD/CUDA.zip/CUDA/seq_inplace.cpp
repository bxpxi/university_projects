#include "seq_inplace.h"
#include <vector>

static inline int clampi(int x, int lo, int hi) {
    return x < lo ? lo : (x > hi ? hi : x);
}

void filterSequentialInPlace(int N, int M, std::vector<int>& F, const int K[3][3]) {
    if (N == 0 || M == 0)
        return;

    std::vector<int> prev(M), curr(M), next(M), out(M);

    auto loadRow = [&](int r, std::vector<int>& buf) {
        int rr = clampi(r, 0, N - 1);
        for (int j = 0; j < M; j++)
            buf[j] = F[(size_t)rr * M + j];
    };

    loadRow(0, prev);
    curr = prev;
    loadRow(1, next);

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            int sum = 0;
            for (int dj = -1; dj <= 1; dj++) {
                int jj = clampi(j + dj, 0, M - 1);
                sum += prev[jj] * K[0][dj + 1];
                sum += curr[jj] * K[1][dj + 1];
                sum += next[jj] * K[2][dj + 1];
            }
            out[j] = sum;
        }

        for (int j = 0; j < M; j++)
            F[(size_t)i * M + j] = out[j];

        prev.swap(curr);
        curr.swap(next);
        loadRow(i + 2, next);
    }
}
