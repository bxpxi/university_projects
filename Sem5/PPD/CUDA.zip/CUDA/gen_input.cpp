#include <iostream>
#include <fstream>
#include <random>
#include <stdexcept>

int main(int argc, char** argv) {
    if (argc < 4) {
        std::cerr << "Usage: gen_input <N> <M> <output_file> [seed]\n";
        return 1;
    }

    int N = std::stoi(argv[1]);
    int M = std::stoi(argv[2]);
    std::string outFile = argv[3];
    unsigned seed = (argc >= 5) ? (unsigned)std::stoul(argv[4]) : 42;

    if (N <= 0 || M <= 0)
        throw std::runtime_error("Invalid N/M");

    std::mt19937 rng(seed);
    std::uniform_int_distribution<int> distF(0, 255);
    std::uniform_int_distribution<int> distK(-2, 2);

    std::ofstream out(outFile);
    if (!out)
        throw std::runtime_error("Cannot open output file");

    out << N << " " << M << "\n";
    for (int i = 0; i < N * M; i++) {
        out << distF(rng) << (i + 1 == N * M ? '\n' : ' ');
    }

    for (int i = 0; i < 9; i++) {
        out << distK(rng) << (i == 8 ? '\n' : ' ');
    }

    return 0;
}
