#include "io.h"
#include <fstream>
#include <stdexcept>

InputData readInput(const std::string& filename) {
    std::ifstream in(filename);
    if (!in)
        throw std::runtime_error("Cannot open input file: " + filename);

    InputData d{};
    in >> d.N >> d.M;
    if (!in || d.N <= 0 || d.M <= 0)
        throw std::runtime_error("Invalid N/M in input");

    d.F.resize((size_t)d.N * d.M);
    for (int i = 0; i < d.N * d.M; i++) {
        in >> d.F[i];
        if (!in)
            throw std::runtime_error("Not enough matrix values");
    }

    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) {
            in >> d.K[i][j];
            if (!in)
                throw std::runtime_error("Not enough kernel values");
        }

    return d;
}

void writeMatrix(const std::string& filename, int N, int M, const std::vector<int>& F) {
    std::ofstream out(filename);
    if (!out)
        throw std::runtime_error("Cannot open output file: " + filename);

    out << N << " " << M << "\n";
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            out << F[(size_t)i * M + j] << (j + 1 == M ? '\n' : ' ');
        }
    }
}
