#include "benchmark.h"
#include "seq_inplace.h"
#include "cuda_inplace.h"
#include <chrono>
#include <stdexcept>

static bool equalVec(const std::vector<int>& a, const std::vector<int>& b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); i++) if (a[i] != b[i]) return false;
    return true;
}

Stats runSequential10x(int N, int M, const std::vector<int>& F0, const int K[3][3], std::vector<int>& out_seq) {
    const int RUNS = 10;
    double sum = 0.0;

    for (int r = 0; r < RUNS; r++) {
        std::vector<int> F = F0;

        auto t0 = std::chrono::high_resolution_clock::now();
        filterSequentialInPlace(N, M, F, K);
        auto t1 = std::chrono::high_resolution_clock::now();

        sum += std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (r == 0)
            out_seq = F;
        else if (!equalVec(F, out_seq))
            throw std::runtime_error("Sequential not deterministic!");
    }

    return { sum / RUNS };
}

Stats runCuda10x(int N, int M, const std::vector<int>& F0, const int K[3][3], int p, const std::vector<int>& ref_seq) {
    const int RUNS = 10;
    double sum = 0.0;

    for (int r = 0; r < RUNS; r++) {
        std::vector<int> F = F0;

        auto t0 = std::chrono::high_resolution_clock::now();
        filterCudaInPlaceRowSegments(N, M, F, K, p);
        auto t1 = std::chrono::high_resolution_clock::now();

        sum += std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (!equalVec(F, ref_seq))
            throw std::runtime_error("CUDA output mismatch vs sequential!");
    }

    return { sum / RUNS };
}
