#!/usr/bin/env bash
set -e

mkdir -p tests

CSV="results.csv"
echo "N,M,seq_avg_ms,cuda_p2_ms,cuda_p4_ms,cuda_p8_ms,cuda_p16_ms" > "$CSV"

run_case () {
  local N=$1
  local M=$2
  local SEED=$3
  local MODE=$4
  local OUTFILE=$5

  ./gen_input "$N" "$M" date.txt "$SEED"

  OUT=$(./CUDA "$MODE" "$OUTFILE")

  SEQ=$(echo "$OUT" | awk '/SEQ_AVG_MS/ {print $2; exit}')
  P2=$(echo "$OUT" | awk '$1=="CUDA_AVG_MS" && $2==2  {print $3; exit}')
  P4=$(echo "$OUT" | awk '$1=="CUDA_AVG_MS" && $2==4  {print $3; exit}')
  P8=$(echo "$OUT" | awk '$1=="CUDA_AVG_MS" && $2==8  {print $3; exit}')
  P16=$(echo "$OUT" | awk '$1=="CUDA_AVG_MS" && $2==16 {print $3; exit}')

  echo "${N},${M},${SEQ},${P2:-},${P4:-},${P8:-},${P16:-}" >> "$CSV"
}

run_case 10 10 42 10 "tests/test_10x10_3x3.out"
run_case 1000 1000 42 1000 "tests/test_1000x1000_3x3.out"
run_case 10000 10000 42 10000 "tests/test_10000x10000_3x3.out"

echo "DONE."
echo "Generated:"
echo "  date.txt"
echo "  tests/test_10x10_3x3.out"
echo "  tests/test_1000x1000_3x3.out"
echo "  tests/test_10000x10000_3x3.out"
echo "  results.csv"
