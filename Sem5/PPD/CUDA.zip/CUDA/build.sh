#!/usr/bin/env bash
set -e
make clean
make all
