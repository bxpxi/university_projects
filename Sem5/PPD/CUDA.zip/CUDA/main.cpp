#include "io.h"
#include "benchmark.h"
#include "seq_inplace.h"
#include <iostream>
#include <vector>
#include <stdexcept>

static void runCase(int N, int M, const std::vector<int>& F0, const int K[3][3], const std::vector<int>& p_values) {
    std::vector<int> seq_out;
    auto seq_stats = runSequential10x(N, M, F0, K, seq_out);

    std::cout << "SEQ_AVG_MS " << seq_stats.avg_ms << "\n";

    for (int p : p_values) {
        auto cuda_stats = runCuda10x(N, M, F0, K, p, seq_out);
        std::cout << "CUDA_AVG_MS " << p << " " << cuda_stats.avg_ms << "\n";
    }
}

int main(int argc, char** argv) {
    if (argc < 3) {
        std::cerr << "Usage: ./CUDA <10|1000|10000> <out_file>\n";
        return 1;
    }

    int mode = std::stoi(argv[1]);
    std::string out_file = argv[2];

    try {
        auto input = readInput("date.txt");
        int N = input.N, M = input.M;

        if (!((mode == 10 && N == 10 && M == 10) ||
              (mode == 1000 && N == 1000 && M == 1000) ||
              (mode == 10000 && N == 10000 && M == 10000))) {
            throw std::runtime_error("date.txt dimensions do not match requested mode");
        }

        std::vector<int> seq_out;
        runSequential10x(N, M, input.F, input.K, seq_out);
        writeMatrix(out_file, N, M, seq_out);

        if (mode == 10) {
            runCase(N, M, input.F, input.K, {2});
        } else {
            runCase(N, M, input.F, input.K, {2,4,8,16});
        }

        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Fatal: " << e.what() << "\n";
        return 1;
    }
}
