#pragma once
#include <vector>
#include <string>

struct InputData {
    int N, M;
    std::vector<int> F;//N*M
    int K[3][3];
};

InputData readInput(const std::string& filename);
void writeMatrix(const std::string& filename, int N, int M, const std::vector<int>& F);
