#pragma once
#include <vector>

struct Stats {
    double avg_ms;
};

Stats runSequential10x(int N, int M, const std::vector<int>& F0, const int K[3][3], std::vector<int>& out_seq);
Stats runCuda10x(int N, int M, const std::vector<int>& F0, const int K[3][3], int p, const std::vector<int>& ref_seq);
