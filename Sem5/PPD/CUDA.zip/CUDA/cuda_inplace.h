#pragma once
#include <vector>

void filterCudaInPlaceRowSegments(int N, int M, std::vector<int>& F, const int K[3][3], int p);
