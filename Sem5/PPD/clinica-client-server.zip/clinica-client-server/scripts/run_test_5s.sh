#!/bin/bash
set -e

OUT_DIR=out/test_5s

rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR"

export OUT_DIR

./scripts/compile.sh

echo "Starting server (5s verification)..."
java -cp build ro.clinica.server.ServerMain \
  --verifySec 5 \
  --runSec 180 &
SERVER_PID=$!

sleep 2

echo "Starting clients..."
java -cp build ro.clinica.client.ClientMain --clients 10

wait $SERVER_PID

echo "TEST 5s DONE"
