#!/bin/bash
set -e

./scripts/compile.sh

echo "Starting server..."
java -cp build ro.clinica.server.ServerMain \
  --port 5050 \
  --threads 10 \
  --verifySec 5 \
  --runSec 180
