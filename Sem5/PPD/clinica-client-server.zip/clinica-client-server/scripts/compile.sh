#!/bin/bash
set -e

rm -rf build
mkdir -p build

echo "Compiling Java sources..."
find src -name "*.java" > sources.txt

javac -encoding UTF-8 -d build @sources.txt

echo "Compile OK"
