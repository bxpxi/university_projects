#!/bin/bash
set -e

./scripts/compile.sh

echo "Starting clients..."
java -cp build ro.clinica.client.ClientMain \
  --host localhost \
  --port 5050 \
  --clients 10
