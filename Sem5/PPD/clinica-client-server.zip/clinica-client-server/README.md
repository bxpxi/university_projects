# Proiect 1 – Aplicație Client–Server (Clinică Medicală)

## Descriere generală
Acest proiect implementează o aplicație de tip client–server pentru gestionarea programărilor într-o
clinică medicală, conform cerințelor temei. Aplicația folosește programare concurentă, execuție
asincronă prin futures și un thread pool limitat pentru procesarea cererilor.

Sistemul permite:
- realizarea de programări pentru tratamente medicale;
- efectuarea plăților asociate programărilor;
- anularea programărilor și returnarea banilor;
- expirarea automată a programărilor neplătite;
- verificarea periodică a consistenței datelor;
- măsurarea performanței (timp de răspuns și throughput).

Nu există interfață grafică; comunicarea se face printr-un protocol text peste TCP.

---

## Structura proiectului

- **common/** – protocolul și modelele de mesaje (client - server)
- **server/** – logica de business, concurență, verificare, persistență
- **client/** – simulare clienți concurenți + măsurare metrici
- **scripts/** – scripturi de compilare și rulare
- **out/** – fișiere rezultate din rulări


---

## Cerințe implementate
- aplicație client–server TCP
- execuție concurentă cu thread pool (maxim p=10 thread-uri)
- folosirea `CompletableFuture` pentru fiecare cerere de programare
- verificare periodică la 5s și 10s
- persistență în fișiere text
- suport pentru anulare, refund și expirare
- notificarea clienților la shutdown-ul serverului
- analiză de performanță (latență și throughput)

---

## Compilare

```bash
./scripts/compile.sh
```

Scriptul compilează toate sursele Java și generează directorul **build/**.

## Rulare – verificare la 5 secunde

```bash
./scripts/run_test_5s.sh
```

Rezultatele sunt salvate în **out/test_5s/** .

## Rulare – verificare la 10 secunde

```bash
./scripts/run_test_10s.sh
```

Rezultatele sunt salvate în **out/test_10s/** .

---

## Parametri principali
### Server

- **--port** – port TCP (implicit 5050)

- **--threads** – număr maxim de thread-uri (implicit 10)

- **--verifySec** – interval verificare (5 sau 10 secunde)

- **--runSec** – durata rulării serverului (implicit 180 secunde)

### Client

- **--host** – adresa serverului (implicit localhost)

- **--port** – port server

- **--clients** – număr de clienți simulați (implicit 10)

---

## Funcționarea clientului

Fiecare client:

- trimite o cerere de programare la fiecare 2 secunde;

- primește notificare de tip „programare reușită” sau „nereușită”;

- în caz de succes:

    - 30% din programări NU sunt plătite (expiră);

    - 70% sunt plătite;

    - 10% din cele plătite sunt ulterior anulate (refund).
  
---

## Fișiere generate

În fiecare director de test (**out/test_5s/**, **out/test_10s/**) se generează:

- **bookings.txt** – toate programările (cu status)

- **payments.txt** – plăți efectuate

- **refunds.txt** – returnări de bani (sume negative)

- **expired.txt** – programări expirate (ID)

- **canceled.txt** – programări anulate (ID)

- **verification_*.txt** – rezultate verificări periodice

- **metrics.txt** – metrici de performanță (latență, throughput)

---

## Metrici de performanță

Metricile sunt măsurate la nivel de client:

- **timp de răspuns**: intervalul dintre trimiterea BOOK_REQUEST și primirea BOOK_RESPONSE;

- **throughput**: număr de răspunsuri primite pe secundă.

Valorile sunt salvate automat în **metrics.txt** pentru fiecare test.

---

## Mediu de lucru

- Limbaj: Java 17

- Sistem de operare: WSL (Ubuntu)

- Fără framework-uri externe

- Compilare și rulare prin scripturi Bash

---

## Observații

- Persistența este realizată în fișiere text, conform cerinței.

- Refunds-urile sunt salvate separat pentru claritate, dar sunt tratate logic ca plăți negative.

- Verificările periodice nu pot observa stări intermediare inconsistente, conform cerinței.

