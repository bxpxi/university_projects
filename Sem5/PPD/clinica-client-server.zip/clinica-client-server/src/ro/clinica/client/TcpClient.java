package ro.clinica.client;

import ro.clinica.common.MsgType;
import ro.clinica.common.Protocol;

import java.io.*;
import java.net.Socket;
import java.util.function.Consumer;

public class TcpClient implements Closeable {

    private final Socket socket;
    private final BufferedReader in;
    private final BufferedWriter out;

    private volatile boolean running = true;

    public TcpClient(String host, int port, Consumer<String> onLine) throws IOException {
        this.socket = new Socket(host, port);
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

        Thread reader = new Thread(() -> readLoop(onLine), "client-reader");
        reader.start();
    }

    private void readLoop(Consumer<String> onLine) {
        try {
            String line;
            while (running && (line = in.readLine()) != null) {
                onLine.accept(line);
            }
        } catch (IOException ignored) {
        } finally {
            running = false;
        }
    }

    public void send(String line) {
        synchronized (out) {
            try {
                out.write(line);
                out.newLine();
                out.flush();
            } catch (IOException e) {
                running = false;
            }
        }
    }

    public boolean isRunning() {
        return running;
    }

    @Override
    public void close() {
        running = false;
        try {
            socket.close();
        } catch (IOException ignored) {

        }

        try {
            in.close();
        } catch (IOException ignored) {

        }

        try {
            out.close();
        } catch (IOException ignored) {

        }
    }
}
