package ro.clinica.client;

import ro.clinica.common.MsgType;
import ro.clinica.common.Protocol;

import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SimulatedClient implements Runnable {

    private final String host;
    private final int port;
    private final int id;
    private final ClientMain.Metrics metrics;

    private final Map<Long, Integer> bookingCost = new ConcurrentHashMap<>();
    private final Map<Long, String> bookingCnp = new ConcurrentHashMap<>();
    private final Map<Long, Long> sentTime = new ConcurrentHashMap<>();

    private volatile boolean running = true;
    private volatile TcpClient clientRef;

    public SimulatedClient(String host, int port, int id, ClientMain.Metrics metrics) {
        this.host = host;
        this.port = port;
        this.id = id;
        this.metrics = metrics;
    }

    @Override
    public void run() {
        try (TcpClient client = new TcpClient(host, port, this::handleLine)) {
            this.clientRef = client;

            while (client.isRunning() && running) {
                sendBooking(client);
                Thread.sleep(2000);
            }
        } catch (Exception ignored) {
        } finally {
            this.clientRef = null;
        }
    }

    private void sendBooking(TcpClient client) {
        long bid = RandomData.bookingId();
        String name = RandomData.name();
        String cnp = RandomData.cnp();
        int loc = RandomData.location();
        int tr = RandomData.treatment();

        bookingCost.put(bid, costForTreatment(tr));
        bookingCnp.put(bid, cnp);

        sentTime.put(bid, System.currentTimeMillis());
        metrics.onSend();

        client.send(Protocol.encode(
                MsgType.BOOK_REQUEST.name(),
                String.valueOf(bid),
                name,
                cnp,
                String.valueOf(loc),
                String.valueOf(tr),
                RandomData.date().toString(),
                RandomData.time().format(DateTimeFormatter.ISO_LOCAL_TIME)
        ));
    }

    private void handleLine(String line) {
        String[] p = Protocol.decode(line);
        MsgType type = MsgType.valueOf(p[0]);

        if (type == MsgType.BOOK_RESPONSE) {
            handleBookResponse(p);
        } else if (type == MsgType.SHUTDOWN_NOTICE) {
            handleShutdown(p);
        }
    }

    private void handleBookResponse(String[] p) {
        long bookingId = Long.parseLong(p[1]);
        boolean success = Boolean.parseBoolean(p[2]);

        Long t0 = sentTime.remove(bookingId);
        if (t0 != null) {
            long latency = System.currentTimeMillis() - t0;
            metrics.onResponse(latency);
        }

        if (!success)
            return;

        if (Math.random() < 0.30)
            return; // simulare expirare ca sa se vada mai bine cand rulez ca functioneaza

        Integer amount = bookingCost.get(bookingId);
        String cnp = bookingCnp.get(bookingId);
        if (amount == null || cnp == null)
            return;

        sendPayment(bookingId, cnp, amount);

        // simulare cancel tot din acelasi motiv
        if (Math.random() < 0.10) {
            sendCancel(bookingId, cnp);
        }
    }

    private void sendPayment(long bookingId, String cnp, int amount) {
        TcpClient c = clientRef;
        if (c == null || !c.isRunning()) return;

        c.send(Protocol.encode(
                MsgType.PAY_REQUEST.name(),
                String.valueOf(bookingId),
                cnp,
                String.valueOf(amount)
        ));
    }

    private void sendCancel(long bookingId, String cnp) {
        TcpClient c = clientRef;
        if (c == null || !c.isRunning()) return;

        c.send(Protocol.encode(
                MsgType.CANCEL_REQUEST.name(),
                String.valueOf(bookingId),
                cnp
        ));
    }

    private void handleShutdown(String[] p) {
        System.out.println("Client " + id + " shutdown: " + p[1]);
        running = false;

        TcpClient c = clientRef;
        if (c != null) c.close();
    }

    private int costForTreatment(int t) {
        return switch (t) {
            case 1 -> 50;
            case 2 -> 20;
            case 3 -> 40;
            case 4 -> 100;
            case 5 -> 30;
            default -> 0;
        };
    }
}
