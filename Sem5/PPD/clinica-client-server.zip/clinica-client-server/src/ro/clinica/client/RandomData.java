package ro.clinica.client;

import ro.clinica.common.Ids;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Random;

public final class RandomData {

    private static final Random RND = new Random();

    private RandomData() {}

    public static long bookingId() {
        return Ids.next();
    }

    public static String name() {
        return "Client" + (100 + RND.nextInt(900));
    }

    public static String cnp() {
        return String.valueOf(1000000000000L + Math.abs(RND.nextLong() % 1_000_000_000_000L));
    }

    public static int location() {
        return 1 + RND.nextInt(5);
    }

    public static int treatment() {
        return 1 + RND.nextInt(5);
    }

    public static LocalDate date() {
        return LocalDate.now();
    }

    public static LocalTime time() {
        int hour = 10 + RND.nextInt(8);
        int minute = RND.nextBoolean() ? 0 : 30;
        return LocalTime.of(hour, minute);
    }
}
