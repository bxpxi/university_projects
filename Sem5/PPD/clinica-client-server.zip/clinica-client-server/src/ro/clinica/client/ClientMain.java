package ro.clinica.client;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class ClientMain {

    public static void main(String[] args) throws Exception {
        String host = arg(args, "--host", "localhost");
        int port = intArg(args, "--port", 5050);
        int clients = intArg(args, "--clients", 10);

        System.out.println("Pornesc " + clients + " clienti catre " + host + ":" + port);

        Metrics metrics = new Metrics();

        List<Thread> threads = new ArrayList<>();
        for (int i = 1; i <= clients; i++) {
            Thread t = new Thread(
                    new SimulatedClient(host, port, i, metrics),
                    "sim-client-" + i
            );
            threads.add(t);
            t.start();
        }

        for (Thread t : threads) {
            t.join();
        }

        writeMetrics(metrics, clients);
        System.out.println("Metrici scrise.");
    }

    static final class Metrics {
        private long sent = 0;
        private long responses = 0;

        private double sumMs = 0;
        private double minMs = Double.MAX_VALUE;
        private double maxMs = 0;

        private final long startMillis = System.currentTimeMillis();
        private long endMillis = startMillis;

        synchronized void onSend() {
            sent++;
        }

        synchronized void onResponse(long latencyMs) {
            responses++;
            sumMs += latencyMs;
            minMs = Math.min(minMs, latencyMs);
            maxMs = Math.max(maxMs, latencyMs);
            endMillis = System.currentTimeMillis();
        }

        synchronized String report(int clients) {
            double durationSec = Math.max(1, (endMillis - startMillis)) / 1000.0;
            double avg = responses == 0 ? 0 : sumMs / responses;
            double throughput = responses / durationSec;

            return """
                    === METRICS CLIENT ===
                    timestamp_utc=%s
                    clients=%d
                    duration_sec=%.2f
                    book_requests_sent=%d
                    book_responses_received=%d

                    avg_latency_ms=%.2f
                    min_latency_ms=%.2f
                    max_latency_ms=%.2f
                    throughput_responses_per_sec=%.2f
                    """.formatted(
                    Instant.now(),
                    clients,
                    durationSec,
                    sent,
                    responses,
                    avg,
                    minMs == Double.MAX_VALUE ? 0 : minMs,
                    maxMs,
                    throughput
            );
        }
    }

    private static void writeMetrics(Metrics m, int clients) {
        String outDir = System.getenv().getOrDefault("OUT_DIR", "out");
        Path p = Path.of(outDir, "metrics.txt");

        try {
            Files.createDirectories(p.getParent());
            Files.writeString(
                    p,
                    m.report(clients),
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING
            );
        } catch (IOException e) {
            System.err.println("Eroare scriere metrics: " + e.getMessage());
        }
    }

    private static String arg(String[] args, String key, String def) {
        for (int i = 0; i < args.length - 1; i++) {
            if (args[i].equals(key)) return args[i + 1];
        }
        return def;
    }

    private static int intArg(String[] args, String key, int def) {
        for (int i = 0; i < args.length - 1; i++) {
            if (args[i].equals(key)) return Integer.parseInt(args[i + 1]);
        }
        return def;
    }
}
