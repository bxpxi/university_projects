package ro.clinica.server;

import ro.clinica.common.Messages;
import ro.clinica.common.TimeUtil;
import ro.clinica.server.models.Booking;
import ro.clinica.server.models.Payment;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.*;

public class BookingService {

    private final ClinicState state;
    private final ThreadPools pools;

    public BookingService(ClinicState state, ThreadPools pools) {
        this.state = state;
        this.pools = pools;
    }

    public CompletableFuture<Messages.BookingResponse> bookAsync(Messages.BookingRequest req) {
        return CompletableFuture.supplyAsync(() -> book(req), pools.requestPool());
    }

    private Messages.BookingResponse book(Messages.BookingRequest req) {
        if (!sameDay(req.date())) {
            return new Messages.BookingResponse(req.id(), false, "Doar aceeasi zi este permisa.");
        }

        int duration = ClinicConfig.TREATMENT_DURATION[req.treatment() - 1];
        LocalTime start = req.time();

        if (!TimeUtil.inProgram(start, duration)) {
            return new Messages.BookingResponse(req.id(), false, "In afara programului 10:00-18:00.");
        }

        state.lock();
        try {
            if (!capacityOk(req.location(), req.treatment(), req.date(), start, duration)) {
                return new Messages.BookingResponse(req.id(), false, "Programare nereusita (capacitate depasita).");
            }

            Booking b = new Booking(req.id(), req.name(), req.cnp(), req.location(), req.treatment(), req.date(), req.time());

            state.addBooking(b);
            Persistence.saveBooking(b);

            scheduleExpiration(b.getId());

            return new Messages.BookingResponse(b.getId(), true, "Programare reusita (rezervare).");
        } finally {
            state.unlock();
        }
    }

    public boolean pay(Messages.PaymentRequest pay) {
        state.lock();
        try {
            Booking b = state.getBooking(pay.bookingId());
            if (b == null)
                return false;
            if (b.getStatus() != Booking.Status.RESERVED)
                return false;
            if (!b.getCnp().equals(pay.cnp()))
                return false;

            int expected = ClinicConfig.TREATMENT_COST[b.getTreatment() - 1];
            if (pay.amount() != expected)
                return false;

            b.markPaid();
            Persistence.saveBooking(b);

            Payment p = new Payment(b.getId(), b.getCnp(), pay.amount());
            state.addPayment(p);
            Persistence.savePayment(p);

            return true;
        } finally {
            state.unlock();
        }
    }


    public boolean cancel(Messages.CancelRequest cancel) {
        state.lock();
        try {
            Booking b = state.getBooking(cancel.bookingId());
            if (b == null)
                return false;
            if (!b.getCnp().equals(cancel.cnp()))
                return false;
            if (b.getStatus() == Booking.Status.CANCELED || b.getStatus() == Booking.Status.EXPIRED)
                return false;

            b.markCanceled();
            Persistence.saveBooking(b);
            Persistence.saveCanceled(b.getId());

            Payment pos = state.removePositivePaymentForBooking(b.getId());
            if (pos != null) {
                int refundAmount = -pos.getAmount();
                Payment refund = new Payment(b.getId(), b.getCnp(), refundAmount);
                state.addPayment(refund);
                Persistence.saveRefund(refund);
            }
            return true;
        } finally {
            state.unlock();
        }
    }

    private void scheduleExpiration(long bookingId) {
        pools.scheduler().schedule(() -> {
            state.lock();
            try {
                Booking b = state.getBooking(bookingId);
                if (b == null)
                    return;

                if (b.getStatus() == Booking.Status.RESERVED) {
                    state.removeBooking(bookingId);
                    Persistence.saveExpired(bookingId);
                }
            } finally {
                state.unlock();
            }
        }, ClinicConfig.PAYMENT_TIMEOUT_SEC, TimeUnit.SECONDS);
    }

    private boolean sameDay(LocalDate date) {
        return date != null;
    }

    private boolean capacityOk(int location, int treatment, LocalDate date, LocalTime start, int duration) {
        int capacity = ClinicConfig.capacity(location, treatment);

        List<Interval> intervals = new ArrayList<>();
        for (var b : state.allBookings()) {
            if (!b.occupiesCapacity() || b.getLocation() != location || b.getTreatment() != treatment || !b.getDate().equals(date))
                continue;

            int d = ClinicConfig.TREATMENT_DURATION[b.getTreatment() - 1];
            intervals.add(new Interval(b.getTime(), b.getTime().plusMinutes(d)));
        }

        intervals.add(new Interval(start, start.plusMinutes(duration)));

        intervals.sort(Comparator.comparing(i -> i.start));

        List<Event> events = new ArrayList<>(intervals.size() * 2);
        for (Interval in : intervals) {
            events.add(new Event(in.start, +1));
            events.add(new Event(in.end, -1));
        }
        events.sort((a, b) -> {
            int c = a.t.compareTo(b.t);
            if (c != 0) return c;
            return Integer.compare(a.delta, b.delta);
        });

        int curr = 0;
        int max = 0;
        for (Event e : events) {
            curr += e.delta;
            if (curr > max) max = curr;
            if (max > capacity)
                return false;
        }
        return true;
    }

    private record Interval(LocalTime start, LocalTime end) {}
    private record Event(LocalTime t, int delta) {}
}
