package ro.clinica.server.models;

import java.time.LocalDate;
import java.time.LocalTime;

public class Booking {

    public enum Status {
        RESERVED,
        PAID,
        CANCELED,
        EXPIRED
    }

    private final long id;
    private final String name;
    private final String cnp;
    private final int location;
    private final int treatment;
    private final LocalDate date;
    private final LocalTime time;

    private Status status;
    private final long createdAtMillis;

    public Booking(long id, String name, String cnp, int location, int treatment, LocalDate date, LocalTime time) {
        this.id = id;
        this.name = name;
        this.cnp = cnp;
        this.location = location;
        this.treatment = treatment;
        this.date = date;
        this.time = time;
        this.status = Status.RESERVED;
        this.createdAtMillis = System.currentTimeMillis();
    }

    public long getId() { return id; }
    public String getName() { return name; }
    public String getCnp() { return cnp; }
    public int getLocation() { return location; }
    public int getTreatment() { return treatment; }
    public LocalDate getDate() { return date; }
    public LocalTime getTime() { return time; }
    public Status getStatus() { return status; }
    public long getCreatedAtMillis() { return createdAtMillis; }

    public boolean occupiesCapacity() {
        return status == Status.RESERVED || status == Status.PAID;
    }

    public void markPaid() {
        this.status = Status.PAID;
    }

    public void markCanceled() {
        this.status = Status.CANCELED;
    }

    public void markExpired() {
        this.status = Status.EXPIRED;
    }
}
