package ro.clinica.server;

import java.util.concurrent.CountDownLatch;

public class ServerMain {

    public static void main(String[] args) throws Exception {
        int port = intArg(args, "--port", 5050);
        int threads = intArg(args, "--threads", ClinicConfig.SERVER_THREADS);
        int verifySec = intArg(args, "--verifySec", 5);
        int runSec = intArg(args, "--runSec", 180);

        ClinicState state = new ClinicState();
        ThreadPools pools = new ThreadPools(threads);

        BookingService bookingService = new BookingService(state, pools);

        String verificationFile = (verifySec == 10) ? "verification_10s.txt" : "verification_5s.txt";
        VerificationService verification = new VerificationService(state, pools, verifySec, verificationFile);
        verification.start();

        TcpServer server = new TcpServer(port, bookingService);
        server.start();

        System.out.println("Server pornit pe port " + port + " | threads=" + threads + " | verifySec=" + verifySec + " | runSec=" + runSec);

        CountDownLatch done = new CountDownLatch(1);

        pools.scheduler().schedule(() -> {
            System.out.println("Server se inchide (timp expirat). Clienti activi=" + server.activeClients());
            server.shutdownAndNotify("Server se inchide acum (timp expirat).");
            pools.shutdownGracefully(2000);
            done.countDown();
        }, runSec, java.util.concurrent.TimeUnit.SECONDS);

        done.await();
    }

    private static int intArg(String[] args, String key, int def) {
        for (int i = 0; i < args.length - 1; i++) {
            if (args[i].equals(key)) {
                return Integer.parseInt(args[i + 1]);
            }
        }
        return def;
    }
}
