package ro.clinica.server.models;

public record Treatment(
        int id,
        int cost,
        int durationMinutes
) {}
