package ro.clinica.server;

import ro.clinica.server.models.Booking;
import ro.clinica.server.models.Payment;

import java.util.*;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

public class ClinicState {

    private final ReentrantLock lock = new ReentrantLock(true);

    private final Map<Long, Booking> bookings = new HashMap<>();
    private final List<Payment> payments = new ArrayList<>();

    public void lock() {
        lock.lock();
    }

    public void unlock() {
        lock.unlock();
    }

    public void addBooking(Booking booking) {
        bookings.put(booking.getId(), booking);
    }

    public void removeBooking(long bookingId) {
        bookings.remove(bookingId);
    }

    public Booking getBooking(long id) {
        return bookings.get(id);
    }

    public Collection<Booking> allBookings() {
        return bookings.values();
    }

    public List<Booking> unpaidBookings() {
        return bookings.values().stream()
                .filter(b -> b.getStatus() == Booking.Status.RESERVED)
                .collect(Collectors.toList());
    }

    public void addPayment(Payment payment) {
        payments.add(payment);
    }

    public List<Payment> allPayments() {
        return payments;
    }

    public Payment removePositivePaymentForBooking(long bookingId) {
        for (Iterator<Payment> it = payments.iterator(); it.hasNext(); ) {
            Payment p = it.next();
            if (p.getBookingId() == bookingId && p.getAmount() > 0) {
                it.remove();
                return p;
            }
        }
        return null;
    }

    public int netBalanceForLocation(int location) {
        int sum = 0;
        for (Payment p : payments) {
            Booking b = bookings.get(p.getBookingId());
            if (b != null && b.getLocation() == location) {
                sum += p.getAmount();
            }
        }
        return sum;
    }
}
