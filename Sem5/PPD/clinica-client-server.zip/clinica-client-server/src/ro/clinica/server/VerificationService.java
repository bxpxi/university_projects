package ro.clinica.server;

import ro.clinica.server.models.Booking;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

public class VerificationService {

    private final ClinicState state;
    private final ThreadPools pools;
    private final int intervalSeconds;
    private final Path outFile;

    public VerificationService(ClinicState state, ThreadPools pools, int intervalSeconds, String outFileName) throws IOException {
        this.state = state;
        this.pools = pools;
        this.intervalSeconds = intervalSeconds;
        String outDir = System.getenv().getOrDefault("OUT_DIR", "out");
        this.outFile = Path.of(outDir).resolve(outFileName);
        Files.createDirectories(Path.of(outDir));
    }

    public void start() {
        pools.scheduler().scheduleAtFixedRate(this::runOnceSafe, intervalSeconds, intervalSeconds, java.util.concurrent.TimeUnit.SECONDS);
    }

    private void runOnceSafe() {
        try {
            runOnce();
        } catch (Exception e) {
            append("VERIFICATION_ERROR: " + e.getMessage());
        }
    }

    private void runOnce() {
        LocalDateTime now = LocalDateTime.now();

        state.lock();
        try {
            for (int loc = 1; loc <= ClinicConfig.NUM_LOCATIONS; loc++) {
                int balance = state.netBalanceForLocation(loc);

                int finalLoc = loc;
                List<Long> unpaid = state.unpaidBookings().stream()
                        .filter(b -> b.getLocation() == finalLoc)
                        .map(Booking::getId)
                        .sorted()
                        .toList();

                List<String> overlaps = findOverlapsForLocation(loc);

                append("Ora verificarii: " + now);
                append("  (" + loc + ", sold_total_locatie=" + balance + ")");
                append("  neplatite=" + unpaid);
                if (overlaps.isEmpty()) {
                    append("  suprapuneri=[]");
                } else {
                    append("  suprapuneri=");
                    for (String s : overlaps) append("    " + s);
                }
                append("");
            }
        } finally {
            state.unlock();
        }
    }

    private List<String> findOverlapsForLocation(int location) {
        List<String> issues = new ArrayList<>();

        for (int tr = 1; tr <= ClinicConfig.NUM_TREATMENTS; tr++) {
            int cap = ClinicConfig.capacity(location, tr);
            int finalTr = tr;
            List<Booking> list = state.allBookings().stream()
                    .filter(Booking::occupiesCapacity)
                    .filter(b -> b.getLocation() == location && b.getTreatment() == finalTr)
                    .toList();

            if (list.isEmpty()) continue;

            List<Event> events = new ArrayList<>(list.size() * 2);
            for (Booking b : list) {
                int d = ClinicConfig.TREATMENT_DURATION[tr - 1];
                LocalTime s = b.getTime();
                LocalTime e = s.plusMinutes(d);
                events.add(new Event(s, +1));
                events.add(new Event(e, -1));
            }
            events.sort((a, b) -> {
                int c = a.t.compareTo(b.t);
                if (c != 0) return c;
                return Integer.compare(a.delta, b.delta); // end(-1) inainte de start(+1)
            });

            int curr = 0;
            int max = 0;
            for (Event ev : events) {
                curr += ev.delta;
                max = Math.max(max, curr);
            }

            if (max > cap) {
                issues.add("loc=" + location + " tratament=" + tr + " cap=" + cap + " max_concurent=" + max);
            }
        }

        return issues;
    }

    private void append(String line) {
        try {
            Files.writeString(outFile, line + System.lineSeparator(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private record Event(LocalTime t, int delta) {}
}
