package ro.clinica.server;

import ro.clinica.server.models.Booking;
import ro.clinica.server.models.Payment;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class Persistence {

    private static final Path OUT_DIR = Path.of(System.getenv().getOrDefault("OUT_DIR", "out"));
    private static final Path BOOKINGS = OUT_DIR.resolve("bookings.txt");
    private static final Path PAYMENTS = OUT_DIR.resolve("payments.txt");
    private static final Path REFUNDS = OUT_DIR.resolve("refunds.txt");
    private static final Path EXPIRED = OUT_DIR.resolve("expired.txt");
    private static final Path CANCELED = OUT_DIR.resolve("canceled.txt");

    static {
        try {
            Files.createDirectories(OUT_DIR);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void saveBooking(Booking b) {
        append(BOOKINGS,
                b.getId() + "," +
                        b.getName() + "," +
                        b.getCnp() + "," +
                        b.getDate() + "," +
                        b.getLocation() + "," +
                        b.getTreatment() + "," +
                        b.getDate() + "," +
                        b.getTime() + "," +
                        b.getStatus());
    }

    public static void savePayment(Payment p) {
        append(PAYMENTS,
                p.getBookingId() + "," +
                        p.getTimestamp().toLocalDate() + "," +
                        p.getCnp() + "," +
                        p.getAmount());
    }

    public static void saveRefund(Payment p) {
        append(REFUNDS,
                p.getBookingId() + "," +
                        p.getTimestamp().toLocalDate() + "," +
                        p.getCnp() + "," +
                        p.getAmount());
    }

    public static void saveExpired(long bookingId) {
        append(EXPIRED, String.valueOf(bookingId));
    }

    public static void saveCanceled(long bookingId) {
        append(CANCELED, String.valueOf(bookingId));
    }

    private static void append(Path file, String line) {
        try {
            Files.writeString(
                    file,
                    line + System.lineSeparator(),
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND
            );
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
