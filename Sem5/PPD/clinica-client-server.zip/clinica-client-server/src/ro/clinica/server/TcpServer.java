package ro.clinica.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class TcpServer {

    private final int port;
    private final BookingService bookingService;

    private final Set<ClientSession> sessions = ConcurrentHashMap.newKeySet();

    private volatile boolean running = false;
    private ServerSocket serverSocket;
    private Thread acceptThread;

    public TcpServer(int port, BookingService bookingService) {
        this.port = port;
        this.bookingService = bookingService;
    }

    public void start() throws IOException {
        serverSocket = new ServerSocket(port);
        running = true;

        acceptThread = new Thread(this::acceptLoop, "accept-thread");
        acceptThread.start();
    }

    private void acceptLoop() {
        while (running) {
            try {
                Socket socket = serverSocket.accept();
                ClientSession session = new ClientSession(socket, this, bookingService);
                sessions.add(session);

                Thread t = new Thread(session, "client-session-" + socket.getRemoteSocketAddress());
                t.start();
            } catch (IOException e) {
                if (running) {
                    System.err.println("Accept error: " + e.getMessage());
                }
                break;
            }
        }
    }

    void unregister(ClientSession s) {
        sessions.remove(s);
    }

    public int activeClients() {
        return sessions.size();
    }

    public void shutdownAndNotify(String msg) {
        running = false;

        for (ClientSession s : sessions) {
            s.sendShutdownNotice(msg);
        }

        try { serverSocket.close(); } catch (IOException ignored) {}

        for (ClientSession s : sessions) {
            s.close();
        }

        if (acceptThread != null) {
            try { acceptThread.join(2000); } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
