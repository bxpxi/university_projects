package ro.clinica.server;

import java.util.concurrent.*;

public final class ThreadPools {

    private final ExecutorService requestPool;
    private final ScheduledExecutorService scheduler;

    public ThreadPools(int maxThreads) {
        this.requestPool = Executors.newFixedThreadPool(maxThreads);
        this.scheduler = Executors.newScheduledThreadPool(2);
    }

    public ExecutorService requestPool() {
        return requestPool;
    }

    public ScheduledExecutorService scheduler() {
        return scheduler;
    }

    public void shutdownNow() {
        requestPool.shutdownNow();
        scheduler.shutdownNow();
    }

    public void shutdownGracefully(long timeoutMs) {
        requestPool.shutdown();
        scheduler.shutdown();
        try {
            requestPool.awaitTermination(timeoutMs, TimeUnit.MILLISECONDS);
            scheduler.awaitTermination(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        } finally {
            requestPool.shutdownNow();
            scheduler.shutdownNow();
        }
    }
}
