package ro.clinica.server;

public final class ClinicConfig {

    public static final int NUM_LOCATIONS = 5;
    public static final int NUM_TREATMENTS = 5;
    public static final int SERVER_THREADS = 10;
    public static final int CLIENTS = 10;

    public static final int[] TREATMENT_DURATION = {120, 20, 30, 60, 30};

    public static final int[] TREATMENT_COST = {50, 20, 40, 100, 30};

    private static final int[] BASE_CAPACITY = {3, 1, 1, 2, 1};

    public static final int PAYMENT_TIMEOUT_SEC = 15;

    private ClinicConfig() {}

    public static int capacity(int location, int treatment) {
        int base = BASE_CAPACITY[treatment - 1];
        if (location <= 1)
            return base;
        return base * (location - 1);
    }
}
