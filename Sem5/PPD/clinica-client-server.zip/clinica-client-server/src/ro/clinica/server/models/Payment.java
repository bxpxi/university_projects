package ro.clinica.server.models;

import java.time.LocalDateTime;

public class Payment {

    private final long bookingId;
    private final String cnp;
    private final int amount;
    private final LocalDateTime timestamp;

    public Payment(long bookingId, String cnp, int amount) {
        this.bookingId = bookingId;
        this.cnp = cnp;
        this.amount = amount;
        this.timestamp = LocalDateTime.now();
    }

    public long getBookingId() {
        return bookingId;
    }

    public String getCnp() {
        return cnp;
    }

    public int getAmount() {
        return amount;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
}
