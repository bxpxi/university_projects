package ro.clinica.server;

import ro.clinica.common.MsgType;
import ro.clinica.common.Protocol;
import ro.clinica.common.Messages;

import java.io.*;
import java.net.Socket;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.concurrent.CompletableFuture;

public class ClientSession implements Runnable {

    private final Socket socket;
    private final TcpServer server;
    private final BookingService bookingService;

    private final BufferedReader in;
    private final BufferedWriter out;

    private volatile boolean running = true;

    public ClientSession(Socket socket, TcpServer server, BookingService bookingService) throws IOException {
        this.socket = socket;
        this.server = server;
        this.bookingService = bookingService;
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
    }

    @Override
    public void run() {
        try {
            String line;
            while (running && (line = in.readLine()) != null) {
                handleLine(line);
            }
        } catch (IOException ignored) {

        } finally {
            close();
            server.unregister(this);
        }
    }

    private void handleLine(String line) {
        String[] parts = Protocol.decode(line);
        if (parts.length == 0) return;

        MsgType type;
        try {
            type = MsgType.valueOf(parts[0]);
        } catch (Exception e) {
            sendError("Mesaj invalid: tip necunoscut.");
            return;
        }

        switch (type) {
            case BOOK_REQUEST -> handleBook(parts);
            case PAY_REQUEST -> handlePay(parts);
            case CANCEL_REQUEST -> handleCancel(parts);
            default -> sendError("Tip mesaj neacceptat: " + type);
        }
    }

    private void handleBook(String[] p) {
        // BOOK_REQUEST|id|name|cnp|location|treatment|date|time
        if (p.length < 8) {
            sendError("BOOK_REQUEST invalid.");
            return;
        }
        try {
            long id = Long.parseLong(p[1]);
            String name = p[2];
            String cnp = p[3];
            int location = Integer.parseInt(p[4]);
            int treatment = Integer.parseInt(p[5]);
            LocalDate date = LocalDate.parse(p[6]);
            LocalTime time = LocalTime.parse(p[7]);

            Messages.BookingRequest req = new Messages.BookingRequest(
                    id, name, cnp, location, treatment, date, time
            );

            CompletableFuture<Messages.BookingResponse> fut = bookingService.bookAsync(req);
            fut.whenComplete((resp, ex) -> {
                if (ex != null) {
                    sendError("Eroare booking: " + ex.getMessage());
                } else {
                    sendBookingResponse(resp);
                }
            });

        } catch (Exception e) {
            sendError("BOOK_REQUEST parse error: " + e.getMessage());
        }
    }

    private void handlePay(String[] p) {
        // PAY_REQUEST|bookingId|cnp|amount
        if (p.length < 4) {
            sendError("PAY_REQUEST invalid.");
            return;
        }
        try {
            long bookingId = Long.parseLong(p[1]);
            String cnp = p[2];
            int amount = Integer.parseInt(p[3]);

            boolean ok = bookingService.pay(new Messages.PaymentRequest(bookingId, cnp, amount));
            if (ok) {
                sendLine(Protocol.encode(
                        MsgType.BOOK_RESPONSE.name(),
                        String.valueOf(bookingId),
                        "true",
                        "Plata reusita."
                ));
            } else {
                sendLine(Protocol.encode(
                        MsgType.BOOK_RESPONSE.name(),
                        String.valueOf(bookingId),
                        "false",
                        "Plata nereusita."
                ));
            }
        } catch (Exception e) {
            sendError("PAY_REQUEST parse error: " + e.getMessage());
        }
    }

    private void handleCancel(String[] p) {
        // CANCEL_REQUEST|bookingId|cnp
        if (p.length < 3) {
            sendError("CANCEL_REQUEST invalid.");
            return;
        }
        try {
            long bookingId = Long.parseLong(p[1]);
            String cnp = p[2];

            boolean ok = bookingService.cancel(new Messages.CancelRequest(bookingId, cnp));
            if (ok) {
                sendLine(Protocol.encode(
                        MsgType.BOOK_RESPONSE.name(),
                        String.valueOf(bookingId),
                        "true",
                        "Anulare reusita."
                ));
            } else {
                sendLine(Protocol.encode(
                        MsgType.BOOK_RESPONSE.name(),
                        String.valueOf(bookingId),
                        "false",
                        "Anulare nereusita."
                ));
            }
        } catch (Exception e) {
            sendError("CANCEL_REQUEST parse error: " + e.getMessage());
        }
    }

    public void sendShutdownNotice(String msg) {
        sendLine(Protocol.encode(MsgType.SHUTDOWN_NOTICE.name(), msg));
    }

    private void sendBookingResponse(Messages.BookingResponse resp) {
        sendLine(Protocol.encode(
                MsgType.BOOK_RESPONSE.name(),
                String.valueOf(resp.bookingId()),
                String.valueOf(resp.success()),
                resp.message()
        ));
    }

    private void sendError(String msg) {
        sendLine(Protocol.encode(MsgType.ERROR.name(), msg));
    }

    private void sendLine(String line) {
        synchronized (out) {
            try {
                out.write(line);
                out.newLine();
                out.flush();
            } catch (IOException e) {
                running = false;
                close();
            }
        }
    }

    public void close() {
        running = false;
        try {
            socket.close();
        } catch (IOException ignored) {

        }

        try {
            in.close();
        } catch (IOException ignored) {

        }

        try {
            out.close();
        } catch (IOException ignored) {

        }
    }
}
