package ro.clinica.common;

import java.time.LocalTime;

public final class TimeUtil {

    public static final LocalTime OPEN = LocalTime.of(10, 0);
    public static final LocalTime CLOSE = LocalTime.of(18, 0);

    private TimeUtil() {}

    public static boolean inProgram(LocalTime start, int durationMin) {
        LocalTime end = start.plusMinutes(durationMin);
        return !start.isBefore(OPEN) && !end.isAfter(CLOSE);
    }

    public static boolean overlap(LocalTime s1, int d1, LocalTime s2, int d2) {
        LocalTime e1 = s1.plusMinutes(d1);
        LocalTime e2 = s2.plusMinutes(d2);
        return !s1.isAfter(e2) && !s2.isAfter(e1);
    }
}
