package ro.clinica.common;

import java.util.StringJoiner;

public final class Protocol {

    private static final String SEP = "|";

    private Protocol() {}

    public static String encode(String... parts) {
        StringJoiner joiner = new StringJoiner(SEP);
        for (String p : parts) {
            joiner.add(p == null ? "" : p);
        }
        return joiner.toString();
    }

    public static String[] decode(String line) {
        return line.split("\\|", -1);
    }
}
