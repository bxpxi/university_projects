package ro.clinica.common;

import java.util.concurrent.atomic.AtomicLong;

public final class Ids {

    private static final AtomicLong SEQ = new AtomicLong(1);

    private Ids() {}

    public static long next() {
        return SEQ.getAndIncrement();
    }
}
