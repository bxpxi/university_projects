package ro.clinica.common;

public enum MsgType {
    BOOK_REQUEST,
    BOOK_RESPONSE,
    PAY_REQUEST,
    CANCEL_REQUEST,
    SHUTDOWN_NOTICE,
    ERROR
}
