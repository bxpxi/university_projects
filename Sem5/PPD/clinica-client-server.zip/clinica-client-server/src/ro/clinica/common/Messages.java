package ro.clinica.common;

import java.time.LocalDate;
import java.time.LocalTime;

public final class Messages {

    public static record BookingRequest(
            long id,
            String name,
            String cnp,
            int location,
            int treatment,
            LocalDate date,
            LocalTime time
    ) {}

    public static record BookingResponse(
            long bookingId,
            boolean success,
            String message
    ) {}

    public static record PaymentRequest(
            long bookingId,
            String cnp,
            int amount
    ) {}

    public static record CancelRequest(
            long bookingId,
            String cnp
    ) {}

    public static record ShutdownNotice(
            String message
    ) {}

    private Messages() {}
}
