package ro.clinica;

public class Main {
}
