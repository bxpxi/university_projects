#!/bin/bash
set -e

echo "Compiling..."
mkdir -p bin
javac -d bin src/GenData.java src/Convolutie.java

OUTCSV="rezultate.csv"
echo "TipMatrice,NrThreads,ModDistribuire,TimpExecutie" > $OUTCSV

echo "Generate date.txt..."
java -cp bin GenData

configs=(
  "10 10 3 4"
  "1000 1000 5 2 4 8 16"
  "10 10000 5 2 4 8 16"
  "10000 10 5 2 4 8 16"
  "10000 10000 5 2 4 8 16"
)

modes=("seq" "horiz" "vert" "block" "delta_lin" "delta_cyc")

for cfg in "${configs[@]}"; do
  set -- $cfg
  N=$1; M=$2; K=$3; shift 3
  PTHREADS=("$@")
  echo "== Config $N x $M kernel=$K"

  for p in "${PTHREADS[@]}"; do
    for mode in "${modes[@]}"; do
      echo "Running $N x $M p=$p mode=$mode..."
      TIME=$(java -Xmx4g -cp bin Convolutie $mode $p 10 date.txt output.txt $N $M $K)
      echo "${N}x${M},$p,$mode,$TIME" >> $OUTCSV
    done
  done
done

echo "Results in $OUTCSV"
