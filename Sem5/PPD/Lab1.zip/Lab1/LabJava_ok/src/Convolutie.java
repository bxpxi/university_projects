import java.io.*;
import java.util.*;

public class Convolutie {
    // virtual boarding
    static int clamp(int x, int lim) {
        if (x < 0) return 0;
        if (x >= lim) return lim - 1;
        return x;
    }

    // convulation for a single cell by using the given formula + virtual boarding of the matrix
    static int convCell(int[][] F, int[][] C, int i, int j) {
        int k = C.length;
        int half = k / 2;
        long s = 0;
        for (int di = -half; di <= half; di++)
            for (int dj = -half; dj <= half; dj++)
                s += 1L * F[clamp(i + di, F.length)][clamp(j + dj, F[0].length)] * C[di + half][dj + half]; // long long to prevent temporary overfitting
        return (int)s;
    }

    // sequential
    static void seq(int[][] F, int[][] C, int[][] V) {
        for (int i = 0; i < F.length; i++)
            for (int j = 0; j < F[0].length; j++)
                V[i][j] = convCell(F, C, i, j);
    }

    // check if two matrices are equal
    static boolean equal(int[][] A, int[][] B) {
        if (A.length != B.length || A[0].length != B[0].length) return false;
        for (int i = 0; i < A.length; i++)
            for (int j = 0; j < A[0].length; j++)
                if (A[i][j] != B[i][j]) return false;
        return true;
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 8) {
            System.err.println("Usage: java Convolutie mode p repeat input output N M K");
            return;
        }

        // read the arguments
        String mode = args[0];
        int p = Integer.parseInt(args[1]);
        int repeat = Integer.parseInt(args[2]);
        String input = args[3];
        String output = args[4];
        int n = Integer.parseInt(args[5]);
        int m = Integer.parseInt(args[6]);
        int k = Integer.parseInt(args[7]);

        // read the input data from the file (dimensions + matrix + kernel)
        Scanner sc = new Scanner(new File(input));
        int nmax = sc.nextInt();
        int mmax = sc.nextInt();
        int kmax = sc.nextInt();

        int[][] Ffull = new int[nmax][mmax];
        for (int i = 0; i < nmax; i++)
            for (int j = 0; j < mmax; j++)
                Ffull[i][j] = sc.nextInt();

        int[][] Cfull = new int[kmax][kmax];
        for (int i = 0; i < kmax; i++)
            for (int j = 0; j < kmax; j++)
                Cfull[i][j] = sc.nextInt();
        sc.close();

        // we read everything from the file but we keep only as much as we need from both the matrix and the kernel
        int[][] F = new int[n][m];
        for (int i = 0; i < n; i++)
            System.arraycopy(Ffull[i], 0, F[i], 0, m);

        int[][] C = new int[k][k];
        for (int i = 0; i < k; i++)
            System.arraycopy(Cfull[i], 0, C[i], 0, k);

        int[][] V = new int[n][m]; // result matrix
        int[][] Gold = new int[n][m]; // golden reference; result from the sequential running
        seq(F, C, Gold);

        // parallel
        double total = 0.0;
        for (int r = 0; r < repeat; r++) {
            // initialize the result matrix
            for (int i = 0; i < n; i++)
                Arrays.fill(V[i], 0);

            long t0 = System.nanoTime();

            Thread[] threads = new Thread[p];

            if (mode.equals("seq") || p <= 1) {
                seq(F, C, V);
            } else if (mode.equals("horiz")) {
                int base = n / p;
                int remaining = n % p;
                int curr = 0;
                for (int t = 0; t < p; t++) {
                    int start = curr;
                    int add = t < remaining ? 1 : 0;
                    int end = start + base + add;
                    curr = end;
                    threads[t] = new Thread(() -> {
                        for (int i = start; i < end; i++)
                            for (int j = 0; j < m; j++)
                                V[i][j] = convCell(F, C, i, j);
                    });
                    threads[t].start();
                }
            } else if (mode.equals("vert")) {
                int base = m / p;
                int remaining = m % p;
                int curr = 0;
                for (int t = 0; t < p; t++) {
                    int start = curr;
                    int add = t < remaining ? 1 : 0;
                    int end = start + base + add;
                    curr = end;
                    threads[t] = new Thread(() -> {
                        for (int i = 0; i < n; i++)
                            for (int j = start; j < end; j++)
                                V[i][j] = convCell(F, C, i, j);
                    });
                    threads[t].start();
                }
            } else if (mode.equals("block")) {
                int rcount = (int)Math.floor(Math.sqrt(p));
                if (rcount <= 0) rcount = 1;
                while (rcount > 1 && p % rcount != 0) rcount--;
                int ccount = (p + rcount - 1) / rcount;

                int[] rcuts = new int[rcount + 1];
                int[] ccuts = new int[ccount + 1];
                for (int i = 0; i <= rcount; i++)
                    rcuts[i] = i * n / rcount;
                for (int j = 0; j <= ccount; j++)
                    ccuts[j] = j * m / ccount;

                int assigned = 0;
                for (int i = 0; i < rcount && assigned < p; i++)
                    for (int j = 0; j < ccount && assigned < p; j++, assigned++) {
                        int r0 = rcuts[i], r1 = rcuts[i+1], c0 = ccuts[j], c1 = ccuts[j+1];
                        threads[assigned] = new Thread(() -> {
                            for (int ii = r0; ii < r1; ii++)
                                for (int jj = c0; jj < c1; jj++)
                                    V[ii][jj] = convCell(F, C, ii, jj);
                        });
                        threads[assigned].start();
                    }
            } else if (mode.equals("delta_lin")) {
                long NM = 1L * n * m;
                for (int t = 0; t < p; t++) {
                    final int tid = t;
                    threads[t] = new Thread(() -> {
                        long start = (NM * tid) / p;
                        long end = (NM * (tid+1)) / p;
                        for (long idx = start; idx < end; idx++) {
                            int i = (int)(idx / m);
                            int j = (int)(idx % m);
                            V[i][j] = convCell(F, C, i, j);
                        }
                    });
                    threads[t].start();
                }
            } else if (mode.equals("delta_cyc")) {
                long NM = 1L * n * m;
                for (int t = 0; t < p; t++) {
                    final int tid = t;
                    threads[t] = new Thread(() -> {
                        for (long idx = tid; idx < NM; idx += p) {
                            int i = (int)(idx / m);
                            int j = (int)(idx % m);
                            V[i][j] = convCell(F, C, i, j);
                        }
                    });
                    threads[t].start();
                }
            } else {
                // default
                int base = n / p;
                int remaining = n % p;
                int curr = 0;
                for (int t = 0; t < p; t++) {
                    int start = curr;
                    int add = t < remaining ? 1 : 0;
                    int end = start + base + add;
                    curr = end;
                    threads[t] = new Thread(() -> {
                        for (int i = start; i < end; i++)
                            for (int j = 0; j < m; j++)
                                V[i][j] = convCell(F, C, i, j);
                    });
                    threads[t].start();
                }
            }

            // join threads
            for (int t = 0; t < p; t++)
                if (threads[t] != null) threads[t].join();

            long t1 = System.nanoTime();
            total += (t1 - t0)/1e9;
        }

        // check if it's equal to the golden reference
        if (!equal(V, Gold)) {
            System.err.println("Mismatch between parallel and sequential results! Aborting!");
            System.exit(1);
        }

        // write output to the file
        try (PrintWriter out = new PrintWriter(new FileWriter(output))) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    out.print(V[i][j]);
                    if (j + 1 < m) out.print(" ");
                }
                out.println();
            }
        }

        // print the average time
        System.out.printf("%.6f\n", total / repeat);
    }
}
