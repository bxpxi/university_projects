import java.io.*;
import java.util.*;

public class GenData {
    public static void main(String[] args) throws Exception {
        int n = 10000, m = 10000, k = 5;

        Random rng = new Random(12345); // seed for reproductibility
        try (PrintWriter out = new PrintWriter(new FileWriter("date.txt"))) {
            // write matrix and kernel dimensions
            out.println(n + " " + m + " " + k);
            // write the matrix - generated random numbers
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    out.print(rng.nextInt(256)); // pixel values - 0-255
                    if (j + 1 < m)
                        out.print(" ");
                }
                out.println();
            }
            // write the kernel
            for (int i = 0; i < k; i++) {
                for (int j = 0; j < k; j++) {
                    out.print(rng.nextInt(3) - 1); // -1,0,1 values
                    if (j + 1 < k)
                        out.print(" ");
                }
                out.println();
            }
        }
        System.err.printf("date.txt for %dx%d with kernel %d\n", n, m, k);
    }
}
