#!/bin/bash
set -e

echo "Compilare..."
g++ -std=c++11 -O2 gen_data.cpp -o gen_data
g++ -std=c++11 -O2 convolutie.cpp -o convolutie -pthread

OUTCSV="rezultate.csv"
echo "TipMatrice,TipAlocare,NrThreads,ModDistribuire,TimpExecutie" > $OUTCSV

configs=(
  "10 10 3 4"
  "1000 1000 5 2 4 8 16"
  "10 10000 5 2 4 8 16"
  "10000 10 5 2 4 8 16"
  "10000 10000 5 2 4 8 16"
)

modes=("seq" "horiz" "vert" "block" "delta_lin" "delta_cyc")
allocs=("dyn" "static")

for cfg in "${configs[@]}"; do
  set -- $cfg
  N=$1; M=$2; K=$3; shift 3
  PTHREADS=("$@")
  ./gen_data $N $M $K

  for alloc in "${allocs[@]}"; do
    for p in "${PTHREADS[@]}"; do
      for mode in "${modes[@]}"; do
        echo "Running $N x $M kernel=$K alloc=$alloc p=$p mode=$mode..."
        TIME=$(./convolutie $alloc $mode $p 10 date.txt output.txt)
        echo "${N}x${M},$alloc,$p,$mode,$TIME" >> $OUTCSV
      done
    done
  done
done

echo "Results in $OUTCSV"
