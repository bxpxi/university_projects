#include <bits/stdc++.h>
using namespace std;

// for the csv file
struct Entry {
    string dim;
    string alloc;
    int p;
    string mode;
    double time;
};

int main() {
    // for speed
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    vector<tuple<int,int,int,vector<int>>> configs = {
        {10,10,3, {4}},
        {1000,1000,5, {2,4,8,16}},
        {10,10000,5, {2,4,8,16}},
        {10000,10,5, {2,4,8,16}},
        {10000,10000,5, {2,4,8,16}}
    };

    vector<string> modes = {"seq","horiz","vert","block","delta_lin","delta_cyc"};
    vector<string> allocs = {"dyn","static"};

    vector<Entry> results;

    // run all configurations
    for (auto &cfg : configs) {
        int n, m, k; vector<int> ps;
        tie(n, m, k, ps) = cfg;
        cerr << "=== Config " << n << "x" << m << " k=" << k << "\n";

        // generate date.txt
        {
            ofstream fout("date.txt");
            fout << n << " " << m << " " << k << "\n";
            // fixed seed so all runs use same file
            std::mt19937 rng(12345);
            uniform_int_distribution<int> pix(0,255);
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < m; ++j) {
                    fout << pix(rng);
                    if (j+1 < m) fout << " ";
                }
                fout << "\n";
            }
            // kernel small values
            uniform_int_distribution<int> kval(-1,1);
            for (int i = 0; i < k; ++i) {
                for (int j = 0; j < k; ++j) {
                    fout << kval(rng);
                    if (j+1 < k) fout << " ";
                }
                fout << "\n";
            }
            fout.close();
        }

        for (string alloc : allocs) {
            for (int p : ps) {
                for (string mode : modes) {
                    // call convolutie
                    string cmd = "./convolutie " + alloc + " " + mode + " " + to_string(p) + " 10 date.txt output.txt";
                    // Use popen to capture stdout (time)
                    FILE *pipe = popen(cmd.c_str(), "r");
                    if (!pipe) {
                        cerr << "Failed to run command: " << cmd << "\n";
                        // record failure as -1
                        results.push_back({to_string(n)+"x"+to_string(m), alloc, p, mode, -1.0});
                        continue;
                    }
                    double t;
                    int ret = fscanf(pipe, "%lf", &t);
                    int rc = pclose(pipe);
                    if (ret != 1) {
                        cerr << "Failed to get time for: " << cmd << " (rc="<<rc<<")\n";
                        results.push_back({to_string(n)+"x"+to_string(m), alloc, p, mode, -1.0});
                        continue;
                    }
                    cerr << "OK: " << n << "x" << m << " alloc=" << alloc << " p=" << p << " mode=" << mode << " time=" << t << "s\n";
                    results.push_back({to_string(n)+"x"+to_string(m), alloc, p, mode, t});
                }
            }
        }
    }

    // write CSV
    ofstream csv("rezultate.csv");
    csv << "TipMatrice,TipAlocare,NrThreads,ModDistribuire,TimpExecutie\n";
    for (auto &e : results) {
        csv << e.dim << "," << e.alloc << "," << e.p << "," << e.mode << "," << e.time << "\n";
    }
    csv.close();
    cerr << "Wrote rezultate.csv\n";
    return 0;
}
