#include <bits/stdc++.h>
#include <thread>
#include <chrono>
using namespace std;
using hr_clock = chrono::high_resolution_clock;

#ifndef MAX
#define MAX 10000
#endif

// static allocation
static int F_static[MAX][MAX]; // input matrix
static int V_static[MAX][MAX]; // result matrix
static int C_static[51][51]; // kernel

// useful for virtual boarding of the matrix; elements are equal to the elements from the first/last line/column
inline int clamp_idx(int x, int lim) {
    if (x < 0) return 0;
    if (x >= lim) return lim - 1;
    return x;
}

// wrapper class for dynamic allocation
// I used it in order to be able to access the dimensions directly, without calling size() every time
struct DynM2 {
    int n=0, m=0;
    vector<vector<int>> a;
    void init(int n_, int m_) { n = n_; m = m_; a.assign(n, vector<int>(m)); }
};

// wrapper class for dynamic allocation using new/delete
struct DynM {
    int n=0, m=0;
    int **a = nullptr;

    void init(int n_, int m_) {
        n = n_; m = m_;
        a = new int*[n];
        for(int i = 0; i < n; ++i)
            a[i] = new int[m];
    }

    void free() {
        if(a) {
            for(int i = 0; i < n; ++i) delete[] a[i];
            delete[] a;
            a = nullptr;
        }
    }

    ~DynM() { free(); }
};


// apply convulation for one cell by using the given formula and taking into account the virtual boarding of the matrix
inline int conv_cell_stat(int n, int m, int k, int i, int j) {
    int half = k/2;
    long long s = 0;
    for (int di = -half; di <= half; ++di)
        for (int dj = -half; dj <= half; ++dj) {
            int ii = clamp_idx(i + di, n);
            int jj = clamp_idx(j + dj, m);
            s += 1LL * F_static[ii][jj] * C_static[di + half][dj + half]; // temporary transform into long long to prevent overflow
        }
    return (int)s;
}

// the same thing as above, but for dynamic allocation
inline int conv_cell_dyn(const DynM &F, const DynM &C, int i, int j) {
    int k = C.n;
    int half = k/2;
    long long s = 0;
    for (int di = -half; di <= half; ++di)
        for (int dj = -half; dj <= half; ++dj) {
            int ii = clamp_idx(i + di, F.n);
            int jj = clamp_idx(j + dj, F.m);
            s += 1LL * F.a[ii][jj] * C.a[di + half][dj + half];
        }
    return (int)s;
}

// sequential for static allocation
void seq_stat(int n, int m, int k) {
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < m; ++j)
            V_static[i][j] = conv_cell_stat(n, m, k, i, j);
}

// sequential for dynamic allocation
void seq_dyn(const DynM &F, const DynM &C, DynM &V) {
    for (int i = 0; i < F.n; ++i)
        for (int j = 0; j < F.m; ++j)
            V.a[i][j] = conv_cell_dyn(F, C, i, j);
}

// horizontal for static allocation
void worker_horiz_stat(int n, int m, int k, int r0, int r1) {
    for (int i = r0; i < r1; ++i)
        for (int j = 0; j < m; ++j)
            V_static[i][j] = conv_cell_stat(n, m, k, i, j);
}

// horizontal for dynamic allocation
void worker_horiz_dyn(const DynM &F, const DynM &C, DynM &V, int r0, int r1) {
    for (int i = r0; i < r1; ++i)
        for (int j = 0; j < F.m; ++j)
            V.a[i][j] = conv_cell_dyn(F, C, i, j);
}

// vertical for static allocation
void worker_vert_stat(int n, int m, int k, int c0, int c1) {
    for (int i = 0; i < n; ++i)
        for (int j = c0; j < c1; ++j)
            V_static[i][j] = conv_cell_stat(n, m, k, i, j);
}

// vertical for dynamic allocation
void worker_vert_dyn(const DynM &F, const DynM &C, DynM &V, int c0, int c1) {
    for (int i = 0; i < F.n; ++i)
        for (int j = c0; j < c1; ++j)
            V.a[i][j] = conv_cell_dyn(F, C, i, j);
}

// structure for the block approach - start and final row/column
struct Block { int r0, r1, c0, c1; };

// blocks for static allocation
void worker_block_stat(int n, int m, int k, Block b) {
    for (int i = b.r0; i < b.r1; ++i)
        for (int j = b.c0; j < b.c1; ++j)
            V_static[i][j] = conv_cell_stat(n, m, k, i, j);
}

// blocks for dynamic allocation
void worker_block_dyn(const DynM &F, const DynM &C, DynM &V, Block b) {
    for (int i = b.r0; i < b.r1; ++i)
        for (int j = b.c0; j < b.c1; ++j)
            V.a[i][j] = conv_cell_dyn(F, C, i, j);
}

// delta linear function for static allocation
void worker_delta_lin_stat(int n, int m, int k, int t, int p) {
    long long NM = 1LL * n * m; // total number of pixels (elements of the matrix); convert to long long to prevent temporary overflow
    // p - number of threads
    // t - index of current thread
    long long start = (NM * t) / p;
    long long end = (NM * (t + 1)) / p;
    for (long long idx = start; idx < end; ++idx) {
        int i = idx / m;
        int j = idx % m;
        V_static[i][j] = conv_cell_stat(n, m, k, i, j);
    }
}

// delta linear function for dynamic allocation
void worker_delta_lin_dyn(const DynM &F, const DynM &C, DynM &V, int t, int p) {
    long long NM = 1LL * F.n * F.m;
    long long start = (NM * t) / p;
    long long end = (NM * (t + 1)) / p;
    for (long long idx = start; idx < end; ++idx) {
        int i = idx / F.m;
        int j = idx % F.m;
        V.a[i][j] = conv_cell_dyn(F, C, i, j);
    }
}

// delta cyclic function for static allocation
void worker_delta_cyc_stat(int n, int m, int k, int t, int p) {
    long long NM = 1LL * n * m; // total number of pixels (elements of the matrix); converted to long long to prevent temporary overflow
    // t - index of the current thread
    // p - pace/stride
    for (long long idx = t; idx < NM; idx += p) {
        int i = idx / m;
        int j = idx % m;
        V_static[i][j] = conv_cell_stat(n, m, k, i, j);
    }
}

// delta cyclic function for dynamic allocation
void worker_delta_cyc_dyn(const DynM &F, const DynM &C, DynM &V, int t, int p) {
    long long NM = 1LL * F.n * F.m;
    for (long long idx = t; idx < NM; idx += p) {
        int i = idx / F.m;
        int j = idx % F.m;
        V.a[i][j] = conv_cell_dyn(F, C, i, j);
    }
}

// check if two matrices are equal (both are dynamically allocated)
bool equal_dyn(const DynM &A, const DynM &B) {
    if (A.n != B.n || A.m != B.m) return false;
    for (int i = 0; i < A.n; ++i)
        for (int j = 0; j < A.m; ++j)
            if (A.a[i][j] != B.a[i][j]) return false;
    return true;
}

// check if two matrices are equal (one is statically and one is dynamically allocated)
bool equal_dyn_stat(const DynM &A, int n, int m) {
    if (A.n != n || A.m != m) return false;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < m; ++j)
            if (A.a[i][j] != V_static[i][j]) return false;
    return true;
}

// run for one configuration for static allocation
double run_static(int n, int m, int k, const string &mode, int p, int repeat) {
    // sequential
    if (mode == "seq" || p <= 1) {
        auto t0 = hr_clock::now();
        seq_stat(n, m, k);
        auto t1 = hr_clock::now();
        return chrono::duration<double>(t1 - t0).count();
    }

    // paralell
    vector<double> times;
    times.reserve(repeat);

    // run repeat times
    for (int r = 0; r < repeat; ++r) {
        // initialize the result matrix
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < m; ++j)
                V_static[i][j] = 0;

        auto t0 = hr_clock::now();
        vector<thread> th;
        if (mode == "horiz") {
            int base = n / p;
            int remaining = n % p;
            int curr = 0;
            for (int t = 0; t < p; ++t) {
                int start = curr;
                int add = (t < remaining) ? 1 : 0;
                int end = start + base + add;
                curr = end;
                th.emplace_back(worker_horiz_stat, n, m, k, start, end);
            }
        } else if (mode == "vert") {
            int base = m / p;
            int remaining = m % p;
            int curr = 0;
            for (int t = 0; t < p; ++t) {
                int start = curr;
                int add = (t < remaining) ? 1 : 0;
                int end = start + base + add; curr = end;
                th.emplace_back(worker_vert_stat, n, m, k, start, end);
            }
        } else if (mode == "block") {
            int rcount = floor(sqrt((double)p)); // blocks per row; used sqrt to obtain blocks that are squares or closer to squares
            if (rcount <= 0)
                rcount = 1;
            while (rcount > 1 && p % rcount != 0)
                --rcount;
            int ccount = (p + rcount - 1) / rcount; // blocks per column

            vector<int> rcuts(rcount+1), ccuts(ccount+1); // starting row/column for the blocks
            for (int i = 0; i <= rcount; ++i)
                rcuts[i] = (i * n) / rcount;
            for (int j = 0; j <= ccount; ++j)
                ccuts[j] = (j * m) / ccount;

            int assigned = 0;
            for (int i = 0; i < rcount; ++i) {
                for (int j = 0; j < ccount; ++j) {
                    if (assigned >= p)
                        break;
                    Block b{rcuts[i], rcuts[i+1], ccuts[j], ccuts[j+1]};
                    th.emplace_back(worker_block_stat, n, m, k, b);
                    ++assigned;
                }
                // no more blocks than threads
                if (assigned >= p)
                    break;
            }
            // empty threads if there weren't enough blocks
            while ((int)th.size() < p)
                th.emplace_back([](){});
        } else if (mode == "delta_lin") {
            for (int t = 0; t < p; ++t)
                th.emplace_back(worker_delta_lin_stat, n, m, k, t, p);
        } else if (mode == "delta_cyc") {
            for (int t = 0; t < p; ++t)
                th.emplace_back(worker_delta_cyc_stat, n, m, k, t, p);
        } else {
            // default
            int base = n / p;
            int remaining = n % p;
            int curr = 0;
            for (int t = 0; t < p; ++t) {
                int start = curr;
                int add = (t < remaining) ? 1 : 0;
                int end = start + base + add;
                curr = end;
                th.emplace_back(worker_horiz_stat, n, m, k, start, end);
            }
        }

        // join for threads
        for (auto &t : th)
            if (t.joinable())
                t.join();

        auto t1 = hr_clock::now();
        times.push_back(chrono::duration<double>(t1 - t0).count());
    }

    // average time
    double s = 0;
    for (double x : times)
        s += x;
    return s / times.size();
}


// run for one configuration for dynamic allocation
double run_dynamic(const DynM &F, const DynM &C, DynM &V, const string &mode, int p, int repeat) {
    if (mode == "seq" || p <= 1) {
        auto t0 = hr_clock::now();
        seq_dyn(F, C, V);
        auto t1 = hr_clock::now();
        return chrono::duration<double>(t1 - t0).count();
    }

    vector<double> times;
    times.reserve(repeat);

    for (int r = 0; r < repeat; ++r) {
        for (int i = 0; i < V.n; ++i)
            fill(V.a[i].begin(), V.a[i].end(), 0);

        auto t0 = hr_clock::now();
        vector<thread> th;

        if (mode == "horiz") {
            int base = F.n / p;
            int remaining = F.n % p;
            int curr = 0;
            for (int t = 0; t < p; ++t) {
                int start = curr;
                int add = (t < remaining) ? 1 : 0;
                int end = start + base + add;
                curr = end;
                th.emplace_back(worker_horiz_dyn, cref(F), cref(C), ref(V), start, end);
            }
        } else if (mode == "vert") {
            int base = F.m / p;
            int remaining = F.m % p;
            int curr = 0;
            for (int t = 0; t < p; ++t) {
                int start = curr;
                int add = (t < remaining) ? 1 : 0;
                int end = start + base + add;
                curr = end;
                th.emplace_back(worker_vert_dyn, cref(F), cref(C), ref(V), start, end);
            }
        } else if (mode == "block") {
            int rcount = floor(sqrt((double)p));
            if (rcount <= 0)
                rcount = 1;
            while (rcount > 1 && p % rcount != 0)
                --rcount;
            int ccount = (p + rcount - 1) / rcount;

            vector<int> rcuts(rcount+1), ccuts(ccount+1);
            for (int i = 0; i <= rcount; ++i)
                rcuts[i] = (i * F.n) / rcount;
            for (int j = 0; j <= ccount; ++j)
                ccuts[j] = (j * F.m) / ccount;

            int assigned = 0;
            for (int i = 0; i < rcount; ++i) {
                for (int j = 0; j < ccount; ++j) {
                    if (assigned >= p) break;
                    Block b{rcuts[i], rcuts[i+1], ccuts[j], ccuts[j+1]};
                    th.emplace_back(worker_block_dyn, cref(F), cref(C), ref(V), b);
                    ++assigned;
                }
                if (assigned >= p)
                    break;
            }

            while ((int)th.size() < p)
                th.emplace_back([](){});
        } else if (mode == "delta_lin") {
            for (int t = 0; t < p; ++t)
                th.emplace_back(worker_delta_lin_dyn, cref(F), cref(C), ref(V), t, p);
        } else if (mode == "delta_cyc") {
            for (int t = 0; t < p; ++t)
                th.emplace_back(worker_delta_cyc_dyn, cref(F), cref(C), ref(V), t, p);
        } else {
            // default
            int base = F.n / p;
            int remaining = F.n % p;
            int curr = 0;
            for (int t = 0; t < p; ++t) {
                int start = curr;
                int add = (t < remaining) ? 1 : 0;
                int end = start + base + add; curr = end;
                th.emplace_back(worker_horiz_dyn, cref(F), cref(C), ref(V), start, end);
            }
        }

        for (auto &t : th)
            if (t.joinable())
                t.join();

        auto t1 = hr_clock::now();
        times.push_back(chrono::duration<double>(t1 - t0).count());
    }

    double s = 0;
    for (double x : times)
        s += x;
    return s / times.size();
}

// read input from the file for static allocation
bool read_input_static(const string &fname, int &n, int &m, int &k) {
    ifstream fin(fname);
    if (!fin)
        return false;

    // read the dimensions
    fin >> n >> m >> k;
    // read the matrix
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < m; ++j)
            fin >> F_static[i][j];
    // read the kernel
    for (int i = 0; i < k; ++i)
        for (int j = 0; j < k; ++j)
            fin >> C_static[i][j];

    fin.close();
    return true;
}

// read input from the file for dynamic allocation
bool read_input_dynamic(const string &fname, DynM &F, DynM &C) {
    ifstream fin(fname);
    if (!fin)
        return false;

    // read the dimensions and initialize the dynamically allocated matrices
    int n, m, k;
    fin >> n >> m >> k;
    F.init(n, m);
    C.init(k, k);
    // read the matrix
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < m; ++j)
            fin >> F.a[i][j];
    // read the kernel
    for (int i = 0; i < k; ++i)
        for (int j = 0; j < k; ++j)
            fin >> C.a[i][j];

    fin.close();
    return true;
}

// write output to file for static allocation
bool write_output_static(const string &fname, int n, int m) {
    ofstream fout(fname);
    if (!fout)
        return false;

    // write the result matrix
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            fout << V_static[i][j];
            if (j + 1 < m)
                fout << ' ';
        }
        fout << '\n';
    }
    fout.close();
    return true;
}

// write output to file for dynamic allocation
bool write_output_dynamic(const string &fname, const DynM &V) {
    ofstream fout(fname);
    if (!fout)
        return false;

    // write the result matrix
    for (int i = 0; i < V.n; ++i) {
        for (int j = 0; j < V.m; ++j) {
            fout << V.a[i][j];
            if (j + 1 < V.m)
                fout << ' ';
        }
        fout << '\n';
    }
    fout.close();
    return true;
}

// main method
int main(int argc, char** argv) {
    // for speed
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    if (argc != 7) {
        cerr << "Usage: ./convolutie alloc[static|dyn] mode[seq|horiz|vert|block|delta_lin|delta_cyc] p repeat input output\n";
        return 1;
    }

    // read the arguments
    string alloc = argv[1];
    string mode = argv[2];
    int p = stoi(argv[3]);
    int repeat = stoi(argv[4]);
    string input = argv[5];
    string output = argv[6];

    if (alloc == "dyn") {
        DynM F, C, V, Gold;

        // handle different type of errors
        if (!read_input_dynamic(input, F, C)) {
            cerr << "Cannot read " << input << "\n";
            return 2;
        }

        if (C.n % 2 == 0) {
            cerr << "Kernel k must be odd\n";
            return 3;
        }

        V.init(F.n, F.m);
        Gold.init(F.n, F.m); // golden reference; the result from sequential running
        seq_dyn(F, C, Gold);

        // parallel running
        double avg = run_dynamic(F, C, V, mode, p, repeat);
        // check if it's equal to golden
        if (!equal_dyn(V, Gold)) {
            cerr << "Mismatch between parallel and sequential results (dynamic)! Aborting!\n";
            return 4;
        }

        // write output
        if (!write_output_dynamic(output, V)) {
            cerr << "Cannot write " << output << "\n";
            return 5;
        }

        // print average time
        cout.setf(std::ios::fixed);
        cout<<setprecision(6)<<avg<<"\n";
        return 0;
    } else if (alloc == "static") {
        int n, m, k;
        if (!read_input_static(input, n, m, k)) {
            cerr << "Cannot read " << input << "\n";
            return 2;
        }

        if (k % 2 == 0) {
            cerr << "Kernel k must be odd\n";
            return 3;
        }

        // golden reference - the result of sequential running
        seq_stat(n, m, k);
        // copy golden into a temporary dynamic matrix
        DynM Gold;
        Gold.init(n, m);
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < m; ++j)
                Gold.a[i][j] = V_static[i][j];

        // run parallel
        double avg = run_static(n, m, k, mode, p, repeat);

        // check if it's equal to the golden reference
        if (!equal_dyn_stat(Gold, n, m)) {
            cerr << "Mismatch between parallel and sequential results (static)! Aborting!\n";
            return 4;
        }

        // write output
        if (!write_output_static(output, n, m)) {
            cerr << "Cannot write " << output << "\n";
            return 5;
        }

        // print average time
        cout.setf(std::ios::fixed);
        cout<<setprecision(6)<<avg<<"\n";

        return 0;
    } else {
        cerr << "alloc must be 'static' or 'dyn'\n";
        return 1;
    }
}
