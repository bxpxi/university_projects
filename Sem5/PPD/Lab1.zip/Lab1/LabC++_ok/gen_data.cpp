#include <bits/stdc++.h>
using namespace std;

int main(int argc,char**argv){
    // args needed: matrix dimension (N, M), kernel dimension (K)
    if(argc<4){
        cerr<<"Usage: ./gen_data N M K\n";
        return 1;
    }

    // create the data file - the first line contains n, m, k and then the following lines contain the matrix and at the end the kernel
    int n=stoi(argv[1]), m=stoi(argv[2]), k=stoi(argv[3]);
    ofstream fout("date.txt");
    fout<<n<<" "<<m<<" "<<k<<"\n";

    // random 32-bit numbers, better than rand() because a sequence only repeats itself after 2^19937 - 1 numbers have been generated
    // we need so many numbers (N=10000, M=10000), that rand() will produce too many duplicates
    // used a seed for reproductibility
    mt19937 rng(12345);
    uniform_int_distribution<int> pix(0,255); // pixels from the matrix (N, M)
    uniform_int_distribution<int> ker(-1,1); // pixels from the kernel (K, K)

    // generate the matrix
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            fout<<pix(rng);
            if(j+1<m) fout<<" ";
        }
        fout<<"\n";
    }

    // generate the kernel
    for(int i=0;i<k;i++){
        for(int j=0;j<k;j++){
            fout<<ker(rng);
            if(j+1<k) fout<<" ";
        }
        fout<<"\n";
    }
    fout.close();
    cerr<<"date.txt generated for "<<n<<"x"<<m<<" with kernel "<<k<<"\n";
}
