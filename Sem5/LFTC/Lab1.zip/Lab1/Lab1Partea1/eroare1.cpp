#include<iostream>
using namespace std;

int main()
{
    while(int i=0;i<3;i++) // Nu respecta structura while. Are argumente de for, dar e while.
        cout<<i<<endl;
    return ;  // E functie ce returneaza un int, dar de fapt nu returneaza nimic.
}
