#include <iostream>
using namespace std;

void cerc() {
    float raza, perimetru, arie, PI = 3.14159;

    cout<<"Raza: ";
    cin>>raza;

    perimetru = 2 * PI * raza;
    cout<<"Perimetru = "<<perimetru<<"\n";

    arie = PI * raza * raza;
    cout<<"Arie = "<<arie<<"\n";
}

void cmmdc() {
    int a, b;
    cout<<"Primul numar: ";
    cin>>a;
    cout<<"Al doilea numar: ";
    cin>>b;

    while (a != b) {
        if (a > b) {
            a = a - b;
        } else {
            b = b - a;
        }
    }

    cout<<"Cmmdc = "<<a<<"\n";
}

void suma() {
    int n;
    cout<<"N= ";
    cin>>n;

    int suma = 0;
    while (n > 0) {
        int nr;
        cout<<"Numar: ";
        cin>>nr;

        suma = suma + nr;
        n--;
    }

    cout<<"Suma = "<<suma<<"\n";
}

void eroareMLP() {
    struct x{int a, b;}; // Nu e printre tipurile de date specificate (int, float, int_tuple). In C++ e valid.

    for(int i=5;i--;) // Lipseste partea de conditie la for. In C++ e valid.
        cout<<i<<endl;
}

int main() {
    cout<<"Selectati optiunea:\n 1.Calculati perimetrul si aria cercului\n 2. Calculati cmmdc\n 3.Calculati suma a n numere\n 4. Erori MLP\n";

    int optiune;
    cout<<"Optiunea: ";
    cin>>optiune;

    switch (optiune) {
        case 1:
            cerc();
            break;
        case 2:
            cmmdc();
            break;
        case 3:
            suma();
            break;
        case 4:
            eroareMLP();
            break;
    }

    return 0;
}