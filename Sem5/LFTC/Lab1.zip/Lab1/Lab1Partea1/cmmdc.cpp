#include <iostream>
using namespace std;

int main() {
    int a, b;
    cout<<"Primul numar: ";
    cin>>a;
    cout<<"Al doilea numar: ";
    cin>>b;

    while (a != b) {
        if (a > b) {
            a = a - b;
        } else {
            b = b - a;
        }
    }

    cout<<"Cmmdc = "<<a<<"\n";

    return 0;
}