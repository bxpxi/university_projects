#include <iostream>
using namespace std;

int main() {
    float raza, perimetru, arie, PI = 3.14159;

    cout<<"Raza: ";
    cin>>raza;

    perimetru = 2 * PI * raza;
    cout<<"Perimetru = "<<perimetru<<"\n";

    arie = PI * raza * raza;
    cout<<"Arie = "<<arie<<"\n";

    return 0;
}