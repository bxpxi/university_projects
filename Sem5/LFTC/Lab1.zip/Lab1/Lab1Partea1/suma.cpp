#include <iostream>
using namespace std;

int main() {
    int n;
    cout<<"N= ";
    cin>>n;

    int suma = 0;
    while (n > 0) {
        int nr;
        cout<<"Numar: ";
        cin>>nr;

        suma = suma + nr;
        n--;
    }

    cout<<"Suma = "<<suma<<"\n";

    return 0;
}