#include<iostream>
using namespace std;

int main()
{
    for(int i=5; ;i--) { // Lipseste partea de conditie la for. In C++ e valid.
        if (i <= 0)
            break; // nu exista break in MLP, in C++ exista
        cout<<i<<endl;
    }

    return 0;
}
