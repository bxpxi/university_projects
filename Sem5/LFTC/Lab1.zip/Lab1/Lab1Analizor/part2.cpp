#include <bits/stdc++.h>
using namespace std;

const unordered_set<string> keywords = {
    "int","float","float_array","cin","cout","if","else","while","for",
    "return","#include", "iostream","using","namespace","std","endl","main"
};

const unordered_set<string> operators = {
    "+","-","*","/","%","=","==","!=","<","<=",">",">=","<<",">>"
};

const unordered_set<char> single_separators = {
    ';',',','(',')','{','}','[',']', '<', '>'
};

struct LexError {
    int line, col;
    string message;
};

struct FIPEntry {
    string token_repr;
    int ts_pos; // pozitia in TS; daca nu apare in TS va fi egal cu 0
};

struct TS_Entry {
    string lexeme;
    string kind; // id sau const
    int index;
};

class SymbolTable {
    vector<TS_Entry> entries;
    unordered_map<string,int> lookup;
public:
    int insert(const string &lex, const string &kind) {
        string key = kind + "|" + lex;
        if(lookup.count(key)) return lookup[key];
        int idx = (int)entries.size() + 1;
        entries.push_back({lex, kind, idx});
        lookup[key] = idx;
        return idx;
    }

    void print() const {
        cout << "\n=== TABELA DE SIMBOLURI (TS) ===\n";
        for(auto &e : entries)
            cout << e.index << " | " << e.kind << " | " << e.lexeme << "\n";
    }
};

bool is_letter(char c){ return isalpha((unsigned char)c); }
bool is_digit(char c){ return isdigit((unsigned char)c); }
bool is_alnum_or_underscore(char c){ return isalnum((unsigned char)c) || c == '_'; }

bool valid_identifier(const string &s, string &reason) {
    if(s.empty()){ reason = "empty"; return false; }
    char first = s[0];
    if(!(first == '_' || (first >= 'a' && first <= 'z'))){
        reason = "must start with lowercase letter or underscore";
        return false;
    }
    for(char c : s){
        if(!(is_letter(c) || is_digit(c) || c == '_')){
            reason = "contains invalid character";
            return false;
        }
    }
    if(keywords.count(s)){
        reason = "is reserved keyword";
        return false;
    }
    return true;
}

bool valid_constant(const string &s) {
    if(s.empty()) return false;
    size_t i = 0;
    if(s[0] == '+' || s[0] == '-') i++;
    bool hasDigitsBefore = false;
    while(i < s.size() && is_digit(s[i])) { hasDigitsBefore = true; i++; }
    if(i < s.size() && s[i] == '.'){
        i++;
        bool hasDigitsAfter = false;
        while(i < s.size() && is_digit(s[i])) { hasDigitsAfter = true; i++; }
        if(!hasDigitsBefore && !hasDigitsAfter) return false;
    } else {
        if(!hasDigitsBefore) return false;
    }
    return i == s.size();
}

vector<LexError> errors;

vector<FIPEntry> analyze_file(const string &filename, SymbolTable &ts) {
    ifstream in(filename);
    if(!in.is_open()){
        cerr << "Cannot open file: " << filename << endl;
        exit(1);
    }

    vector<FIPEntry> fip;
    string line;
    int lineNo = 0;

    while(getline(in, line)){
        lineNo++;
        size_t i = 0;

        while(i < line.size()){
            if(isspace((unsigned char)line[i])) { i++; continue; }

            int col = (int)i + 1;
            char c = line[i];
            string s1(1,c);

            auto starts_with = [&](const string &pat){
                return (i + pat.size() <= line.size() && line.substr(i, pat.size()) == pat);
            };
            vector<string> multi_ops = {"<<",">>","<=",">=","==","!="};
            bool matched = false;
            for(auto &op : multi_ops){
                if(starts_with(op)){
                    fip.push_back({"OP:"+op,0});
                    i += op.size();
                    matched = true;
                    break;
                }
            }
            if(matched) continue;

            if(operators.count(s1)){
                fip.push_back({"OP:"+s1,0});
                i++;
                continue;
            }

            if(single_separators.count(c)){
                fip.push_back({"SEP:"+s1,0});
                i++;
                continue;
            }

            if(c == '#'){
                size_t j = i;
                while(j < line.size() && !isspace((unsigned char)line[j])) j++;
                string token = line.substr(i, j-i);
                fip.push_back({"KW:"+token,0});
                i = j;
                continue;
            }

            if(is_letter(c) || c == '_'){
                size_t j = i+1;
                while(j < line.size() && is_alnum_or_underscore(line[j])) j++;
                string lex = line.substr(i, j-i);
                if(keywords.count(lex)){
                    fip.push_back({"KW:"+lex,0});
                } else {
                    string reason;
                    if(!valid_identifier(lex, reason))
                        errors.push_back({lineNo,col,"Invalid identifier '"+lex+"': "+reason});
                    int pos = ts.insert(lex,"id");
                    fip.push_back({"ID",pos});
                }
                i = j;
                continue;
            }

            if(c == '+' || c == '-' || is_digit(c)){
                size_t j = i;
                if(line[j] == '+' || line[j] == '-') j++;
                while(j < line.size() && is_digit(line[j])) j++;
                if(j < line.size() && line[j] == '.'){
                    j++;
                    while(j < line.size() && is_digit(line[j])) j++;
                }
                string lex = line.substr(i, j-i);
                if(valid_constant(lex)){
                    int pos = ts.insert(lex,"const");
                    fip.push_back({"CONST",pos});
                } else {
                    errors.push_back({lineNo,col,"Malformed numeric constant '"+lex+"'"});
                }
                i = j;
                continue;
            }

            if(c == '"'){
                size_t j = i+1;
                bool closed=false;
                while(j < line.size()){
                    if(line[j] == '"'){ closed=true; break; }
                    j++;
                }
                if(!closed)
                    errors.push_back({lineNo,col,"Unclosed string literal"});
                else
                    errors.push_back({lineNo,col,"String literals not allowed in MLP"});
                i = closed ? j+1 : line.size();
                continue;
            }

            errors.push_back({lineNo,col,"Invalid character '"+string(1,c)+"'"});
            i++;
        }
    }

    return fip;
}

int main(int argc, char** argv) {
    if(argc < 2){
        cout << "Usage: " << argv[0] << " <source-file>\n";
        return 0;
    }

    string source = argv[1];
    SymbolTable ts;
    vector<FIPEntry> fip = analyze_file(source, ts);

    cout << "\n=== ATOMI LEXICALI ===\n";
    for(size_t i=0; i<fip.size(); i++){
        cout << i+1 << " | " << fip[i].token_repr;
        if(fip[i].ts_pos != 0) cout << " | TS poz: " << fip[i].ts_pos;
        cout << "\n";
    }

    ts.print();

    if(!errors.empty()){
        cout << "\n=== ERORI LEXICALE ===\n";
        for(auto &e : errors)
            cout << "Linia " << e.line << ", Col " << e.col << " : " << e.message << "\n";
    } else {
        cout << "\nNicio eroare lexicala\n";
    }

    return 0;
}
