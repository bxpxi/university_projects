#include <iostream>
using namespace std;

int main() {
    float raza, perimetru, arie, Pi = 3.14159;

    cin>>raza;

    perimetru = 2 * Pi * raza;
    cout<<perimetru<<endl;

    arie = Pi * raza * raza;
    cout<<arie<<endl;

    return 0;
}