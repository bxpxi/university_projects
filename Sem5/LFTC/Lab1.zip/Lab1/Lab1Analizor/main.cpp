#include <bits/stdc++.h>
using namespace std;

const unordered_set<string> keywords = {
    "int","float","float_array","cin","cout","if","else","while","for",
    "return","#include","iostream","using","namespace","std","endl","main"
};

const unordered_set<string> operators_set = {
    "+","-","*","/","%","=","==","!=","<","<=",">",">=","<<",">>"
};

const unordered_set<char> single_separators = {
    ';',',','(',')','{','}','[',']'
};

bool is_letter(char c){ return std::isalpha((unsigned char)c); }
bool is_digit(char c){ return std::isdigit((unsigned char)c); }
bool is_alnum_or_underscore(char c){ return std::isalnum((unsigned char)c) || c == '_'; }

struct LexError {
    int line, col;
    string message;
};

struct FIPEntry {
    string token_repr; // tip (ID, CONS, KW, OP, SEP)
    int ts_pos;        // daca tokenul e ID/CONST va fi numarul liniei din TS; altfel 0
    int src_line;      // info suplimentare: linia unde apare in codul sursa
};

struct TS_InMemory {
    string lexeme;
    string kind; // id/const
    int internal_id; // id intern (alocat incremental)
};

class TSManager {
    // mapping lexeme -> internal id
    unordered_map<string,int> lookup; // key = kind+'|'+lexeme -> internal_id
    vector<TS_InMemory> entries_by_id; // index = internal_id-1 -> entry

public:
    TSManager() {
        entries_by_id.clear();
        lookup.clear();
    }

    int insert(const string &lex, const string &kind){
        string key = kind + "|" + lex;
        auto it = lookup.find(key);
        if(it != lookup.end())
            return it->second;
        int new_id = (int)entries_by_id.size() + 1;
        TS_InMemory e{lex, kind, new_id};
        entries_by_id.push_back(e);
        lookup[key] = new_id;
        return new_id;
    }

    const TS_InMemory* get_by_internal_id(int id) const {
        if(id <= 0 || id > (int)entries_by_id.size())
            return nullptr;
        return &entries_by_id[id-1];
    }

    unordered_map<int,int> finalize_and_save(const string &ts_filename) {
        // create vector of pointers to entries and sort lexicographically by lexeme then kind
        vector<TS_InMemory> cloned = entries_by_id;
        sort(cloned.begin(), cloned.end(), [](const TS_InMemory &a, const TS_InMemory &b){
            if(a.lexeme != b.lexeme)
                return a.lexeme < b.lexeme;
            return a.kind < b.kind;
        });

        // mapping internal_id -> line number
        unordered_map<int,int> internal_to_line;
        ofstream out(ts_filename);
        if(!out.is_open()){
            cerr << "Erorr: Cannot open TS file: " << ts_filename << "\n";
            exit(1);
        }
        int line = 0;
        out << "Index | Kind | Lexeme\n";
        while(!cloned.empty()){
            const TS_InMemory &e = cloned.front();
            line++;
            out << line << " | " << e.kind << " | " << e.lexeme << "\n";
            internal_to_line[e.internal_id] = line;
            cloned.erase(cloned.begin());
        }
        out.close();
        return internal_to_line;
    }

    size_t size() const {
        return entries_by_id.size();
    }
};

bool valid_identifier(const string &s, string &reason) {
    if(s.empty()) {
        reason = "empty";
        return false;
    }
    char first = s[0];
    if(!(first == '_' || (first >= 'a' && first <= 'z'))){
        reason = "must start with lowercase letter or underscore";
        return false;
    }
    for(char c : s){
        if(!(is_letter(c) || is_digit(c) || c == '_')){
            reason = "contains invalid character";
            return false;
        }
    }
    if(keywords.count(s)){
        reason = "is reserved keyword";
        return false;
    }
    return true;
}

bool valid_constant(const string &s) {
    if(s.empty()) return false;
    size_t i = 0;
    if(s[0] == '+' || s[0] == '-')
        i++;
    bool hasDigitsBefore = false;
    while(i < s.size() && is_digit(s[i])) {
        hasDigitsBefore = true;
        i++;
    }
    if(i < s.size() && s[i] == '.'){
        i++;
        bool hasDigitsAfter = false;
        while(i < s.size() && is_digit(s[i])) {
            hasDigitsAfter = true;
            i++;
        }
        if(!hasDigitsBefore && !hasDigitsAfter)
            return false;
    } else {
        if(!hasDigitsBefore)
            return false;
    }
    return i == s.size();
}

vector<FIPEntry> analyze_file(const string &filename, TSManager &ts, vector<LexError> &errors) {
    ifstream in(filename);
    if(!in.is_open()){
        cerr << "Cannot open file: " << filename << endl;
        exit(1);
    }

    vector<FIPEntry> fip;
    string line;
    int lineNo = 0;

    vector<string> multi_ops = {"<<",">>","<=",">=","==","!="};

    while(getline(in, line)){
        lineNo++;
        size_t i = 0;
        while(i < line.size()){
            if(isspace((unsigned char)line[i])) { i++; continue; }

            int col = (int)i + 1;
            char c = line[i];
            string s1(1,c);

            auto starts_with = [&](const string &pat){
                return (i + pat.size() <= line.size() && line.substr(i, pat.size()) == pat);
            };

            if(c == '#'){
                size_t j = i;
                while(j < line.size() && !isspace((unsigned char)line[j]))
                    j++;
                string directive = line.substr(i, j-i);
                fip.push_back({string("KW:")+directive, 0, lineNo});
                i = j;

                while(i < line.size() && isspace((unsigned char)line[i])) i++;
                if(i < line.size() && line[i] == '<'){
                    size_t k = i+1;
                    while(k < line.size() && line[k] != '>') k++;
                    if(k < line.size() && line[k] == '>'){
                        string inside = line.substr(i+1, k-(i+1));
                        fip.push_back({string("INC:<")+inside+">", 0, lineNo});
                        i = k+1;
                    } else {
                        errors.push_back({lineNo, col, "Unclosed <...> after #include"});
                        i = line.size();
                    }
                }
                continue;
            }

            bool matched = false;
            for(auto &op : multi_ops){
                if(starts_with(op)){
                    fip.push_back({string("OP:")+op,0,lineNo});
                    i += op.size();
                    matched = true;
                    break;
                }
            }
            if(matched) continue;

            if(single_separators.count(c)){
                fip.push_back({string("SEP:")+s1,0,lineNo});
                i++;
                continue;
            }

            if(string("+-*/%=").find(c) != string::npos || c == '<' || c == '>'){
                string op(1,c);
                if(operators_set.count(op)){
                    fip.push_back({string("OP:")+op,0,lineNo});
                    i++;
                    continue;
                }
            }

            if(is_letter(c) || c == '_'){
                size_t j = i+1;
                while(j < line.size() && is_alnum_or_underscore(line[j])) j++;
                string lex = line.substr(i, j-i);
                if(keywords.count(lex)){
                    fip.push_back({string("KW:")+lex,0,lineNo});
                } else {
                    string reason;
                    if(!valid_identifier(lex, reason)){
                        errors.push_back({lineNo,col,"Invalid identifier '"+lex+"': "+reason});
                    }
                    int internal_id = ts.insert(lex,"id");
                    fip.push_back({"ID", internal_id, lineNo});
                }
                i = j;
                continue;
            }

            if(c == '+' || c == '-' || is_digit(c)){
                size_t j = i;
                if(line[j] == '+' || line[j] == '-') j++;
                if(j < line.size() && !is_digit(line[j])){
                    fip.push_back({string("OP:")+string(1,c),0,lineNo});
                    i++;
                    continue;
                }

                while(j < line.size() && is_digit(line[j]))
                    j++;
                if(j < line.size() && line[j] == '.'){
                    j++;
                    while(j < line.size() && is_digit(line[j]))
                        j++;
                }
                string lex = line.substr(i, j-i);
                if(valid_constant(lex)){
                    int internal_id = ts.insert(lex,"const");
                    fip.push_back({"CONST", internal_id, lineNo});
                } else {
                    errors.push_back({lineNo, col, "Malformed numeric constant '" + lex + "'"});
                }
                i = j;
                continue;
            }

            if(c == '"'){
                size_t j = i+1;
                bool closed = false;
                while(j < line.size()){
                    if(line[j] == '"'){ closed = true; break; }
                    j++;
                }
                if(!closed){
                    errors.push_back({lineNo, col, "Unclosed string literal"});
                    i = line.size();
                } else {
                    errors.push_back({lineNo, col, "String literals not allowed in MLP"});
                    i = j+1;
                }
                continue;
            }

            errors.push_back({lineNo, col, "Invalid character '"+string(1,c)+"'"});
            i++;
        }
    }

    in.close();
    return fip;
}

int main(int argc, char** argv) {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    if(argc < 2){
        cout << "Usage: " << argv[0] << " <source-file>\n";
        return 0;
    }

    string source = argv[1];
    TSManager ts;
    vector<LexError> errors;

    vector<FIPEntry> fip = analyze_file(source, ts, errors);

    string ts_filename = "TS.txt";
    unordered_map<int,int> internal_to_line = ts.finalize_and_save(ts_filename);

    for(auto &e : fip){
        if(e.token_repr == "ID" || e.token_repr == "CONST"){
            int internal_id = e.ts_pos;
            auto it = internal_to_line.find(internal_id);
            if(it != internal_to_line.end()){
                e.ts_pos = it->second;
            } else {
                e.ts_pos = 0;
            }
        }
    }

    string fip_filename = "FIP.txt";
    ofstream fout(fip_filename);
    if(!fout.is_open()){
        cerr << "Error: Cannot open FIP file: " << fip_filename << "\n";
        return 1;
    }

    cout << "\n=== ATOMI LEXICALI (FIP) ===\n";
    fout << "Nr | Token | TS_line\n";
    for(size_t i=0;i<fip.size();++i){
        const FIPEntry &e = fip[i];
        cout << i+1 << " | " << e.token_repr;
        if(e.ts_pos != 0) cout << " | TS poz: " << e.ts_pos;
        cout << " (line in src: " << e.src_line << ")\n";

        fout << (i+1) << " | " << e.token_repr << " | " << e.ts_pos << "\n";
    }
    fout.close();

    cout << "\n=== TABELA DE SIMBOLURI (TS) scrisa in '" << ts_filename << "' ===\n";
    ifstream tin(ts_filename);
    string tline;
    while(getline(tin, tline)) cout << tline << "\n";
    tin.close();

    if(!errors.empty()){
        cout << "\n=== ERORI LEXICALE ===\n";
        for(auto &er : errors){
            cout << "Line " << er.line << ", Col " << er.col << " : " << er.message << "\n";
        }
    } else {
        cout << "\nNo lexical errors\n";
    }

    cout << "\nFIP saved in: " << fip_filename << "\n";
    cout << "TS saved in: " << ts_filename << "\n";

    return 0;
}
