#include <iostream>
using namespace std;

int main() {
    float raza, perimetru, arie, pi = 3.14159;

    cin>>raza;

    perimetru = 2 * pi * raza;
    cout<<perimetru<<endl;

    arie = pi * raza * raza;
    cout<<arie<<endl;

    return 0;
}