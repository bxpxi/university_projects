#include <bits/stdc++.h>
using namespace std;

static inline string trim(const string &s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == string::npos)
        return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

static inline vector<string> split_csv(const string &s) {
    vector<string> res;
    string curr;
    bool inquote = false;
    for (size_t i = 0; i < s.size(); ++i) {
        char c = s[i];
        if (c == ',' && !inquote) {
            res.push_back(trim(curr));
            curr.clear();
        } else {
            curr.push_back(c);
        }
    }
    if (!curr.empty() || s.size()>0)
        res.push_back(trim(curr));
    vector<string> out;
    for (auto &t : res)
        if (!t.empty())
            out.push_back(t);
    return out;
}

class Automat {
public:
    set<string> stari;
    set<string> alfabet;
    string stare_initiala;
    set<string> stari_finale;
    unordered_map<string, unordered_map<string, set<string>>> tranzitii;

    Automat() {}

    bool incarcaDinFisier(const string &filename, string &err) {
        ifstream in(filename);
        if (!in) {
            err = "Nu se poate deschide fisierul: " + filename;
            return false;
        }
        vector<string> lines;
        string line;
        while (getline(in, line))
            lines.push_back(line);
        in.close();
        return parseazaLinii(lines, err);
    }

    bool incarcaDeLaTastatura(string &err) {
        cout << "Introduceti automatul (terminati cu o linie ce contine doar END):\n";
        vector<string> lines;
        string line;
        while (true) {
            if(!std::getline(cin, line))
                break;
            if (trim(line) == "END")
                break;
            lines.push_back(line);
        }
        return parseazaLinii(lines, err);
    }

    bool esteDeterminist(string &motiv) const {
        for (const auto &st : stari) {
            auto it = tranzitii.find(st);
            if (it == tranzitii.end())
                continue;
            for (const auto &p : it->second) {
                const string &simbol = p.first;
                const set<string> &dest = p.second;
                if (simbol == "eps") {
                    motiv = "Contine tranzitii epsilon -> nedeterminist.";
                    return false;
                }
                if (dest.size() > 1) {
                    motiv = "Pentru perechea (stare, simbol) exista mai multe destinatii.";
                    return false;
                }
            }
        }
        if (stari.find(stare_initiala) == stari.end()) {
            motiv = "Starea initiala nu este in multimea starilor.";
            return false;
        }
        return true;
    }

    bool acceptaAFD(const string &secventa) const {
        string motiv;
        if (!esteDeterminist(motiv)) {
            throw runtime_error("Automatul nu este determinist: " + motiv);
        }
        string curr = stare_initiala;
        for (char c : secventa) {
            string s(1, c);
            auto it = tranzitii.find(curr);
            if (it == tranzitii.end())
                return false;
            auto it2 = it->second.find(s);
            if (it2 == it->second.end())
                return false;
            curr = *it2->second.begin();
        }
        return stari_finale.find(curr) != stari_finale.end();
    }

    string celMaiLungPrefixAcceptatAFD(const string &secventa) const {
        string motiv;
        if (!esteDeterminist(motiv)) {
            throw runtime_error("Automatul nu este determinist: " + motiv);
        }
        string curr = stare_initiala;
        int ultimaPozAcceptata = -1;
        if (stari_finale.find(curr) != stari_finale.end())
            ultimaPozAcceptata = 0;
        for (int i = 0; i < (int)secventa.size(); ++i) {
            string s(1, secventa[i]);
            auto it = tranzitii.find(curr);
            if (it == tranzitii.end())
                break;
            auto it2 = it->second.find(s);
            if (it2 == it->second.end())
                break;
            curr = *it2->second.begin();
            if (stari_finale.find(curr) != stari_finale.end())
                ultimaPozAcceptata = i + 1;
        }
        if (ultimaPozAcceptata <= 0)
            return "";
        return secventa.substr(0, ultimaPozAcceptata);
    }

    void afiseazaStari() const {
        cout << "Stari: {";
        bool first=true;
        for (auto &s : stari) {
            if (!first)
                cout << ", ";
            cout << s;
            first=false;
        }
        cout << "}\n";
    }
    void afiseazaAlfabet() const {
        cout << "Alfabet: {";
        bool first=true;
        for (auto &a : alfabet) {
            if (!first)
                cout << ", ";
            cout << a;
            first=false;
        }
        cout << "}\n";
    }
    void afiseazaFinale() const {
        cout << "Stari finale: {";
        bool first=true;
        for (auto &s : stari_finale) {
            if (!first)
                cout << ", ";
            cout << s;
            first=false;
        }
        cout << "}\n";
    }
    void afiseazaTranzitii() const {
        cout << "Tranzitii:\n";
        for (auto &from : tranzitii) {
            for (auto &p : from.second) {
                cout << "  " << from.first << " --" << p.first << "--> {";
                bool f=true;
                for (auto &to : p.second) {
                    if (!f)
                        cout << ", ";
                    cout << to;
                    f=false;
                }
                cout << "}\n";
            }
        }
    }

private:
    bool parseazaLinii(const vector<string> &linii, string &err) {
        enum Sectiune { S_STARI, S_ALFABET, S_START, S_FINALE, S_TRANZ, S_DONE };
        Sectiune sec = S_STARI;
        size_t i = 0;

        auto incepeCu = [&](const string &linie, const string &prefix)->bool{
            string t = linie;
            return t.size() >= prefix.size() && trim(t.substr(0, prefix.size())) == prefix;
        };

        auto dupaDouaPuncte = [&](const string &linie)->string{
            auto pos = linie.find(':');
            if (pos == string::npos)
                return "";
            return trim(linie.substr(pos+1));
        };

        vector<string> liniiTranz;

        while (i < linii.size()) {
            string linie = trim(linii[i]);
            if (linie.empty()) { ++i; continue; }
            if (sec == S_STARI) {
                if (!incepeCu(linie, "states:")) { err = "Lipseste sectiunea 'states:' la inceput."; return false; }
                auto rest = dupaDouaPuncte(linie);
                auto toks = split_csv(rest);
                for (auto &t : toks)
                    stari.insert(t);
                sec = S_ALFABET;
                ++i;
            } else if (sec == S_ALFABET) {
                if (!incepeCu(linie, "alphabet:")) { err = "Lipseste sectiunea 'alphabet:'."; return false; }
                auto rest = dupaDouaPuncte(linie);
                auto toks = split_csv(rest);
                for (auto &t : toks) {
                    string s = trim(t);
                    if (s == "eps")
                        alfabet.insert("eps");
                    else if (s.size() >= 2 && s.front() == '\'' && s.back() == '\'')
                        alfabet.insert(s.substr(1, s.size()-2));
                    else { err = "Simbol invalid in alfabet: " + s; return false; }
                }
                sec = S_START;
                ++i;
            } else if (sec == S_START) {
                if (!incepeCu(linie, "start:")) { err = "Lipseste sectiunea 'start:'."; return false; }
                stare_initiala = trim(dupaDouaPuncte(linie));
                ++i;
                sec = S_FINALE;
            } else if (sec == S_FINALE) {
                if (!incepeCu(linie, "finals:")) { err = "Lipseste sectiunea 'finals:'."; return false; }
                auto rest = dupaDouaPuncte(linie);
                auto toks = split_csv(rest);
                for (auto &t : toks)
                    stari_finale.insert(t);
                ++i;
                sec = S_TRANZ;
            } else if (sec == S_TRANZ) {
                if (!incepeCu(linie, "transitions:")) {
                    err = "Lipseste sectiunea 'transitions:'."; return false;
                }
                ++i;
                while (i < linii.size()) {
                    string l2 = trim(linii[i]);
                    if (l2.empty()) {
                        ++i;
                        continue;
                    }
                    liniiTranz.push_back(l2);
                    ++i;
                }
                break;
            }
        }

        for (auto &tl : liniiTranz) {
            auto pos1 = tl.find("->");
            if (pos1 == string::npos) {
                err = "Tranzitie invalida: " + tl;
                return false;
            }
            string st_from = trim(tl.substr(0, pos1));
            string rest = trim(tl.substr(pos1 + 2));
            auto pos2 = rest.find("->");
            if (pos2 == string::npos) {
                err = "Tranzitie invalida: " + tl;
                return false;
            }
            string simbol_raw = trim(rest.substr(0, pos2));
            string st_to_raw = trim(rest.substr(pos2 + 2));

            string simbol;
            if (simbol_raw == "eps")
                simbol = "eps";
            else if (simbol_raw.size() >= 2 && simbol_raw.front() == '\'' && simbol_raw.back() == '\'')
                simbol = simbol_raw.substr(1, simbol_raw.size()-2);
            else {
                err = "Simbol tranzitie invalid: " + simbol_raw;
                return false;
            }

            auto destinatii = split_csv(st_to_raw);
            for (auto &to : destinatii) {
                stari.insert(st_from);
                stari.insert(to);
                if (simbol != "eps")
                    alfabet.insert(simbol);
                tranzitii[st_from][simbol].insert(to);
            }
        }

        if (stari.empty()) {
            err = "Nu exista stari definite.";
            return false;
        }
        if (stare_initiala.empty()) {
            err = "Starea initiala nu este definita.";
            return false;
        }
        if (stari.find(stare_initiala) == stari.end())
            stari.insert(stare_initiala);
        return true;
    }
};

void afiseazaMeniu() {
    cout << "\nMeniu:\n";
    cout << "1. Afiseaza multimea starilor\n";
    cout << "2. Afiseaza alfabetul\n";
    cout << "3. Afiseaza tranzitiile\n";
    cout << "4. Afiseaza starile finale\n";
    cout << "5. Verifica (pentru AFD) daca o secventa este acceptata\n";
    cout << "6. Determina (pentru AFD) cel mai lung prefix acceptat dintr-o secventa\n";
    cout << "7. Iesire\n";
    cout << "Alegeti optiunea: ";
}

int main() {
    Automat A;
    cout << "Citire automat: (1) din fisier  (2) de la tastatura\nAlegeti (1/2): ";
    string opt;
    getline(cin, opt);
    string err;

    if (trim(opt) == "1") {
        cout << "Nume fisier (ex: int_literals.af): ";
        string fname;
        getline(cin, fname);
        if (!A.incarcaDinFisier(trim(fname), err)) {
            cerr << "Eroare citire: " << err << "\n";
            return 1;
        }
    } else {
        if (!A.incarcaDeLaTastatura(err)) {
            cerr << "Eroare citire: " << err << "\n";
            return 1;
        }
    }

    while (true) {
        afiseazaMeniu();
        string alegere;
        if (!getline(cin, alegere)) break;
        alegere = trim(alegere);

        if (alegere == "1")
            A.afiseazaStari();
        else if (alegere == "2")
            A.afiseazaAlfabet();
        else if (alegere == "3")
            A.afiseazaTranzitii();
        else if (alegere == "4")
            A.afiseazaFinale();
        else if (alegere == "5") {
            string motiv;
            if (!A.esteDeterminist(motiv)) {
                cout << "Automatul NU este determinist: " << motiv << "\n";
                continue;
            }
            cout << "Introduceti secventa: ";
            string seq; getline(cin, seq);
            try {
                cout << (A.acceptaAFD(seq) ? "Secventa este ACCEPTATA.\n" : "Secventa NU este acceptata.\n");
            } catch (const exception &e) {
                cout << "Eroare: " << e.what() << "\n";
            }
        }
        else if (alegere == "6") {
            string motiv;
            if (!A.esteDeterminist(motiv)) {
                cout << "Automatul NU este determinist: " << motiv << "\n";
                continue;
            }
            cout << "Introduceti secventa: ";
            string seq; getline(cin, seq);
            try {
                string pref = A.celMaiLungPrefixAcceptatAFD(seq);
                if (pref.empty()) cout << "Niciun prefix acceptat.\n";
                else cout << "Cel mai lung prefix acceptat: \"" << pref << "\" (lungime " << pref.size() << ")\n";
            } catch (const exception &e) {
                cout << "Eroare: " << e.what() << "\n";
            }
        }
        else if (alegere == "7") { cout << "Exit\n"; break; }
        else cout << "Optiune invalida.\n";
    }

    return 0;
}
