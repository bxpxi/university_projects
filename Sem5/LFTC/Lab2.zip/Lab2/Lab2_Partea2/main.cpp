#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <set>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <cctype>
#include <stdexcept>

using namespace std;

class Automat {
public:
    set<string> stari;
    set<string> alfabet;
    string stare_initiala;
    set<string> stari_finale;
    unordered_map<string, unordered_map<string, set<string>>> tranzitii;

    Automat() {}

    void adaugaStare(const string &s, bool final=false) {
        stari.insert(s);
        if(final) stari_finale.insert(s);
    }

    void adaugaTranzitie(const string &from, const string &symbol, const string &to) {
        tranzitii[from][symbol].insert(to);
        alfabet.insert(symbol);
        stari.insert(from);
        stari.insert(to);
    }

    bool esteDeterminist(string &motiv) const {
        for (const auto &st : stari) {
            auto it = tranzitii.find(st);
            if (it == tranzitii.end()) continue;
            for (const auto &p : it->second) {
                if (p.first == "eps") {
                    motiv = "Contine tranzitii epsilon -> nedeterminist.";
                    return false;
                }
                if (p.second.size() > 1) {
                    motiv = "Pentru perechea (stare, simbol) exista mai multe destinatii.";
                    return false;
                }
            }
        }
        if(stari.find(stare_initiala)==stari.end()){
            motiv="Starea initiala nu este in multimea starilor.";
            return false;
        }
        return true;
    }

    bool acceptaAFD(const string &secventa) const {
        string motiv;
        if (!esteDeterminist(motiv)) throw runtime_error("Automatul nu este determinist: " + motiv);
        string curr = stare_initiala;
        for (char c : secventa) {
            string s(1, c);
            auto it = tranzitii.find(curr);
            if (it == tranzitii.end())
                return false;
            auto it2 = it->second.find(s);
            if (it2 == it->second.end())
                return false;
            curr = *it2->second.begin();
        }
        return stari_finale.find(curr) != stari_finale.end();
    }

    string celMaiLungPrefixAcceptatAFD(const string &secventa) const {
        string motiv;
        if (!esteDeterminist(motiv))
            throw runtime_error("Automatul nu este determinist: " + motiv);
        string curr = stare_initiala;
        int ultimaPozAcceptata = -1;
        if (stari_finale.find(curr) != stari_finale.end())
            ultimaPozAcceptata = 0;
        for (int i=0;i<(int)secventa.size();++i) {
            string s(1, secventa[i]);
            auto it = tranzitii.find(curr);
            if (it==tranzitii.end())
                break;
            auto it2 = it->second.find(s);
            if (it2==it->second.end())
                break;
            curr = *it2->second.begin();
            if(stari_finale.find(curr)!=stari_finale.end())
                ultimaPozAcceptata=i+1;
        }
        if (ultimaPozAcceptata<=0) return "";
        return secventa.substr(0, ultimaPozAcceptata);
    }
};

Automat construireAFIdentificator() {
    Automat afd;
    afd.stare_initiala="q0";
    afd.adaugaStare("q0");
    afd.adaugaStare("qf",true);
    for(char c='a';c<='z';++c){
        afd.adaugaTranzitie("q0", string(1,c), "qf");
        afd.adaugaTranzitie("qf", string(1,c), "qf");
    }
    afd.adaugaTranzitie("q0","_", "qf");
    afd.adaugaTranzitie("qf","_", "qf");
    for(char c='0';c<='9';++c)
        afd.adaugaTranzitie("qf", string(1,c), "qf");
    return afd;
}

Automat construireAFConstInt() {
    Automat afd;
    afd.stare_initiala="q0";
    afd.adaugaStare("q0");
    afd.adaugaStare("qf",true);
    afd.adaugaStare("q1");
    afd.adaugaTranzitie("q0","+","q1");
    afd.adaugaTranzitie("q0","-","q1");
    for(char c='0';c<='9';++c){
        afd.adaugaTranzitie("q0", string(1,c), "qf");
        afd.adaugaTranzitie("q1", string(1,c), "qf");
        afd.adaugaTranzitie("qf", string(1,c), "qf");
    }
    return afd;
}

Automat construireAFConstReal() {
    Automat afd;
    afd.stare_initiala="q0";
    afd.adaugaStare("q0");
    afd.adaugaStare("q1");
    afd.adaugaStare("qf",true);
    afd.adaugaStare("q2");
    afd.adaugaTranzitie("q0","+","q1");
    afd.adaugaTranzitie("q0","-","q1");
    for(char c='0';c<='9';++c){
        afd.adaugaTranzitie("q0", string(1,c), "qf");
        afd.adaugaTranzitie("q1", string(1,c), "qf");
        afd.adaugaTranzitie("qf", string(1,c), "qf");
    }
    afd.adaugaTranzitie("qf",".","q2");
    for(char c='0';c<='9';++c) afd.adaugaTranzitie("q2", string(1,c), "q2");
    afd.stari_finale.insert("q2");
    return afd;
}

const unordered_set<string> keywords = {
    "int","float","float_array","cin","cout","if","else","while","for",
    "return","#include","iostream","using","namespace","std","endl","main"
};

const unordered_set<string> operators_set = {
    "+","-","*","/","%","=","==","!=","<","<=",">",">=","<<",">>"
};

const unordered_set<char> single_separators = {
    ';',',','(',')','{','}','[',']'
};

struct FIPEntry {
    string token_repr; // tip (ID, CONST, KW, OP, SEP)
    int ts_pos;        // pozitie in TS
    int src_line;      // linia din sursa
};

struct TS_InMemory {
    string lexeme;
    string kind; // id/const
    int internal_id;
};

class TSManager {
    unordered_map<string,int> lookup;
    vector<TS_InMemory> entries_by_id;
public:
    int insert(const string &lex, const string &kind){
        string key = kind+"|"+lex;
        auto it = lookup.find(key);
        if(it != lookup.end()) return it->second;
        int new_id = (int)entries_by_id.size()+1;
        entries_by_id.push_back({lex,kind,new_id});
        lookup[key]=new_id;
        return new_id;
    }

    unordered_map<int,int> finalize_and_save(const string &ts_filename){
        vector<TS_InMemory> cloned=entries_by_id;
        sort(cloned.begin(), cloned.end(), [](const TS_InMemory &a, const TS_InMemory &b){
            if(a.lexeme!=b.lexeme)
                return a.lexeme<b.lexeme;
            return a.kind<b.kind;
        });
        unordered_map<int,int> internal_to_line;
        ofstream out(ts_filename);
        out<<"Index | Kind | Lexeme\n";
        int line=0;
        for(auto &e: cloned){
            line++;
            out<<line<<" | "<<e.kind<<" | "<<e.lexeme<<"\n";
            internal_to_line[e.internal_id]=line;
        }
        out.close();
        return internal_to_line;
    }
};

bool is_letter(char c) {
    return std::isalpha((unsigned char)c);
}

bool is_digit(char c) {
    return std::isdigit((unsigned char)c);
}

bool is_alnum_or_underscore(char c) {
    return std::isalnum((unsigned char)c) || c=='_';
}

string trim(const string &s) {
    size_t a=s.find_first_not_of(" \t\r\n");
    if(a==string::npos)
        return "";
    size_t b=s.find_last_not_of(" \t\r\n");
    return s.substr(a,b-a+1);
}

vector<FIPEntry> lexical_analyze(const string &filename, TSManager &ts, vector<string> &errors) {
    ifstream in(filename);
    if(!in.is_open()){ cerr<<"Cannot open file "<<filename<<"\n"; exit(1);}
    vector<FIPEntry> fip;
    string line;
    int lineNo=0;

    Automat AF_ID = construireAFIdentificator();
    Automat AF_INT = construireAFConstInt();
    Automat AF_REAL = construireAFConstReal();

    while(getline(in,line)){
        lineNo++;
        size_t i=0;
        while(i<line.size()){
            if(isspace((unsigned char)line[i])){ i++; continue; }

            string rest=line.substr(i);

            if(rest.substr(0,8)=="#include"){
                fip.push_back({"KW:#include",0,lineNo});
                i+=8;
                while(i<line.size() && isspace(line[i])) i++;
                if(i<line.size() && line[i]=='<'){
                    size_t j = line.find('>', i);
                    if(j!=string::npos){
                        string header = line.substr(i, j-i+1);
                        fip.push_back({"KW:"+header,0,lineNo});
                        i=j+1;
                        continue;
                    }
                }
            }

            string prefix = AF_ID.celMaiLungPrefixAcceptatAFD(rest);
            if(!prefix.empty()){
                if(keywords.count(prefix))
                    fip.push_back({"KW:"+prefix,0,lineNo});
                else{
                    int id = ts.insert(prefix,"id");
                    fip.push_back({"ID",id,lineNo});
                }
                i+=prefix.size();
                continue;
            }

            prefix = AF_REAL.celMaiLungPrefixAcceptatAFD(rest);
            if(!prefix.empty()){
                int id=ts.insert(prefix,"const");
                fip.push_back({"CONST",id,lineNo});
                i+=prefix.size();
                continue;
            }

            prefix = AF_INT.celMaiLungPrefixAcceptatAFD(rest);
            if(!prefix.empty()){
                int id=ts.insert(prefix,"const");
                fip.push_back({"CONST",id,lineNo});
                i+=prefix.size();
                continue;
            }

            vector<string> multi_ops = {"<<",">>","<=",">=","==","!="};
            bool op_found=false;
            for(auto &op:multi_ops){
                if(rest.substr(0,op.size())==op){
                    fip.push_back({"OP:"+op,0,lineNo});
                    i+=op.size();
                    op_found=true;
                    break;
                }
            }
            if(op_found)
                continue;

            if(operators_set.count(string(1,line[i]))){
                fip.push_back({"OP:"+string(1,line[i]),0,lineNo});
                i++;
                continue;
            }

            if(single_separators.count(line[i])){
                fip.push_back({"SEP:"+string(1,line[i]),0,lineNo});
                i++;
                continue;
            }

            errors.push_back("Line "+to_string(lineNo)+": invalid char '"+string(1,line[i])+"'");
            i++;
        }
    }
    return fip;
}

int main(int argc, char** argv){
    if(argc<2) {
        cout<<"Usage: "<<argv[0]<<" <source-file>\n";
        return 0;
    }
    string source = argv[1];
    TSManager ts;
    vector<string> errors;
    vector<FIPEntry> fip = lexical_analyze(source, ts, errors);

    string ts_filename="TS.txt";
    unordered_map<int,int> internal_to_line=ts.finalize_and_save(ts_filename);

    string fip_filename="FIP.txt";
    ofstream fout(fip_filename);
    fout<<"Nr | Token | TS_line\n";
    for(size_t i=0;i<fip.size();++i){
        auto &e=fip[i];
        if(e.token_repr=="ID" || e.token_repr=="CONST"){
            auto it=internal_to_line.find(e.ts_pos);
            if(it!=internal_to_line.end())
                e.ts_pos=it->second;
            else
                e.ts_pos=0;
        }
        cout<<i+1<<" | "<<e.token_repr;
        if(e.ts_pos!=0)
            cout<<" | TS poz: "<<e.ts_pos;
        cout<<" (line in src: "<<e.src_line<<")\n";
        fout<<i+1<<" | "<<e.token_repr<<" | "<<e.ts_pos<<"\n";
    }
    fout.close();

    cout<<"\nTS saved in "<<ts_filename<<"\n";
    cout<<"FIP saved in "<<fip_filename<<"\n";

    if(!errors.empty()){
        cout<<"\nLEXICAL ERRORS:\n";
        for(auto &e: errors)
            cout<<e<<"\n";
    } else
        cout<<"\nNo lexical errors\n";

    return 0;
}
