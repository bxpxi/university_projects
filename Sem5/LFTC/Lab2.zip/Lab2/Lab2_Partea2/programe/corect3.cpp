#include <iostream>
using namespace std;

int main() {
    int n;
    cin>>n;

    int suma = 0;
    while (n > 0) {
        int nr;
        cin>>nr;

        suma = suma + nr;
        n--;
    }

    cout<<suma<<endl;

    return 0;
}