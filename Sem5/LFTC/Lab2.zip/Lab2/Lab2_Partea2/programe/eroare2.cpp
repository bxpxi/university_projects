#include <iostream>
using namespace std;

int main() {
    int x = 5;
    string s = "abc";

    x = x + 2;
    cout << x << endl;

    return 0;
}
