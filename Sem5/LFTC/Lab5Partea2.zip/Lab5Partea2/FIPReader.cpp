#include "FIPReader.h"
#include <fstream>
#include <sstream>
#include <cctype>

static inline std::string trimLine(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && std::isspace((unsigned char)s[start]))
        start++;
    if (start == s.size())
        return "";
    size_t end = s.size() - 1;
    while (end > start && std::isspace((unsigned char)s[end]))
        end--;
    return s.substr(start, end - start + 1);
}

bool FIPReader::readFIP(const std::string& filename, std::vector<std::string>& tokens, std::string& errorMsg)
{
    tokens.clear();

    std::ifstream fin(filename);
    if (!fin) {
        errorMsg = "Nu s-a putut deschide fisierul FIP: " + filename;
        return false;
    }

    std::string line;
    int lineNo = 0;
    while (std::getline(fin, line)) {
        ++lineNo;
        line = trimLine(line);
        if (line.empty()) continue;

        std::istringstream iss(line);
        std::string cod;
        if (!(iss >> cod)) {
            continue;
        }
        tokens.push_back(cod);
    }

    if (tokens.empty()) {
        errorMsg = "Fisierul FIP nu contine niciun cod de atom.";
        return false;
    }

    return true;
}
