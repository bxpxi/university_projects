#include "Grammar.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <set>

const int Grammar::EPSILON = -1;

static inline std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && std::isspace((unsigned char)s[start]))
        start++;
    if (start == s.size())
        return "";
    size_t end = s.size() - 1;
    while (end > start && std::isspace((unsigned char)s[end]))
        end--;
    return s.substr(start, end - start + 1);
}

static inline std::vector<std::string> split(const std::string& s, char delim) {
    std::vector<std::string> result;
    std::string current;
    std::istringstream iss(s);
    while (std::getline(iss, current, delim)) {
        current = trim(current);
        if (!current.empty()) {
            result.push_back(current);
        }
    }
    return result;
}

static inline std::vector<std::string> splitSpaces(const std::string& s) {
    std::vector<std::string> result;
    std::istringstream iss(s);
    std::string token;
    while (iss >> token) {
        result.push_back(token);
    }
    return result;
}

Grammar::Grammar() : startSymbol(-1), endMarkerSymbol(-1)
{
    endMarkerSymbol = addSymbol("$", true);
}

int Grammar::addSymbol(const std::string& name, bool isTerminal) {
    auto it = nameToId.find(name);
    if (it != nameToId.end()) {
        int id = it->second;
        return id;
    }
    int id = static_cast<int>(symbols.size());
    SymbolInfo info;
    info.name = name;
    info.isTerminal = isTerminal;
    symbols.push_back(info);
    nameToId[name] = id;
    return id;
}

bool Grammar::loadFromFile(const std::string& filename, std::string& errorMsg) {
    std::ifstream fin(filename);
    if (!fin) {
        errorMsg = "Nu s-a putut deschide fisierul de gramatica: " + filename;
        return false;
    }

    std::vector<std::string> rawLines;
    std::string line;
    while (std::getline(fin, line)) {
        size_t hashPos = line.find('#');
        if (hashPos != std::string::npos) {
            line = line.substr(0, hashPos);
        }
        line = trim(line);
        if (line.empty()) continue;
        rawLines.push_back(line);
    }

    if (rawLines.empty()) {
        errorMsg = "Fisierul de gramatica este gol.";
        return false;
    }

    std::string startName = trim(rawLines[0]);
    startSymbol = addSymbol(startName, false);

    std::vector<std::string> prodLines;
    for (size_t i = 1; i < rawLines.size(); ++i) {
        prodLines.push_back(rawLines[i]);
    }

    if (prodLines.empty()) {
        errorMsg = "Nu exista productii in gramatica.";
        return false;
    }

    std::set<std::string> nontermNames;
    nontermNames.insert(startName);

    for (const auto& pl : prodLines) {
        size_t arrowPos = pl.find("->");
        if (arrowPos == std::string::npos) {
            errorMsg = "Linie de productie invalida (lipseste '->'): " + pl;
            return false;
        }
        std::string lhsStr = trim(pl.substr(0, arrowPos));
        if (lhsStr.empty()) {
            errorMsg = "Neterminal lipsa in stanga productiei: " + pl;
            return false;
        }
        nontermNames.insert(lhsStr);
    }

    for (const auto& nt : nontermNames) {
        addSymbol(nt, false);
    }

    productions.clear();

    for (const auto& pl : prodLines) {
        size_t arrowPos = pl.find("->");
        std::string lhsStr = trim(pl.substr(0, arrowPos));
        std::string rhsStr = trim(pl.substr(arrowPos + 2));

        int lhsId = getSymbolId(lhsStr);
        if (lhsId < 0 || !isNonTerminal(lhsId)) {
            errorMsg = "Neterminal invalid in stanga productiei: " + lhsStr;
            return false;
        }

        std::vector<std::string> alts = split(rhsStr, '|');
        if (alts.empty()) {
            errorMsg = "Partea dreapta goala la productie: " + pl;
            return false;
        }

        for (const auto& alt : alts) {
            std::string altTrim = trim(alt);
            Production p;
            p.lhs = lhsId;

            if (altTrim == "eps" || altTrim == "epsilon" ||
                altTrim == "EPS" || altTrim == "Eps") {
            } else {
                std::vector<std::string> symbolsStr = splitSpaces(altTrim);
                for (const auto& sname : symbolsStr) {
                    bool isNt = (nontermNames.find(sname) != nontermNames.end());
                    int sid = getSymbolId(sname);
                    if (sid < 0) {
                        sid = addSymbol(sname, !isNt);
                    } else {

                    }
                    p.rhs.push_back(sid);
                }
            }
            productions.push_back(p);
        }
    }

    return true;
}

int Grammar::getSymbolId(const std::string& name) const {
    auto it = nameToId.find(name);
    if (it == nameToId.end())
        return -1;
    return it->second;
}

std::string Grammar::symbolName(int id) const {
    if (id < 0 || id >= (int)symbols.size())
        return "<?>";
    return symbols[id].name;
}

bool Grammar::isTerminal(int id) const {
    if (id < 0 || id >= (int)symbols.size())
        return false;
    return symbols[id].isTerminal;
}

bool Grammar::isNonTerminal(int id) const {
    if (id < 0 || id >= (int)symbols.size())
        return false;
    return !symbols[id].isTerminal;
}

void Grammar::print(std::ostream& out) const {
    out << "Simboluri:\n";
    for (size_t i = 0; i < symbols.size(); ++i) {
        out << i << ": " << symbols[i].name
            << (symbols[i].isTerminal ? " (T)" : " (N)") << "\n";
    }
    out << "\nProductii:\n";
    for (size_t i = 0; i < productions.size(); ++i) {
        const auto& p = productions[i];
        out << i << ": " << symbolName(p.lhs) << " -> ";
        if (p.rhs.empty()) {
            out << "eps";
        } else {
            for (size_t j = 0; j < p.rhs.size(); ++j) {
                out << symbolName(p.rhs[j]);
                if (j + 1 < p.rhs.size()) out << " ";
            }
        }
        out << "\n";
    }
}
