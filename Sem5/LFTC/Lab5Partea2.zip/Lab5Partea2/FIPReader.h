#ifndef FIPREADER_H
#define FIPREADER_H

#include <string>
#include <vector>

class FIPReader {
public:
    static bool readFIP(const std::string& filename,
                        std::vector<std::string>& tokens,
                        std::string& errorMsg);
};

#endif
