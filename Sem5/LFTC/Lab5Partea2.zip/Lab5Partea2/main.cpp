#include <iostream>
#include <fstream>
#include <vector>
#include <string>

#include "Grammar.h"
#include "LL1Parser.h"
#include "FIPReader.h"

int main(int argc, char** argv) {
    if (argc < 3) {
        std::cerr << "Utilizare: " << argv[0] << " <fisier_gramatica_minilimbaj> <fisier_FIP>\n";
        return 1;
    }

    std::string grammarFile = argv[1];
    std::string fipFile = argv[2];

    Grammar g;
    std::string err;
    if (!g.loadFromFile(grammarFile, err)) {
        std::cerr << "Eroare la incarcare gramatica: " << err << "\n";
        return 1;
    }

    std::cout << "=== Gramatica minilimbajului ===\n";
    g.print(std::cout);
    std::cout << "================================\n\n";

    LL1Parser parser(g);
    parser.build();

    if (!parser.isLL1()) {
        std::cerr << "Gramatica NU este LL(1): " << parser.getErrorMessage() << "\n";
        return 1;
    } else {
        std::cout << "Gramatica este LL(1) (nu au fost detectate conflicte in tabel).\n\n";
    }

    std::vector<std::string> fipTokens;
    std::string fipErr;
    if (!FIPReader::readFIP(fipFile, fipTokens, fipErr)) {
        std::cerr << "Eroare la citirea FIP: " << fipErr << "\n";
        return 1;
    }

    std::vector<int> inputIds;
    for (size_t i = 0; i < fipTokens.size(); ++i) {
        const std::string& cod = fipTokens[i];
        int id = g.getSymbolId(cod);
        if (id < 0) {
            std::cerr << "Cod de atom necunoscut in FIP (linia " << (i+1) << "): '" << cod << "'\n";
            return 1;
        }
        if (!g.isTerminal(id)) {
            std::cerr << "Cod de atom din FIP nu este terminal in gramatica (linia " << (i+1) << "): '" << cod << "'\n";
            return 1;
        }
        inputIds.push_back(id);
    }

    inputIds.push_back(g.getEndMarker());

    if (inputIds.empty()) {
        std::cerr << "Secventa de intrare (din FIP) este goala.\n";
        return 1;
    }

    std::vector<int> usedProductions;
    std::string parseErr;

    bool ok = parser.parse(inputIds, usedProductions, parseErr);
    if (!ok) {
        std::cerr << "Program incorect sintactic.\n";
        std::cerr << parseErr << "\n";
        return 1;
    }

    std::cout << "Programul (din FIP) este corect sintactic.\n";
    std::cout << "Sirul productiilor folosite (in ordinea derivarilor):\n";

    const auto& prods = g.getProductions();
    for (size_t i = 0; i < usedProductions.size(); ++i) {
        int idx = usedProductions[i];
        if (idx < 0 || idx >= (int)prods.size())
            continue;
        const auto& p = prods[idx];
        std::cout << i << ") " << g.symbolName(p.lhs) << " -> ";
        if (p.rhs.empty()) {
            std::cout << "eps";
        } else {
            for (size_t j = 0; j < p.rhs.size(); ++j) {
                std::cout << g.symbolName(p.rhs[j]);
                if (j + 1 < p.rhs.size())
                    std::cout << " ";
            }
        }
        std::cout << "\n";
    }

    return 0;
}
