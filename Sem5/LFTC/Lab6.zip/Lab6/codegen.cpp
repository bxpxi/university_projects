#include "codegen.h"
#include "symtable.h"
#include <iostream>

using namespace std;

static vector<string> code;

void emit(const string& s) { code.push_back(s); }

void emit_push_const(int v) {
    emit("push dword " + to_string(v));
}

void emit_push_var(const string& v) {
    int off = get_var(v);
    emit("push dword [vars+" + to_string(off) + "]");
}

void emit_expr_add() {
    emit("pop ebx");
    emit("pop eax");
    emit("add eax, ebx");
    emit("push eax");
}

void emit_expr_sub() {
    emit("pop ebx");
    emit("pop eax");
    emit("sub eax, ebx");
    emit("push eax");
}

void emit_expr_mul() {
    emit("pop ebx");
    emit("pop eax");
    emit("imul eax, ebx");
    emit("push eax");
}

void emit_assign(const string& v) {
    int off = alloc_var(v);
    emit("pop eax");
    emit("mov [vars+" + to_string(off) + "], eax");
}

void generate_program() {
    cout << "global _start\n";

    cout << "section .bss\n";
    cout << "vars resb " << next_mem << "\n";
    cout << "number_buffer resb 12\n";

    cout << "section .text\n";

    cout <<
R"(
print_int:
    mov ebx, 10
    mov ecx, number_buffer + 11
    mov byte [ecx], 0
    dec ecx

.convert_loop_print:
    xor edx, edx
    div ebx
    add dl, '0'
    mov [ecx], dl
    dec ecx
    test eax, eax
    jnz .convert_loop_print

    inc ecx

    mov esi, number_buffer + 12
    sub esi, ecx
    mov edx, esi

    mov eax, 4
    mov ebx, 1
    ; ecx pointeaza la inceputul sirului
    int 0x80
    ret
)";

    cout <<
R"(
read_int:
    mov eax, 3
    mov ebx, 0
    mov ecx, number_buffer
    mov edx, 12
    int 0x80

    mov esi, number_buffer
    xor eax, eax
    xor ebx, ebx

.convert_loop_read:
    mov bl, [esi]
    cmp bl, 0
    je .done_read
    cmp bl, 10
    je .done_read
    sub bl, '0'
    imul eax, 10
    add eax, ebx
    inc esi
    jmp .convert_loop_read

.done_read:
    ret
)";

    cout << "_start:\n";

    for (auto &s : code)
        cout << s << "\n";

    cout << "mov eax,1\n";
    cout << "mov ebx,0\n";
    cout << "int 0x80\n";
}
