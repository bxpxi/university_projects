#ifndef SYMTABLE_H
#define SYMTABLE_H

#include <string>
#include <unordered_map>

using namespace std;

extern unordered_map<string,int> symtab;
extern int next_mem;

int alloc_var(const string& s);
int get_var(const string& s);

#endif
