#ifndef CODEGEN_H
#define CODEGEN_H
#include <string>
#include <vector>

void emit(const std::string& s);
void emit_expr_add();
void emit_expr_sub();
void emit_expr_mul();
void emit_push_const(int v);
void emit_push_var(const std::string& v);
void emit_assign(const std::string& v);
void generate_program();

#endif
