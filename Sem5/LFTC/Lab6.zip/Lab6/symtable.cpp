#include "symtable.h"

unordered_map<string,int> symtab;
int next_mem = 0;

int alloc_var(const string& s) {
    auto it = symtab.find(s);
    if (it != symtab.end())
        return it->second;

    int off = next_mem;
    next_mem += 4;
    symtab[s] = off;
    return off;
}

int get_var(const string& s) {
    auto it = symtab.find(s);
    if (it == symtab.end()) {
        return alloc_var(s);
    }
    return it->second;
}
