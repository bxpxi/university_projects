#include "LL1Parser.h"
#include <stack>
#include <iostream>

LL1Parser::LL1Parser(const Grammar& g): grammar(g), ll1Ok(true)
{
    int n = grammar.symbolsCount();
    FIRST.resize(n);
    FOLLOW.resize(n);
    parseTable.resize(n);
}

void LL1Parser::build() {
    computeFirst();
    computeFollow();
    buildTable();
}

void LL1Parser::computeFirst() {
    int n = grammar.symbolsCount();

    for (int i = 0; i < n; ++i) {
        FIRST[i].clear();
        if (grammar.isTerminal(i) || i == grammar.getEndMarker()) {
            FIRST[i].insert(i);
        }
    }

    bool changed = true;
    const auto& prods = grammar.getProductions();

    while (changed) {
        changed = false;

        for (const auto& p : prods) {
            int A = p.lhs;

            if (p.rhs.empty()) {
                if (FIRST[A].insert(Grammar::EPSILON).second) {
                    changed = true;
                }
                continue;
            }

            bool allCanEps = true;
            for (size_t i = 0; i < p.rhs.size(); ++i) {
                int X = p.rhs[i];

                for (int a : FIRST[X]) {
                    if (a == Grammar::EPSILON) continue;
                    if (FIRST[A].insert(a).second) {
                        changed = true;
                    }
                }

                if (FIRST[X].find(Grammar::EPSILON) == FIRST[X].end()) {
                    allCanEps = false;
                    break;
                }
            }

            if (allCanEps) {
                if (FIRST[A].insert(Grammar::EPSILON).second) {
                    changed = true;
                }
            }
        }
    }
}


std::set<int> LL1Parser::firstOfSequence(const std::vector<int>& seq) const {
    std::set<int> result;
    bool allCanEps = true;

    if (seq.empty()) {
        result.insert(Grammar::EPSILON);
        return result;
    }

    for (size_t i = 0; i < seq.size(); ++i) {
        int X = seq[i];
        const auto& FX = FIRST[X];

        for (int a : FX) {
            if (a == Grammar::EPSILON) continue;
            result.insert(a);
        }

        if (FX.find(Grammar::EPSILON) == FX.end()) {
            allCanEps = false;
            break;
        }
    }

    if (allCanEps) {
        result.insert(Grammar::EPSILON);
    }

    return result;
}

void LL1Parser::computeFollow() {
    int n = grammar.symbolsCount();

    for (int i = 0; i < n; ++i) {
        FOLLOW[i].clear();
    }

    int S = grammar.getStartSymbol();
    FOLLOW[S].insert(grammar.getEndMarker());

    bool changed = true;
    const auto& prods = grammar.getProductions();

    while (changed) {
        changed = false;

        for (const auto& p : prods) {
            int A = p.lhs;
            const auto& alpha = p.rhs;

            for (size_t i = 0; i < alpha.size(); ++i) {
                int B = alpha[i];
                if (!grammar.isNonTerminal(B)) continue;

                std::vector<int> beta;
                for (size_t j = i + 1; j < alpha.size(); ++j) {
                    beta.push_back(alpha[j]);
                }

                auto firstBeta = firstOfSequence(beta);
                bool betaCanEps = (firstBeta.find(Grammar::EPSILON) != firstBeta.end());

                for (int a : firstBeta) {
                    if (a == Grammar::EPSILON) continue;
                    if (FOLLOW[B].insert(a).second) {
                        changed = true;
                    }
                }

                if (beta.empty() || betaCanEps) {
                    for (int a : FOLLOW[A]) {
                        if (FOLLOW[B].insert(a).second) {
                            changed = true;
                        }
                    }
                }
            }
        }
    }
}

void LL1Parser::buildTable() {
    ll1Ok = true;
    ll1ErrorMessage.clear();

    int nSymbols = grammar.symbolsCount();
    parseTable.clear();
    parseTable.resize(nSymbols);

    const auto& prods = grammar.getProductions();

    for (int i = 0; i < (int)prods.size(); ++i) {
        const Production& p = prods[i];
        int A = p.lhs;

        auto firstAlpha = firstOfSequence(p.rhs);

        for (int a : firstAlpha) {
            if (a == Grammar::EPSILON) continue;
            if (!grammar.isTerminal(a) && a != grammar.getEndMarker())
                continue;

            auto& row = parseTable[A];
            auto it = row.find(a);
            if (it != row.end() && it->second != i) {
                ll1Ok = false;
                ll1ErrorMessage =
                    "Conflict in tabela LL(1) pentru neterminalul '" +
                    grammar.symbolName(A) + "' si terminalul '" +
                    grammar.symbolName(a) + "'.";
            } else {
                row[a] = i;
            }
        }

        if (firstAlpha.find(Grammar::EPSILON) != firstAlpha.end()) {
            const auto& followA = FOLLOW[A];
            for (int b : followA) {
                auto& row = parseTable[A];
                auto it = row.find(b);
                if (it != row.end() && it->second != i) {
                    ll1Ok = false;
                    ll1ErrorMessage =
                        "Conflict (eps) in tabela LL(1) pentru neterminalul '" +
                        grammar.symbolName(A) + "' si simbolul '" +
                        grammar.symbolName(b) + "'.";
                } else {
                    row[b] = i;
                }
            }
        }
    }
}

bool LL1Parser::parse(const std::vector<int>& input, std::vector<int>& usedProductions, std::string& errorMsg) const
{
    if (!ll1Ok) {
        errorMsg = "Gramatica nu este LL(1): " + ll1ErrorMessage;
        return false;
    }

    usedProductions.clear();

    if (input.empty()) {
        errorMsg = "Secventa de intrare este goala (nu are nici macar $).";
        return false;
    }

    std::vector<int> stiva;
    int endMarker = grammar.getEndMarker();
    int S = grammar.getStartSymbol();

    stiva.push_back(endMarker);
    stiva.push_back(S);

    size_t ip = 0;
    int a = input[ip];

    const auto& prods = grammar.getProductions();

    while (!stiva.empty()) {
        int X = stiva.back();

        if (grammar.isTerminal(X) || X == endMarker) {
            if (X == a) {
                stiva.pop_back();
                ++ip;
                if (ip >= input.size()) {
                    if (stiva.empty()) {
                        return true;
                    } else {
                        errorMsg = "Eroare de sintaxa: intrarea s-a terminat, dar stiva nu este vida.";
                        return false;
                    }
                }
                a = input[ip];
            } else {
                errorMsg = "Eroare de sintaxa: se astepta simbolul '" +
                           grammar.symbolName(X) + "', dar s-a gasit '" +
                           grammar.symbolName(a) + "'.";
                return false;
            }
        } else {
            const auto& row = parseTable[X];
            auto it = row.find(a);
            if (it == row.end()) {
                errorMsg = "Eroare de sintaxa: nu exista productie aplicabila "
                           "pentru neterminalul '" + grammar.symbolName(X) +
                           "' si simbolul de intrare '" +
                           grammar.symbolName(a) + "'.";
                return false;
            }

            int prodIndex = it->second;
            const Production& p = prods[prodIndex];

            stiva.pop_back();

            for (int k = (int)p.rhs.size() - 1; k >= 0; --k) {
                int Y = p.rhs[k];
                stiva.push_back(Y);
            }

            usedProductions.push_back(prodIndex);
        }
    }

    if (ip == input.size()) {
        return true;
    } else {
        errorMsg = "Eroare: au ramas simboluri de intrare neprocesate.";
        return false;
    }
}
