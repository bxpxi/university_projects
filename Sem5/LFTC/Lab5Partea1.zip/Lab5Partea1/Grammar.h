#ifndef GRAMMAR_H
#define GRAMMAR_H

#include <string>
#include <vector>
#include <map>
#include <set>
#include <iostream>

struct Production {
    int lhs;
    std::vector<int> rhs;
};

class Grammar {
public:
    struct SymbolInfo {
        std::string name;
        bool isTerminal;
    };

    static const int EPSILON;

    Grammar();

    bool loadFromFile(const std::string& filename, std::string& errorMsg);

    const std::vector<Production>& getProductions() const {
        return productions;
    }

    const std::vector<SymbolInfo>& getSymbols() const {
        return symbols;
    }

    int getStartSymbol() const {
        return startSymbol;
    }

    int getEndMarker() const {
        return endMarkerSymbol;
    }

    int getSymbolId(const std::string& name) const;
    std::string symbolName(int id) const;

    bool isTerminal(int id) const;
    bool isNonTerminal(int id) const;

    int symbolsCount() const {
        return static_cast<int>(symbols.size());
    }

    void print(std::ostream& out) const;

private:
    std::map<std::string, int> nameToId;
    std::vector<SymbolInfo> symbols;
    std::vector<Production> productions;

    int startSymbol;
    int endMarkerSymbol;

    int addSymbol(const std::string& name, bool isTerminal);
};

#endif
