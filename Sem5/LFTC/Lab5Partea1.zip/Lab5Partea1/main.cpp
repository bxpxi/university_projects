#include <iostream>
#include <fstream>
#include <vector>
#include <string>

#include "Grammar.h"
#include "LL1Parser.h"

int main(int argc, char** argv) {
    if (argc < 3) {
        std::cerr << "Utilizare: " << argv[0] << " <fisier_gramatica> <fisier_input>\n";
        return 1;
    }

    std::string grammarFile = argv[1];
    std::string inputFile   = argv[2];

    Grammar g;
    std::string err;
    if (!g.loadFromFile(grammarFile, err)) {
        std::cerr << "Eroare la incarcare gramatica: " << err << "\n";
        return 1;
    }

    std::cout << "=== Gramatica citita ===\n";
    g.print(std::cout);
    std::cout << "========================\n\n";

    LL1Parser parser(g);
    parser.build();

    if (!parser.isLL1()) {
        std::cerr << "Gramatica NU este LL(1): " << parser.getErrorMessage() << "\n";
        return 1;
    } else {
        std::cout << "Gramatica este LL(1) (nu au fost detectate conflicte in tabel).\n\n";
    }

    std::ifstream fin(inputFile);
    if (!fin) {
        std::cerr << "Nu s-a putut deschide fisierul de intrare: " << inputFile << "\n";
        return 1;
    }

    std::vector<int> inputIds;
    std::string tok;
    while (fin >> tok) {
        int id = g.getSymbolId(tok);
        if (id < 0) {
            std::cerr << "Simbol necunoscut in secventa de intrare: '" << tok << "'\n";
            return 1;
        }
        if (!g.isTerminal(id)) {
            std::cerr << "Simbol neterminal folosit in secventa de intrare: '" << tok << "'\n";
            return 1;
        }
        inputIds.push_back(id);
    }

    inputIds.push_back(g.getEndMarker());

    if (inputIds.empty()) {
        std::cerr << "Secventa de intrare este goala.\n";
        return 1;
    }

    std::vector<int> usedProductions;
    std::string parseErr;

    bool ok = parser.parse(inputIds, usedProductions, parseErr);
    if (!ok) {
        std::cerr << "Program incorect sintactic.\n";
        std::cerr << parseErr << "\n";
        return 1;
    }

    std::cout << "Secventa acceptata.\n";
    std::cout << "Sirul productiilor folosite (in ordinea derivarilor):\n";

    const auto& prods = g.getProductions();
    for (size_t i = 0; i < usedProductions.size(); ++i) {
        int idx = usedProductions[i];
        if (idx < 0 || idx >= (int)prods.size()) continue;
        const auto& p = prods[idx];
        std::cout << i << ") " << g.symbolName(p.lhs) << " -> ";
        if (p.rhs.empty()) {
            std::cout << "eps";
        } else {
            for (size_t j = 0; j < p.rhs.size(); ++j) {
                std::cout << g.symbolName(p.rhs[j]);
                if (j + 1 < p.rhs.size()) std::cout << " ";
            }
        }
        std::cout << "\n";
    }

    return 0;
}
