#ifndef LL1PARSER_H
#define LL1PARSER_H

#include "Grammar.h"
#include <set>
#include <map>
#include <vector>
#include <string>

class LL1Parser {
public:
    LL1Parser(const Grammar& g);

    void build();

    bool isLL1() const {
        return ll1Ok;
    }
    std::string getErrorMessage() const {
        return ll1ErrorMessage;
    }

    bool parse(const std::vector<int>& input, std::vector<int>& usedProductions, std::string& errorMsg) const;

    const std::vector<std::set<int>>& getFIRST() const {
        return FIRST;
    }

    const std::vector<std::set<int>>& getFOLLOW() const {
        return FOLLOW;
    }

private:
    const Grammar& grammar;

    std::vector< std::set<int> > FIRST;
    std::vector< std::set<int> > FOLLOW;

    std::vector< std::map<int, int> > parseTable;

    bool ll1Ok;
    std::string ll1ErrorMessage;

    void computeFirst();
    void computeFollow();

    std::set<int> firstOfSequence(const std::vector<int>& seq) const;

    void buildTable();
};

#endif
