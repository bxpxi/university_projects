#include <iostream>
using namespace std;

int main() {
    int a, b

    if (a < b) {
        cout << a << endl;

        while (a < 10)
            cin >> a;

        return 0;
    }
}