#include <iostream>
using namespace std;

int main() {
    int a, b;
    float_array v[10];

    a = 5;
    b = a + 2 * 3;

    if (a < b) {
        cout << a << endl;
    } else {
        cout << b << endl;
    }

    while (a < 10) {
        cin >> a;
    }

    for (int i, j; i < 10; i = i + 1) {
        cout << i << endl;
    }

    return 0;
}
