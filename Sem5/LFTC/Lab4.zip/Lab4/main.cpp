#include <cstdio>
#include <cstdlib>

extern int yyparse(void);
extern FILE* yyin;

int main(int argc, char** argv) {
    if (argc < 2) {
        std::fprintf(stderr, "Utilizare: %s <fisier-sursa>\n", argv[0]);
        return 1;
    }

    yyin = std::fopen(argv[1], "r");
    if (!yyin) {
        std::perror("Nu se paote deschide fisierul sursa");
        return 1;
    }

    int res = yyparse();

    if (res == 0) {
        std::printf("Program corect sintactic.\n");
    } else {
        std::printf("Program incorect sintactic.\n");
    }

    std::fclose(yyin);
    return res;
}
